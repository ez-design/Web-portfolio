<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>CAFFE PASCUCCI</title>
<link rel="stylesheet" href="http://leedaegyu.pe.kr/css/default.css?ver=2303229">
<link rel="stylesheet" href="http://leedaegyu.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<!--[if lte IE 8]>
<script src="http://leedaegyu.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://leedaegyu.pe.kr";
var g5_bbs_url   = "http://leedaegyu.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.caffe-pascucci.co.kr/">
<meta property="og:title" content="CAFFE PASCUCCI">
<meta property="og:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta property="og:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:url" content="https://www.caffe-pascucci.co.kr/">
<meta name="twitter:title" content="CAFFE PASCUCCI">
<meta name="twitter:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta name="twitter:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<script defer src="/js/default.js"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-1.12.4.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery.menu.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/common.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/wrest.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/placeholders.min.js?ver=2210172"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-default.css">
<link rel="stylesheet" href="/css/policy.css">

<div class="skip-nav">
    <a href="#main-con">메인콘텐츠 바로가기</a>
</div>
<header class="header">
  <div class="inner">
    <h1 class="h-logo"><a href="http://leedaegyu.pe.kr/">카페 파스쿠찌</a></h1>
    <nav class="gnb">
     <ul>
        <li class="depth1"><a href="/sub/sub1-1.php"><span>BRAND</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub1-1.php"><span>카페 파스쿠찌</span></a></li>
            <li><a href="/sub/sub1-2.php"><span>커피 이야기</span></a></li>
            <li><a href="/sub/sub1-3.php"><span>에스프레소 바</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>MENU</span></a>
          <ul ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>시즌</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=coffee"><span>커피</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=beverage"><span>음료</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=food"><span>음식</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=product"><span>상품</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>STORE</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>매장찾기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=inquiry"><span>1:1 문의하기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=faq"><span>자주하는 질문</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>NEWS</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=sns"><span>SNS</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="/sub/sub5-1.php"><span>FRANCHISE</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
            <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
            <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
            <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="depth2-bg"></div>
    </nav>
    <nav class="tnb">
      <ul class="hd_login">        
                <li class="account">
          <a href="http://leedaegyu.pe.kr/bbs/register.php"><i class="xi-user-plus-o"></i>Sign&nbsp;Up</a>
        </li>
        <li class="login">
          <a href="http://leedaegyu.pe.kr/bbs/login.php"><i class="xi-log-in"></i>Sign&nbsp;In</a>
        </li>
            </ul>
    </nav>
  </div>
</header>
<main class="main" id="main-con">
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">POLICY</p>
    </div>
  </section>
  <div class="inner">
  <nav class="lnb inner">
    <ul class="lnb-wrap">
      <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
      <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
      <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    </ul>
  </nav>
    
<script>
$(document).ready(function(){
  $(".lnb-wrap li:nth-child(1)").addClass("on");
});
</script>

<section class="sub-wrap policy inner">
  <header class="sub-header">
    <h2 class="sub-header-tit">개인정보 처리방침</h2>
    <p class="sub-header-desc">
      ‘파리크라상(파스쿠찌)’은 고객님의 개인정보를 중요시하며, 「개인정보 보호법」 및 관계 법령이 정한 바를 준수하여, 적법하게 개인정보를 처리하고 안전하게 관리하고 있습니다.회사는 개인정보처리방침을 통하여 고객님께서 제공하시는 개인정보가 어떠한 용도와 방식으로 이용되고 있으며,<br>개인정보 보호를 위해 어떠한 조치가 취해지고 있는지 알려드립니다.
    </p>
  </header>
  <article class="policy-con" id="privacy1">
    <h3>1. 개인정보의 수집 및 이용목적</h3>
    <p class="desc">
      회사에서는 파스쿠찌 서비스 이용에 관한 정보를 제공하고 고지하기 위하여 개인정보를 수집하고 있습니다.
    </p>
    <table class="table conTbMulti">
      <caption>개인정보의 수집 및 이용목적 테이블로 구분에 따른 이용목적 등의 정보를 제공합니다.</caption>
      <colgroup>
        <col style="width: 33%;">
        <col>
      </colgroup>
      <thead>
        <tr>
          <th scope="col">구분</th>
          <th scope="col">이용목적</th>
        </tr>
      </thead>
      <tbody>
        <tr data-title="가맹설명회 신청">
          <th scope="row">가맹설명회 신청</th>
          <td data-title="이용목적" class="subject">- 파스쿠찌 가맹설명회 참석 접수 및 확인</td>
        </tr>
        <tr data-title="FAQ /가맹문의">
          <th scope="row">가맹문의</th>
          <td data-title="이용목적" class="subject">- 파스쿠찌 가맹문의 접수 및 확인</td>
        </tr>
        <tr data-title="1:1 문의하기">
          <th scope="row">1:1 문의하기</th>
          <td data-title="이용목적" class="subject">- SPC 고객센터 문의 처리 (파스쿠찌 운영DB 미 저장)</td>
        </tr>
      </tbody>
    </table>
  </article>
  <article class="policy-con" id="privacy2">
    <h3>2. 개인정보의 수집항목</h3>
    <table>
      <caption>개인정보의 수집항목 테이블로 구분에 따른 이용목적 등의 정보를 제공합니다.</caption>
      <colgroup>
        <col style="width: 20%;">
        <col>
        <col style="width: 20%;">
      </colgroup>
      <thead>
        <tr>
          <th scope="col">수집 구분</th>
          <th scope="col">수집항목</th>
          <th scope="col">보유 및 이용기간</th>
        </tr>
      </thead>
      <tbody>
        <tr data-title="가맹설명회 신청">
          <th scope="row">가맹설명회 신청</th>
          <td data-title="수집항목">
            [필수] 이름, 휴대폰번호, 참석지역<br>
            [선택] 이메일</td>
          <td data-title="보유 및 이용기간">3개월 보유 후 파기</td>
        </tr>
        <tr data-title="가맹문의">
          <th scope="row">가맹문의</th>
          <td data-title="수집항목">
            [필수] 이름, 휴대폰번호, 가맹문의 관련 정보(점포소유여부, 희망개설지역, 원하는점포형태)<br>
            [선택] 이메일, 연령대, 가맹문의 관련 정보(희망개설지역상세, 원하는점포형태기타 상세, 창업희망시기, 경로)
          </td>
          <td data-title="보유 및 이용기간">1년 후 보유 파기</td>
        </tr>
        <tr data-title="1:1 문의하기">
          <th scope="row">1:1 문의하기</th>
          <td data-title="수집항목">
            [필수] 이름, 이메일, 고객 상담을 위해 제공한 정보<br>
            [선택] 전화번호 
          </td>
          <td data-title="보유 및 이용기간">3년 보유 후 파기</td>
        </tr>
      </tbody>
    </table>
    <p class="additionalTxt">
      </p><ul class="txtD1">
        <li>1) 이용자의 인터넷 등 로그기록/이용자 접속지 추적자료 : 3개월(통신비밀보호법)</li>
      </ul>
    <p></p>
  </article>
  <article class="policy-con" id="privacy3">
    <h3>3. 개인정보 수집방법</h3>
    <ul class="txtD1">
      <li>1) 개인정보 수집 필요 시점에 홈페이지, 서면양식, 전화/팩스, 전자우편 등을 의한 개인정보를 수집</li>
      <li>2) 상담내역 및 이력, 결제기록, 이용기록 등 통상적인 서비스 제공과정에서 자동적으로 수집, 생성되는 정보의 수집</li>
    </ul>
  </article>
  <article class="policy-con" id="privacy4">
    <h3>4. 개인정보 자동수집 장치의 설치, 운영 및 그 거부에 관한 사항</h3>
    <ul class="txtD1">
      <li>1) 쿠키(cookie)란?
        <p class="additionalTxt">회사에서는 고객에 대한 정보를 저장하고 수시로 찾아내는 쿠키(cookie)를 사용합니다. 쿠키는 웹사이트가 고객의 컴퓨터 브라우저(인터넷 익스플로러, 크롬 등)로 전송하는 소량의 정보입니다.</p>
      </li>
      <li>2) 쿠키(cookie) 운용
        <p class="additionalTxt">회사에서는 이용자의 편의를 위하여 쿠키를 운영합니다. 쿠키를 통해 수집하는 정보는 회원 아이디에 한하며, 그 외의 다른 정보는 수집하지 않습니다. 쿠키(cookie)를 통해 수집한 회원 아이디는 다음의 목적을 위해 사용됩니다. (쿠키는 브라우저의 종료시나 로그아웃 시 만료됩니다.</p>
      </li>
      <li>3) 쿠키 설정 거부방법
        <p class="additionalTxt">고객이 사용하는 웹브라우저의 「옵션」메뉴를 선택함으로써 모든 쿠키를 허용하거나 쿠키를 저장할 때마다 확인을 거치거나, 모든 쿠키의 저장을 거부할 수 있습니다. 단, 쿠키설치를 거부하였을 경우 서비스 제공에 제한이 있을 수 있습니다.</p>
      </li>
    </ul>
  </article>
  <article class="policy-con" id="privacy5">
    <h3>5. 개인정보의 파기절차 및 방법</h3>
    <ul class="txtD1">
      <li>1) 파기절차
        <ul class="txtD2">
          <li>고객의 개인정보는 수집, 이용목적이 달성된 후 내부 방침 및 기타 관련 법령에 의한 정보 보호 사유에 따라(보유 및 이용기간 참조) 일정 기간 저장된 후 파기됩니다.</li>
          <li>파기대상 : 보유 및 이용기간, 관련법령에 따른 보존기간이 종료된 고객정보</li>
        </ul>
      </li>
      <li>2) 파기방법
        <ul class="txtD2">
          <li>전자적 파일형태로 저장된 개인정보는 기록을 재생할 수 없는 기술적 방법을 사용하여 삭제합니다.</li>
          <li>종이에 출력된 개인정보는 분쇄기로 분쇄하거나 소각을 통하여 파기합니다.</li>
        </ul>
      </li>
    </ul>
  </article>
  <article class="policy-con" id="privacy6">
    <h3>6. 개인정보의 제 3자 제공</h3>
    <p class="desc">
      회사에서는 고객의 개인정보를 개인정보처리방침의 「개인정보의 이용목적」에서 고지한 범위 또는 서비스이용약관에 명시한 범위 내에서 사용하며, 동 범위를 넘어 이용하거나 제3자에게 제공하지 않습니다. <br>
      단 다음의 경우에는 관련 법령의 규정에 의해 고객의 동의 없이 개인정보를 제공하는 것이 가능합니다.
    </p>
    <ul class="txtD1">
      <li>1) 서비스 제공에 관한 계약 이행</li>
      <li>2) 관련 법령의 규정에 의하거나, 수사목적으로 법령에 정해진 절차와 방법에 따라 수사기관의 요구가 있는 경우</li>
      <li>3) 통계작성, 학술연구나 시장조사를 위해 특정 개인을 식별할 수 없는 형태로 가공하여 제공하는 경우 <br>
      *제3자에게 고객 개인정보를 제공이 발생하는 경우 반드시 정보주체에게 제3자 제공에 대한 동의 받도록 하겠습니다.</li>
    </ul>
  </article>
  <article class="policy-con" id="privacy7">
    <h3>7. 개인정보의 처리 위탁</h3>
    <p class="desc">회사에서는 서비스이행을 위해 다음과 같이 개인정보 취급 업무를 외부 전문업체에 위탁하여 운영하고 있습니다.</p>
    <table class="table conTbMulti mobWideMore noSubTit">
      <caption>개인정보의 수집항목 테이블로 구분에 따른 이용목적 등의 정보를 제공합니다.</caption>
      <colgroup>
        <col style="width: 40%;">
        <col>
      </colgroup>
      <thead>
        <tr>
          <th scope="col">수탁사명</th>
          <th scope="col">위탁하는 업무</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th data-title="수탁사명">(주) 플립커뮤니케이션즈</th>
          <td data-title="위탁하는 업무">홈페이지 운영 유지 및 이벤트 대행</td>
        </tr>
          <tr>
          <th data-title="수탁사명">(주) 섹타나인</th>
          <td data-title="위탁하는 업무">1:1 문의하기 VOC 웹사이트 총괄관리</td>
          </tr>
          <tr>
          <th data-title="수탁사명">(주) 파리크라상 소속점포</th>
          <td data-title="위탁하는 업무">점포 상담처리 및 관련 교환/환불</td>
        </tr>
      </tbody>
    </table>
  </article>
  <article class="policy-con" id="privacy8">
    <h3>8. 만14세 미만의 아동에 대한 개인정보보호</h3>
    <p class="desc">회사는 만 14세 미만의 아동 개인정보 수집시 법정 대리인의 동의여부를 확인하고, 법정대리인 권리행사 시 본인확인을 진행합니다. 이 경우 정보주체가 동의하신 사항에서만 이용하며, 개인정보의 열람 및 오류정정을 요구 시, 지체 없이 필요한 조치를 취하며 오류정정 요구가 있을 시 그 정정 때까지 당해 해당정보를 이용하지 않습니다.</p>
  </article>
  <article class="policy-con" id="privacy9">
    <h3>9. 이용자 및 법정대리인의 권리와 그 행사방법</h3>
    <ul class="txtD1">
      <li>1) 이용자는 언제든지 본인의 개인정보의 열람 및 오류정정을 요구할 수 있고, 당 회사에서는 지체 없이 필요한 조치를 취하며 오류정정 요구가 있을 시 그 정정 때까지 당해 해당정보를 이용하지 않습니다.</li>
      <li>2) 또한, 담당자에게 이메일 또는 전화로 연락하여 회원님 본인임을 확인한 후 열람/변경/회원탈퇴 신청을 하실 수 있습니다.</li>
    </ul>
  </article>
  <article class="policy-con" id="privacy10">
    <h3>10. 개인정보의 기술적/관리적 보호 대책</h3>
    <p class="desc">회사에서는 수집된 개인정보의 안정성 확보를 위하여 아래와 같은 기술적/관리적 대책을 강구하고 있습니다.</p>
    <h4>[기술적 대책]</h4>
    <ul class="txtD1">
      <li>1) 고객님의 개인정보는 비밀번호에 의해 보호되며, 파일 및 전송 데이터를 암호 화하여 중요한 데이터는 보호되고 있습니다.</li>
      <li>2) 해킹 등에 의한 고객님의 개인정보가 유출되는 것을 방지하기 위해 외부로부터의 침입을 차단하는 네트워크 및 시스템 측면의 별도의 보안 장치(방화벽 등)를 사용하여 침입의 차단 및 모니터링을 수행하고 있습니다.</li>
      <li>3) 백신 및 패치 자동 설치 프로그램을 이용하여, 컴퓨터 바이러스에 의한 피해를 방지하기 위한 조치를 취하고 있습니다. 해당 프로그램은 주기적으로 업데이트되며 갑작스런 바이러스가 출현할 경우, 즉시 패치를 적용함으로써 개인정보가 침해되는 것을 방지하고 있습니다.</li>
    </ul>
    <h4>[관리적 대책]</h4>
    <ul class="txtD1">
      <li>1) 회사에서는 고객님의 개인정보에 대한 접근권한을 최소한의 인원으로 제한하고 있으며 그에 해당하는 자는 다음과 같습니다.
        <ul class="txtD2">
          <li>이용자를 직접 상대로 하여 마케팅 업무를 수행하는 자</li>
          <li>개인정보 보호책임자 및 담당자 등 개인정보관리업무를 수행하는 자</li>
          <li>기타 업무상 개인정보의 취급이 불가피한 자</li>
        </ul>
      </li>
      <li>2) 취급자에 의하여 개인정보가 분실, 도난, 유출 등이 되지 아니하도록 의식함양 및 지속적인 교육을 실시합니다.</li>
      <li>3) 개인정보 관련 취급자의 업무 인수인계는 보안이 유지된 상태에서 철저하게 이뤄지고 있으며 입사 및 퇴사 후 개인정보 사고에 대한 책임을 명확화하고 있습니다.</li>
      <li>4) 전산실 및 자료 보관실 등을 특별 보호구역으로 설정하여 출입을 통제하고 있습니다.</li>
      <li>5) 회사에서는 이용자 개인의 실수나 기본적인 인터넷의 위험성 때문에 일어나는 일들에 대해 책임을 지지 않습니다. 회원 개개인이 본인의 개인정보를 보호하기 위해서 자신의 아이디와 비밀번호를 적절하게 관리하고 여기에 대한 책임을 져야 합니다.</li>
      <li>6) 그 외 내부 관리자의 실수나 기술관리상의 사고로 인해 개인정보의 상실, 유출, 변조, 훼손이 유발될 경우 즉각 고객님께 사실을 알리고 적절한 대책과 보상을 강구할 것입니다.</li>
    </ul>
  </article>
  <article class="policy-con" id="privacy11">
    <h3>11. 개인정보보호책임자 및 담당부서 안내</h3>
    <p class="desc">1) 회사에서는 고객의 개인정보를 보호하고 개인정보와 관련한 불만을 처리하기 위하여 아래와 같이 개인정보보호 책임자를 지정하고 있습니다. <br>
    고객께서는 당 회사의 서비스를 이용하시며 발생하는 모든 개인정보보호 관련 민원을 개인정보 보호책임자에게 신고하실 수 있으며 당 회사에서는 고객의 신고사항에 대해 신속하게 충분한 답변을 드릴 것입니다.</p>
    <table class="table conTbMulti noPd tdSubTit">
      <caption>개인정보관리책임자 및 담당부서 안내 테이블로 개인정보 보호책임자,개인정보보호 담당자(정),개인정보보호 담당자(부) 등의 정보를 제공합니다.</caption>
      <thead>
        <tr>
          <th scope="col">개인정보 보호책임자</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>디지털정보혁신실</td>
        </tr>
        <tr>
          <td>김종호 상무</td>
        </tr>
        <tr>
          <td>02-2276-6259, aykim@spc.co.kr</td>
        </tr>
      </tbody>
    </table>
    <p class="desc">
      기타 개인정보침해에 대한 신고나 상담이 필요하신 경우에는 아래 기관에 문의하시기 바랍니다.<br>
      - 개인정보침해신고센터 (privacy.kisa.or.kr / 국번없이 118)<br>
      - 개인정보분쟁조정위원회 (www.kopico.go.kr / 국번없이 1833-6972)<br>
      - 대검찰청 사이버수사과 (www.spo.go.kr / 국번없이 1301)<br>
      - 경찰청 사이버수사국 사이버범죄 신고시스템(ecrm.police.go.kr / 국번없이 182)
    </p>
  </article>
  <article class="policy-con" id="privacy12">
    <h3>12. 고지의 의무</h3>
    <p class="desc">현 개인정보처리방침은 2022년 10월 27일부터 적용됩니다. 개인정보처리방침의 내용은 수시로 변경될 수 있으며, 변경 내용의 확인이 용이하도록 회사의 홈페이지 첫 화면 하단에 상시로 공개 합니다. <br>
    현 개인정보처리방침 내용의 변경이 있을 경우 변경사항을 최소 7일전부터 홈페이지 ‘공지사항’을 통하여 공지합니다. 단, 회원님의 권리 또는 의무에 중요한 내용의 변경은 시행일로부터 30일 이전에 고지합니다.</p>
  </article>
  <article class="policy-con" id="privacy13">
    <h3>13. 시행일자</h3>
    <p class="desc">공고일 : 2022년 10월 20일 <br>
    시행일 : 2022년 10월 27일</p>
  </article>
</section>

  </div>
</main>
<aside class="side" aria-hidden="true">
  <button type="button" class="side-btn side-top"></button>
  <a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact" class="side-btn side-talk"><span>가맹문의</span></a>
</aside>
<footer class="footer">
  <div class="inner">
    <p class="f-logo">카페 파스쿠찌</p>
    <ul class="f-menu">
    <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
    <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
    <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    <li><a href="https://www.happypointcard.com/page/customer/term.spc">이용약관</a></li>
    <li><a href="https://www.spc.co.kr/share/right-mng/tip-off-intro/">윤리신고센터</a></li>
    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=E477ABF316702625A4017450F648607F">해피포인트</a></li>
    </ul>
    <div class="f-box clear">
    <ul class="f-sns">
      <li><a href="https://www.instagram.com/pascucci_kr/"><span class="hidden">인스타그램</span></a></li>
      <li><a href="https://blog.naver.com/pascucci1883"><span class="hidden">네이버블로그</span></a></li>
      <li><a href="https://www.youtube.com/channel/UCHKRIWTWjq0uzJOAm6KFHOg"><span class="hidden">유튜브</span></a></li>
      <li><a href="https://www.facebook.com/pascucci1883"><span class="hidden">페이스북</span></a></li>
    </ul>
    <div class="f-family"><span>FAMILY SITE</span>
      <ul class="f-family-wrap">
        <li><a href="https://www.pascucci.it/">파스쿠찌 이탈리아</a></li>
        <li><a href="https://www.happyconstore.com/">해피콘</a></li>
        <li><a href="https://www.happypointcard.com/page/main/index.spc">해피포인트카드</a></li>
        <li><a href="https://www.dunkindonuts.co.kr/">던킨도너츠</a></li>
        <li><a href="https://www.baskinrobbins.co.kr/">배스킨라빈스31</a></li>
        <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
        <li><a href="https://pariscroissantorder.com/">파리크라상</a></li>
        <li><a href="http://www.jambajuice.co.kr/">잠바주스</a></li>
        <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
      </ul>
    </div>
    <dl class="f-addr">
      <dt class="hidden">주소</dt>
      <dd><address>경기도 성남시 중원구 사기막골로 31번길 18</address></dd>
      <dt class="clear">사업자등록번호</dt>
      <dd>129-81-07244</dd>
      <dt>Fax</dt>
      <dd>0505-073-0210</dd>
      <dt>Tel</dt>
      <dd>080-731-2027</dd>
    </dl>
    <p class="f-copy clear">COPYRIGHT ⓒ 2023 CAFE PASCUCCI. ALL RIGHTS RESERVED.</p>
  </div>
</div>
</footer>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
