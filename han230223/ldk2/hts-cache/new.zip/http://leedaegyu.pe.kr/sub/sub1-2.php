<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>CAFFE PASCUCCI</title>
<link rel="stylesheet" href="http://leedaegyu.pe.kr/css/default.css?ver=2303229">
<link rel="stylesheet" href="http://leedaegyu.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<!--[if lte IE 8]>
<script src="http://leedaegyu.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://leedaegyu.pe.kr";
var g5_bbs_url   = "http://leedaegyu.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.caffe-pascucci.co.kr/">
<meta property="og:title" content="CAFFE PASCUCCI">
<meta property="og:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta property="og:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:url" content="https://www.caffe-pascucci.co.kr/">
<meta name="twitter:title" content="CAFFE PASCUCCI">
<meta name="twitter:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta name="twitter:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<script defer src="/js/default.js"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-1.12.4.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery.menu.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/common.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/wrest.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/placeholders.min.js?ver=2210172"></script>
</head>
<body>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<link rel="stylesheet" href="/css/sub-default.css">
<link rel="stylesheet" href="/css/sub1.css">

<div class="skip-nav">
    <a href="#main-con">메인콘텐츠 바로가기</a>
</div>
<header class="header">
  <div class="inner">
    <h1 class="h-logo"><a href="http://leedaegyu.pe.kr/">카페 파스쿠찌</a></h1>
    <nav class="gnb">
     <ul>
        <li class="depth1"><a href="/sub/sub1-1.php"><span>BRAND</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub1-1.php"><span>카페 파스쿠찌</span></a></li>
            <li><a href="/sub/sub1-2.php"><span>커피 이야기</span></a></li>
            <li><a href="/sub/sub1-3.php"><span>에스프레소 바</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>MENU</span></a>
          <ul ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>시즌</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=coffee"><span>커피</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=beverage"><span>음료</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=food"><span>음식</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=product"><span>상품</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>STORE</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>매장찾기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=inquiry"><span>1:1 문의하기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=faq"><span>자주하는 질문</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>NEWS</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=sns"><span>SNS</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="/sub/sub5-1.php"><span>FRANCHISE</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
            <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
            <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
            <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="depth2-bg"></div>
    </nav>
    <nav class="tnb">
      <ul class="hd_login">        
                <li class="account">
          <a href="http://leedaegyu.pe.kr/bbs/register.php"><i class="xi-user-plus-o"></i>Sign&nbsp;Up</a>
        </li>
        <li class="login">
          <a href="http://leedaegyu.pe.kr/bbs/login.php"><i class="xi-log-in"></i>Sign&nbsp;In</a>
        </li>
            </ul>
    </nav>
  </div>
</header>
<main class="main" id="main-con">
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">BRAND</p>
    </div>
  </section>
  <nav class="lnb inner">
    <ul class="lnb-wrap">
      <li><a href="/sub/sub1-1.php">카페 파스쿠찌</a></li>
      <li><a href="/sub/sub1-2.php">커피 이야기</a></li>
      <li><a href="/sub/sub1-3.php">에스프레소 바</a></li>
    </ul>
  </nav>
<script>
$(document).ready(function(){
  $(".lnb-wrap li:nth-child(2)").addClass("on");
});
</script>

<section class="sub-wrap story">
  <header class="sub-header inner">
    <em class="sub-header-eng">Coffee Story</em>
    <h2 class="sub-header-tit">파스쿠찌의 커피 이야기</h2>
    <p class="sub-header-desc">
      카페 파스쿠찌는 130년간 이어진 전통과 연구, 열정을 바탕으로<br>항상 최고의 커피를 위해 노력합니다.
    </p>
  </header>
  <article class="story-item climate">
    <div class="inner">
      <em class="story-desc">이탈리아 중부, 생두 보관에 적합한 기후</em>
      <h3 class="story-tit">천혜의 환경</h3>
      <div class="story-txt">
        <p>
          이탈리아에서 수만 킬로미터 떨어진 산지에서 재배∙가공 되어 배에 실려 운반된 생두는 이동기간 동안<br>바다의 염분과 습기를 머금고 있기 때문에 로스팅 이전까지 습도∙온도의 조절과 관리를 통해<br>지속적으로 품질을 유지시킬 수 있도록 해야 합니다.
        </p>
        <p>
          이탈리아 중부 <strong>‘몬테 체리뇨네’(Monte Cerignone)</strong>는 파스쿠찌 가문에서 오랫동안 생두를 보관해온 곳으로<br>일년 내내 일정한 온도와 낮은 습도가 유지되는 천혜의 요새와 같은 곳입니다.
        </p>
        <p>
          콘가(Conga)강 계곡 600m의 미기후(micr-oclimate)는 생두가 고유의 향미를 지속시키며<br>자연스럽게 시간에 따라 숙성시켜 나갈 수 있도록 하기 때문에 최신 시설의 생두 보관 창고 보다 깊이있고<br>산지의 기후와 작황에 상관 없이 일관된 커피 맛을 낼 수 있도록 합니다.
        </p>
      </div>
      <figure class="climate-img">
        <figcaption class="hidden">몬테 체리뇨네</figcaption>
        <img src="/img/sub1-2-climate.jpg" alt="">
      </figure>
    </div>
  </article>
  <article class="story-item blend">
    <div class="inner">
      <em class="story-desc">이탈리아 커피문화의 대표</em>
      <h3 class="story-tit">파스쿠찌 가문의 블렌딩</h3>
      <div class="story-txt">
        <p>
          총 9가지 품종의 엄선된 생두는 전문가의 테스트를 통해  아라비카 80%, 로브스타 20% 비율로 블렌딩합니다.<br>파스쿠찌 가문이 로브스타를 블렌딩에 사용하는 이유는 에스프레소 본고장 이탈리아 커피문화에서 비롯합니다.
        </p>
        <p>
          이탈리아에선 로브스타 종을 아라비카 종과 블렌딩해 에스프레소의 묵직한 바디와 깊은 쓴맛을 내는 걸<br>오랫동안 선호해 왔습니다. 아라비카 종의 산미, 그리고 풍부한 맛과 향에 로브스타의 구수하고 묵직한 바디감을<br>표현해 내는 것이 파스쿠찌 가문의 블렌딩 노하우 입니다.
        </p>
      </div>
      <figure class="blend-img">
        <img src="/img/sub1-2-blend.jpg" alt="">
      </figure>
    </div>
  </article>
  <article class="story-item roast">
    <div class="inner">
      <em class="story-desc">생두 고유의 맛과 향미를 살리는</em>
      <h3 class="story-tit">슬로우 로스팅</h3>
      <div class="story-txt">
        <p>
          블렌딩을 할 때에는 균일하게 로스팅을 하는 것이 중요하기 때문에 특유의 노하우가 필요합니다.<br>파스쿠찌는 잘 배합된 블렌딩 생두를 중배전(미디움 로스팅)으로 슬로우 로스팅(Slow Roasting) 합니다.
        </p>
        <p>
          슬로우 로스팅은 보통의 로스팅 시간 11~14분 보다 긴 15~18분 동안 중간 정도의 불세기로 천천히 로스팅하며<br>생두안의 수분을 자연스럽게 증발시키고, 안의 좋은 맛과 향미의 성분을 끌어내는 방식입니다.<br>이 방식은 에스프레소의 탄맛이 적고 특유의 바디감과 쌉쌀한 맛을 깨워 내는데 가장 중요한 과정 중 하나입니다.
        </p>
      </div>
      <figure class="roast-img">
        <img src="/img/sub1-2-roast.jpg" alt="">
      </figure>
    </div>
  </article>
  <article class="story-item golden">
    <div class="inner">
      <em class="story-desc">이탈리아 전통의 맛과 경험을 위한</em>
      <h3 class="story-tit">프리미엄 원두 - 골든 색</h3>
      <div class="story-txt">
        <p>
          정통 에스프레소 커피의 특별한 맛과 경험을 구현하기 위한 골든 색(Golden Sack)은<br>이탈리아 파스쿠찌와 내부 연구원 및 소비자 테스트를 통해 검증을 받은 프리미엄 원두입니다.
        </p>
        <p>
          골든 색(Golden Sack)으로 갓 추출한 에스프레소는 미디움 바디감은 물론 말린 과일의 신맛과 밀크초콜릿의<br>단맛의 조화가 뛰어납니다. 또한, 브라운 슈가, 쿠키, 구운 아몬드의 풍무한 아로마와 부드러운 목넘김 후<br>좋은 여운이 오래 남는 특징을 가지고 있습니다.
        </p>
      </div>
      <figure class="golden-img">
        <figcaption class="hidden">골든 색</figcaption>
        <img src="/img/sub1-2-golden.jpg" alt="">
      </figure>
    </div>
  </article>
  <article class="story-item research">
    <div class="inner">
      <em class="story-desc">전통과 정통을 잇는 밑거름</em>
      <h3 class="story-tit">130년의 에스프레소 연구</h3>
      <div class="story-txt">
        <p>
          1883년 파스쿠찌 가문이 생두 거래를 시작하고 커피업 확산의 발판이 되는 로스팅 공장 설립 이후,<br>이탈리아 에스프레소에 대한 연구를 적극적으로 시작하게 됩니다.
        </p>
        <p>
          처음에는 단순히 생두에 대한 연구였으나 이후 에스프레소의 품질을 높이기 위해 농학자, 과학자 등의<br>전문가 집단으로 운영되는 자체 연구소를 설립하고, 생두별 역사, 결점두 기준 관리, 곰팡이 및 병충해 연구 등<br>생산지에서 지속적으로 높은 품질의 생두를 생산할 수 있도록 하는 연구로 확대되었습니다.
        </p>
        <p>
          이를 통해 연구 환경이 열악한 생산 농가에게 다양한 정보를 제공하고 지속가능한 품질을 유지할 수 있도록<br>지원하고 있습니다. 파스쿠찌는 지속적인 연구와 정보의 공유를 통해 130년 동안 변하지 않는 에스프레소<br>맛을 유지할 수 있으며 산지와의 지속가능한 커피 산업을 만들어 나가고 있습니다.
        </p>
      </div>
      <figure class="research-img">
        <figcaption class="hidden">파스쿠찌 연구실</figcaption>
        <img src="/img/sub1-2-research.jpg" alt="">
      </figure>
    </div>
  </article>
</section>


</main>
<aside class="side" aria-hidden="true">
  <button type="button" class="side-btn side-top"></button>
  <a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact" class="side-btn side-talk"><span>가맹문의</span></a>
</aside>
<footer class="footer">
  <div class="inner">
    <p class="f-logo">카페 파스쿠찌</p>
    <ul class="f-menu">
    <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
    <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
    <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    <li><a href="https://www.happypointcard.com/page/customer/term.spc">이용약관</a></li>
    <li><a href="https://www.spc.co.kr/share/right-mng/tip-off-intro/">윤리신고센터</a></li>
    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=E477ABF316702625A4017450F648607F">해피포인트</a></li>
    </ul>
    <div class="f-box clear">
    <ul class="f-sns">
      <li><a href="https://www.instagram.com/pascucci_kr/"><span class="hidden">인스타그램</span></a></li>
      <li><a href="https://blog.naver.com/pascucci1883"><span class="hidden">네이버블로그</span></a></li>
      <li><a href="https://www.youtube.com/channel/UCHKRIWTWjq0uzJOAm6KFHOg"><span class="hidden">유튜브</span></a></li>
      <li><a href="https://www.facebook.com/pascucci1883"><span class="hidden">페이스북</span></a></li>
    </ul>
    <div class="f-family"><span>FAMILY SITE</span>
      <ul class="f-family-wrap">
        <li><a href="https://www.pascucci.it/">파스쿠찌 이탈리아</a></li>
        <li><a href="https://www.happyconstore.com/">해피콘</a></li>
        <li><a href="https://www.happypointcard.com/page/main/index.spc">해피포인트카드</a></li>
        <li><a href="https://www.dunkindonuts.co.kr/">던킨도너츠</a></li>
        <li><a href="https://www.baskinrobbins.co.kr/">배스킨라빈스31</a></li>
        <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
        <li><a href="https://pariscroissantorder.com/">파리크라상</a></li>
        <li><a href="http://www.jambajuice.co.kr/">잠바주스</a></li>
        <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
      </ul>
    </div>
    <dl class="f-addr">
      <dt class="hidden">주소</dt>
      <dd><address>경기도 성남시 중원구 사기막골로 31번길 18</address></dd>
      <dt class="clear">사업자등록번호</dt>
      <dd>129-81-07244</dd>
      <dt>Fax</dt>
      <dd>0505-073-0210</dd>
      <dt>Tel</dt>
      <dd>080-731-2027</dd>
    </dl>
    <p class="f-copy clear">COPYRIGHT ⓒ 2023 CAFE PASCUCCI. ALL RIGHTS RESERVED.</p>
  </div>
</div>
</footer>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
