<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>CAFFE PASCUCCI</title>
<link rel="stylesheet" href="http://leedaegyu.pe.kr/css/default.css?ver=2303229">
<link rel="stylesheet" href="http://leedaegyu.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<!--[if lte IE 8]>
<script src="http://leedaegyu.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://leedaegyu.pe.kr";
var g5_bbs_url   = "http://leedaegyu.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.caffe-pascucci.co.kr/">
<meta property="og:title" content="CAFFE PASCUCCI">
<meta property="og:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta property="og:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:url" content="https://www.caffe-pascucci.co.kr/">
<meta name="twitter:title" content="CAFFE PASCUCCI">
<meta name="twitter:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta name="twitter:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<script defer src="/js/default.js"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-1.12.4.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery.menu.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/common.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/wrest.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/placeholders.min.js?ver=2210172"></script>
</head>
<body>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<link rel="stylesheet" href="/css/sub-default.css">
<link rel="stylesheet" href="/css/sub1.css">

<div class="skip-nav">
    <a href="#main-con">메인콘텐츠 바로가기</a>
</div>
<header class="header">
  <div class="inner">
    <h1 class="h-logo"><a href="http://leedaegyu.pe.kr/">카페 파스쿠찌</a></h1>
    <nav class="gnb">
     <ul>
        <li class="depth1"><a href="/sub/sub1-1.php"><span>BRAND</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub1-1.php"><span>카페 파스쿠찌</span></a></li>
            <li><a href="/sub/sub1-2.php"><span>커피 이야기</span></a></li>
            <li><a href="/sub/sub1-3.php"><span>에스프레소 바</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>MENU</span></a>
          <ul ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>시즌</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=coffee"><span>커피</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=beverage"><span>음료</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=food"><span>음식</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=product"><span>상품</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>STORE</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>매장찾기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=inquiry"><span>1:1 문의하기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=faq"><span>자주하는 질문</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>NEWS</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=sns"><span>SNS</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="/sub/sub5-1.php"><span>FRANCHISE</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
            <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
            <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
            <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="depth2-bg"></div>
    </nav>
    <nav class="tnb">
      <ul class="hd_login">        
                <li class="account">
          <a href="http://leedaegyu.pe.kr/bbs/register.php"><i class="xi-user-plus-o"></i>Sign&nbsp;Up</a>
        </li>
        <li class="login">
          <a href="http://leedaegyu.pe.kr/bbs/login.php"><i class="xi-log-in"></i>Sign&nbsp;In</a>
        </li>
            </ul>
    </nav>
  </div>
</header>
<main class="main" id="main-con">
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">BRAND</p>
    </div>
  </section>
  <nav class="lnb inner">
    <ul class="lnb-wrap">
      <li><a href="/sub/sub1-1.php">카페 파스쿠찌</a></li>
      <li><a href="/sub/sub1-2.php">커피 이야기</a></li>
      <li><a href="/sub/sub1-3.php">에스프레소 바</a></li>
    </ul>
  </nav>
<script>
$(document).ready(function(){
  $(".lnb-wrap li:nth-child(1)::before").css('transition','all 0');
  $(".lnb-wrap li:nth-child(1)").addClass("on");
});
</script>

<section class="sub-wrap origin">
  <header class="sub-header inner">
    <em class="sub-header-eng">CAFFÉ PASCUCCI</em>
    <h2 class="sub-header-tit">카페 파스쿠찌</h2>
    <p class="sub-header-desc">
      에스프레소의 고향 이탈리아에서,<br>커피에 대한 열정이 넘치는 파스쿠찌 가족에 의해 카페 파스쿠찌의 역사가 시작되었습니다.
    </p>
  </header>
  <article class="origin-item begin">
    <div class="inner">
      <h3 class="origin-tit">파스쿠찌 가문</h3>
      <div class="origin-txt">
        <em class="origin-year">1883</em>
        <p>
          이탈리아와 영국 두 나라 사이에서 무역을 하던 안토니오 파스쿠찌는 거래품목 중,<br>생두에 큰 관심을 가지고 이를 발전 시키고자 합니다.<br>이것이 카페 파스쿠찌의 이야기가 시작되는 계기가 됩니다.
        </p>
      </div>
      <div class="origin-txt">
        <em class="origin-year">1935</em>
        <p>
          안토니오 파스쿠찌의 아들인 마리오 파스쿠찌는 그의 아내 도메니카와 함께<br>몬테 체리뇨네에서 원두를 주석냄비에 볶아 새로운 맛과 향을 만드는 실험에 성공 합니다.<br>그리고 카페 파스쿠찌의 사업을 본격적으로 전개하게 됩니다.
        </p>
      </div>
      <figure class="begin-img">
        <figcaption>Pascucci Family</figcaption>
        <img src="/img/sub1-1-begin.jpg" alt="">
      </figure>
    </div>
  </article>
  <article class="origin-item develope">
    <div class="inner">
      <h3 class="origin-tit">계속되는 변화와 발전</h3>
      <div class="origin-txt">
        <em class="origin-year">1946</em>
        <p>
          마리오 파스쿠찌의 동생 디노 파스쿠찌가<br>장비를 이용하여 에스프레소를 추출하는 기법을 업계 최초로 도입합니다.
        </p>
      </div>
      <div class="origin-txt">
        <em class="origin-year">1963</em>
        <p>
          알베르토 파스쿠찌는 균일한 로스팅을 위한 간접 연소식 로스터 도입과<br>생산라인을 구축함으로써 원두의 생산량 확대 및 고품질 원두생산이 가능한 환경을 마련했습니다.<br>이로써 대량생산이 가능해졌고 트럭을 활용해서 원두를 배달하기 시작합니다.
        </p>
      </div>
      <figure class="develope-img">
        <figcaption>Alberto Pascucci</figcaption>
        <img src="/img/sub1-1-develope.jpg" alt="">
      </figure>
    </div>
  </article>
  <article class="origin-item innovate">
    <div class="inner">
      <h3 class="origin-tit">최고의 커피를 위한 혁신</h3>
      <div class="origin-txt">
        <em class="origin-year">1975</em>
        <p>
          카페 파스쿠찌는 에스프레소 커피에 전념하기 위해 식품 유통 사업을 포기하고<br><strong>"Only Top-Quality Coffee"</strong>이라는 프로젝트를 시작했습니다.<br>그 후, 달콤하고 향기로운 커피로 구성된 골든 블렌드는 에스프레소 커피의 맛을 혁신적으로 바꾸게 됩니다.
        </p>
      </div>
      <div class="origin-txt">
        <em class="origin-year">2000</em>
        <p>
        그들은 최고의 커피를 위해 원두 수분 유지에 이상적인 몬테 세리뇨네에 또다시 공장을 증설했습니다.<br>알베르토 파스쿠찌는 이후 특허받은 로스팅 시스템으로 상공회의소에서 상을 받으며 회사의 명성을 높였습니다.
        </p>
      </div>
    </div>
  </article>
  <article class="origin-item global">
    <div class="inner">
      <h3 class="origin-tit">이탈리아 정통 에스프레소 전문점</h3>
      <div class="origin-txt">
        <p>
          그 후 130년간 계속 이어진 파스쿠찌 가문의 노력은<br>카페 파스쿠찌를 이탈리아 카페 업계 상위 10개의 브랜드로 성장시켰습니다.
        </p>
        <p>
          그리고 이탈리아 본래 모습에 충실한 정통 에스프레소 전문점으로 그 문화를 세계로 전파하였고,<br>현재 영국, 미국, 한국 등 전 세계 20여 개국 100여 도시에 진출하게 됩니다.
        </p>
      </div>
      <figure class="global-img">
        <figcaption class="hidden">파스쿠찌 본사</figcaption>
        <img src="/img/sub1-1-global.jpg" alt="">
      </figure>
    </div>
  </article>
</section>


</main>
<aside class="side" aria-hidden="true">
  <button type="button" class="side-btn side-top"></button>
  <a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact" class="side-btn side-talk"><span>가맹문의</span></a>
</aside>
<footer class="footer">
  <div class="inner">
    <p class="f-logo">카페 파스쿠찌</p>
    <ul class="f-menu">
    <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
    <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
    <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    <li><a href="https://www.happypointcard.com/page/customer/term.spc">이용약관</a></li>
    <li><a href="https://www.spc.co.kr/share/right-mng/tip-off-intro/">윤리신고센터</a></li>
    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=E477ABF316702625A4017450F648607F">해피포인트</a></li>
    </ul>
    <div class="f-box clear">
    <ul class="f-sns">
      <li><a href="https://www.instagram.com/pascucci_kr/"><span class="hidden">인스타그램</span></a></li>
      <li><a href="https://blog.naver.com/pascucci1883"><span class="hidden">네이버블로그</span></a></li>
      <li><a href="https://www.youtube.com/channel/UCHKRIWTWjq0uzJOAm6KFHOg"><span class="hidden">유튜브</span></a></li>
      <li><a href="https://www.facebook.com/pascucci1883"><span class="hidden">페이스북</span></a></li>
    </ul>
    <div class="f-family"><span>FAMILY SITE</span>
      <ul class="f-family-wrap">
        <li><a href="https://www.pascucci.it/">파스쿠찌 이탈리아</a></li>
        <li><a href="https://www.happyconstore.com/">해피콘</a></li>
        <li><a href="https://www.happypointcard.com/page/main/index.spc">해피포인트카드</a></li>
        <li><a href="https://www.dunkindonuts.co.kr/">던킨도너츠</a></li>
        <li><a href="https://www.baskinrobbins.co.kr/">배스킨라빈스31</a></li>
        <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
        <li><a href="https://pariscroissantorder.com/">파리크라상</a></li>
        <li><a href="http://www.jambajuice.co.kr/">잠바주스</a></li>
        <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
      </ul>
    </div>
    <dl class="f-addr">
      <dt class="hidden">주소</dt>
      <dd><address>경기도 성남시 중원구 사기막골로 31번길 18</address></dd>
      <dt class="clear">사업자등록번호</dt>
      <dd>129-81-07244</dd>
      <dt>Fax</dt>
      <dd>0505-073-0210</dd>
      <dt>Tel</dt>
      <dd>080-731-2027</dd>
    </dl>
    <p class="f-copy clear">COPYRIGHT ⓒ 2023 CAFE PASCUCCI. ALL RIGHTS RESERVED.</p>
  </div>
</div>
</footer>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
