<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>CAFFE PASCUCCI</title>
<link rel="stylesheet" href="http://leedaegyu.pe.kr/css/default.css?ver=2303229">
<link rel="stylesheet" href="http://leedaegyu.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<!--[if lte IE 8]>
<script src="http://leedaegyu.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://leedaegyu.pe.kr";
var g5_bbs_url   = "http://leedaegyu.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.caffe-pascucci.co.kr/">
<meta property="og:title" content="CAFFE PASCUCCI">
<meta property="og:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta property="og:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:url" content="https://www.caffe-pascucci.co.kr/">
<meta name="twitter:title" content="CAFFE PASCUCCI">
<meta name="twitter:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta name="twitter:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<script defer src="/js/default.js"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-1.12.4.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery.menu.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/common.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/wrest.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/placeholders.min.js?ver=2210172"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-default.css">
<link rel="stylesheet" href="/css/policy.css">

<div class="skip-nav">
    <a href="#main-con">메인콘텐츠 바로가기</a>
</div>
<header class="header">
  <div class="inner">
    <h1 class="h-logo"><a href="http://leedaegyu.pe.kr/">카페 파스쿠찌</a></h1>
    <nav class="gnb">
     <ul>
        <li class="depth1"><a href="/sub/sub1-1.php"><span>BRAND</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub1-1.php"><span>카페 파스쿠찌</span></a></li>
            <li><a href="/sub/sub1-2.php"><span>커피 이야기</span></a></li>
            <li><a href="/sub/sub1-3.php"><span>에스프레소 바</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>MENU</span></a>
          <ul ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>시즌</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=coffee"><span>커피</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=beverage"><span>음료</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=food"><span>음식</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=product"><span>상품</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>STORE</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>매장찾기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=inquiry"><span>1:1 문의하기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=faq"><span>자주하는 질문</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>NEWS</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=sns"><span>SNS</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="/sub/sub5-1.php"><span>FRANCHISE</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
            <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
            <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
            <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="depth2-bg"></div>
    </nav>
    <nav class="tnb">
      <ul class="hd_login">        
                <li class="account">
          <a href="http://leedaegyu.pe.kr/bbs/register.php"><i class="xi-user-plus-o"></i>Sign&nbsp;Up</a>
        </li>
        <li class="login">
          <a href="http://leedaegyu.pe.kr/bbs/login.php"><i class="xi-log-in"></i>Sign&nbsp;In</a>
        </li>
            </ul>
    </nav>
  </div>
</header>
<main class="main" id="main-con">
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">POLICY</p>
    </div>
  </section>
  <div class="inner">
  <nav class="lnb inner">
    <ul class="lnb-wrap">
      <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
      <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
      <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    </ul>
  </nav>
    
<script>
$(document).ready(function(){
  $(".lnb-wrap li:nth-child(2)").addClass("on");
});
</script>

<section class="sub-wrap policy inner">
  <header class="sub-header">
    <h2 class="sub-header-tit">영상정보 처리기기 운영 및 관리방침</h2>
    <p class="sub-header-desc">
      ‘파리크라상(파스쿠찌)’은 고객님의 개인정보를 중요시하며,<br>관련법률에 따라 영상정보처리기기 운영 및 관리방침을 통해 개인영상정보 이용 및 관리를 알려드립니다.
    </p>
  </header>
  <article class="policy-con" id="media1">
    <h3>1. 영상정보처리기기의 설치 근거 및 목적</h3>
    <p class="desc">
      회사는 개인정보 보호법 제25조, 개인영상정보 보호법에 따라 고객의 안전, 도난방지, 시설 안전관리 등을 위하여 영상정보처리기기를 설치, 운영하고 있습니다.
    </p>
  </article>
  <article class="policy-con" id="media2">
    <h3>2. CCTV설치현황 및 촬영범위</h3>
    <p class="desc">회사는 아래와 같이 CCTV를 회사 및 매장 내 설치하고 운영하고 있습니다.</p>
    <table>
      <caption>CCTV설치현황 및 촬영범위에 따른 설치 대수의 정보를 제공합니다.</caption>
      <colgroup>
        <col>
        <col style="width: 50%;">
      </colgroup>
      <thead>
        <tr>
          <th scope="col">설치위치 및 촬영범위</th>
          <th scope="col">설치 대수 (2020. 01 기준)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td data-title="직영매장 내 외부">직영매장 내 외부</td>
          <td data-title="설치 대수">279대</td>
        </tr>
      </tbody>
    </table>
  </article>
  <article class="policy-con" id="media3">
    <h3>3. 영상정보 관리책임자 및 담당자</h3>
    <p class="desc">회사는 영상정보 보호를 위해 아래와 같이 책임자 및 접근권한자를 지정하고 있습니다.</p>
    <table class="table conTbMulti mobWideMore noSubTit">
      <caption>관리책임자에 따른 접근권한자의 정보를 제공합니다.</caption>
      <colgroup>
        <col>
        <col style="width: 50%;">
      </colgroup>
      <thead>
        <tr>
          <th scope="col">관리책임자</th>
          <th scope="col">접근권한자</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td data-title="직영관리부서장">직영관리부서장</td>
          <td data-title="접근권한자">부서장, 매장 점장, 정도경영2팀</td>
        </tr>
      </tbody>
    </table>
  </article>
  <article class="policy-con" id="media4">
    <h3>4. 영상정보의 촬영시간, 보관기간, 장소 및 처리방법</h3>
    <p class="desc">회사는 아래와 같이 영상정보를 촬영, 보관, 파기하고 있으며, 용량에 따라 자동삭제 시 복원 불가능한 방법으로 삭제합니다.</p>
    <table class="table conTbMulti mobWideMore noSubTit">
      <caption>촬영시간에 따른 보관기간, 보관장소, 파기방법의 정보를 제공합니다.</caption>
      <colgroup>
        <col>
        <col style="width: 30%;">
        <col style="width: 20%;">
        <col style="width: 30%;">
      </colgroup>
      <thead>
        <tr>
          <th scope="col">촬영시간</th>
          <th scope="col">보관기간</th>
          <th scope="col">보관장소</th>
          <th scope="col">파기방법</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td data-title="24시간">24시간</td>
          <td data-title="보관기간">저장용량에 따라 평균 30일 이내</td>
          <td data-title="보관장소">매장 사무실</td>
          <td data-title="파기방법">저장용량 초과시 자동 삭제</td>
        </tr>
      </tbody>
    </table>
  </article>
  <article class="policy-con" id="media5">
    <h3>5. 개인영상정보의 확인 방법 및 장소에 관한 사항</h3>
    <p class="desc">
      영상정보 확인 방법 및 장소 : 영상정보 관리책임자에게 요구
    </p>
  </article>
  <article class="policy-con" id="media6">
    <h3>6. 정보주체의 영상정보 열람 등 요구에 대한 조치</h3>
    <p class="desc">고객님이 개인영상정보에 관하여 열람 또는 존재확인, 삭제를 원하시는 경우 영상정보처리기기 운영자에게 요구하실 수 있습니다. 단, 고객님이 촬영된 개인영상정보 및 명백히 개인영상정보 주체의 급박한 생명, 신체, 재산의 이익을 위하여 필요한 개인영상정보에 한정됩니다.<br>
    회사는 개인영상정보에 관하여 열람 또는 존재확인, 삭제를 요구한 경우 지체 없이 필요한 조치를 이행합니다.</p>
  </article>
  <article class="policy-con" id="media7">
    <h3>7. 영상정보의 안전성 확보조치</h3>
    <p class="desc">회사에서 처리하는 영상정보는 비밀번호, 암호화 조치 등을 통하여 안전하게 관리되고 있습니다. 또한 본 회사는 개인영상정보보호를 위한 관리적 대책으로서 개인정보에 대한 접근 권한을 차등부여하고 있으며, 개인영상정보의 위변조 방지를 위하여 개인영상정보의 생성 일시, 열람 시 열람 목적, 열람자, 열람 일시 등을 기록하여 관리하고 있습니다.</p>
  </article>
  <article class="policy-con" id="media8">
    <h3>8. 영상정보 처리기기 및 운영관리방침 변경에 관한 사항</h3>
    <p class="desc">본 영상정보처리기기 운영 및 관리방침은 관련 법령과 정책, 영상정보 보호 기술 변경에 따라 변경될 수 있습니다. 변경되는 경우 시행 7일전 웹사이트를 통해 공지하도록 하겠습니다.</p>
  </article>
</section>

  </div>
</main>
<aside class="side" aria-hidden="true">
  <button type="button" class="side-btn side-top"></button>
  <a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact" class="side-btn side-talk"><span>가맹문의</span></a>
</aside>
<footer class="footer">
  <div class="inner">
    <p class="f-logo">카페 파스쿠찌</p>
    <ul class="f-menu">
    <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
    <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
    <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    <li><a href="https://www.happypointcard.com/page/customer/term.spc">이용약관</a></li>
    <li><a href="https://www.spc.co.kr/share/right-mng/tip-off-intro/">윤리신고센터</a></li>
    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=E477ABF316702625A4017450F648607F">해피포인트</a></li>
    </ul>
    <div class="f-box clear">
    <ul class="f-sns">
      <li><a href="https://www.instagram.com/pascucci_kr/"><span class="hidden">인스타그램</span></a></li>
      <li><a href="https://blog.naver.com/pascucci1883"><span class="hidden">네이버블로그</span></a></li>
      <li><a href="https://www.youtube.com/channel/UCHKRIWTWjq0uzJOAm6KFHOg"><span class="hidden">유튜브</span></a></li>
      <li><a href="https://www.facebook.com/pascucci1883"><span class="hidden">페이스북</span></a></li>
    </ul>
    <div class="f-family"><span>FAMILY SITE</span>
      <ul class="f-family-wrap">
        <li><a href="https://www.pascucci.it/">파스쿠찌 이탈리아</a></li>
        <li><a href="https://www.happyconstore.com/">해피콘</a></li>
        <li><a href="https://www.happypointcard.com/page/main/index.spc">해피포인트카드</a></li>
        <li><a href="https://www.dunkindonuts.co.kr/">던킨도너츠</a></li>
        <li><a href="https://www.baskinrobbins.co.kr/">배스킨라빈스31</a></li>
        <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
        <li><a href="https://pariscroissantorder.com/">파리크라상</a></li>
        <li><a href="http://www.jambajuice.co.kr/">잠바주스</a></li>
        <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
      </ul>
    </div>
    <dl class="f-addr">
      <dt class="hidden">주소</dt>
      <dd><address>경기도 성남시 중원구 사기막골로 31번길 18</address></dd>
      <dt class="clear">사업자등록번호</dt>
      <dd>129-81-07244</dd>
      <dt>Fax</dt>
      <dd>0505-073-0210</dd>
      <dt>Tel</dt>
      <dd>080-731-2027</dd>
    </dl>
    <p class="f-copy clear">COPYRIGHT ⓒ 2023 CAFE PASCUCCI. ALL RIGHTS RESERVED.</p>
  </div>
</div>
</footer>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
