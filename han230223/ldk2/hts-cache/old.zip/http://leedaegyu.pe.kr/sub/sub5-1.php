<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>CAFFE PASCUCCI</title>
<link rel="stylesheet" href="http://leedaegyu.pe.kr/css/default.css?ver=2303229">
<link rel="stylesheet" href="http://leedaegyu.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<!--[if lte IE 8]>
<script src="http://leedaegyu.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://leedaegyu.pe.kr";
var g5_bbs_url   = "http://leedaegyu.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.caffe-pascucci.co.kr/">
<meta property="og:title" content="CAFFE PASCUCCI">
<meta property="og:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta property="og:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:url" content="https://www.caffe-pascucci.co.kr/">
<meta name="twitter:title" content="CAFFE PASCUCCI">
<meta name="twitter:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta name="twitter:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<script defer src="/js/default.js"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-1.12.4.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery.menu.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/common.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/wrest.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/placeholders.min.js?ver=2210172"></script>
</head>
<body>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<link rel="stylesheet" href="/css/sub-default.css">
<link rel="stylesheet" href="/css/sub5.css">

<script>
$(document).ready(function(){
  var menuUrl = window.location.href;
  if (menuUrl.includes('contact')) {
    $(".lnb-wrap li:nth-child(3)").addClass("on");
  }
});
</script>

<div class="skip-nav">
    <a href="#main-con">메인콘텐츠 바로가기</a>
</div>
<header class="header">
  <div class="inner">
    <h1 class="h-logo"><a href="http://leedaegyu.pe.kr/">카페 파스쿠찌</a></h1>
    <nav class="gnb">
     <ul>
        <li class="depth1"><a href="/sub/sub1-1.php"><span>BRAND</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub1-1.php"><span>카페 파스쿠찌</span></a></li>
            <li><a href="/sub/sub1-2.php"><span>커피 이야기</span></a></li>
            <li><a href="/sub/sub1-3.php"><span>에스프레소 바</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>MENU</span></a>
          <ul ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>시즌</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=coffee"><span>커피</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=beverage"><span>음료</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=food"><span>음식</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=product"><span>상품</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>STORE</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>매장찾기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=inquiry"><span>1:1 문의하기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=faq"><span>자주하는 질문</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>NEWS</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=sns"><span>SNS</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="/sub/sub5-1.php"><span>FRANCHISE</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
            <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
            <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
            <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="depth2-bg"></div>
    </nav>
    <nav class="tnb">
      <ul class="hd_login">        
                <li class="account">
          <a href="http://leedaegyu.pe.kr/bbs/register.php"><i class="xi-user-plus-o"></i>Sign&nbsp;Up</a>
        </li>
        <li class="login">
          <a href="http://leedaegyu.pe.kr/bbs/login.php"><i class="xi-log-in"></i>Sign&nbsp;In</a>
        </li>
            </ul>
    </nav>
  </div>
</header>
<main class="main" id="main-con">
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">FRANCHISE</p>
    </div>
  </section>
  <nav class="lnb inner">
    <ul class="lnb-wrap">
      <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
      <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
      <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
      <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
      <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
    </ul>
  </nav>
<script>
$(document).ready(function(){
  $(".lnb-wrap li:nth-child(1)").addClass("on");
});
</script>

<section class="sub-wrap competition">
  <header class="sub-header inner">
    <em class="sub-header-eng">Why Pascucci?</em>
    <h2 class="sub-header-tit">경쟁력</h2>
    <p class="sub-header-desc">
      가맹 대표님들은 왜 파스쿠찌를 선택했을까요?
    </p>
  </header>
  <article class="competition-item district">
    <div class="inner">
      <div class="competition-box">
        <em class="competition-num">01</em>
        <h3 class="franchise-tit">빅데이터 기반의 상권분석</h3>
        <p class="competition-txt">
          SPC그룹의 가맹점 6,500곳의 빅데이터가 담긴<br>상권분석 시스템(GCRM)을 통해 상권 분석을 진행합니다.<br>이후 창업지원센터의 심의절차를 통해 수익 중심의 입지인지 검증합니다.
        </p>
      </div>
      <figure class="district-img">
        <img src="/img/sub5-1-district.jpg" alt="">
        <figcaption>SPC <span>'GCRM'</span> System_SITE 분석</figcaption>
      </figure>
    </div>
  </article>
  <article class="competition-item training">
    <div class="inner">
      <div class="competition-box">
        <em class="competition-num">02</em>
        <h3 class="franchise-tit">체계화된 교육시스템</h3>
        <p class="competition-txt">
          파스쿠찌의 검증된 시스템을 바탕으로 지도해<br>
          서비스 품질을 유지하며, 가맹점과 상생합니다. 
        </p>
      </div>
      <ul class="training-wrap">
      <li class="training-item">
        <h4 class="training-tit">트레이닝 센터 상시 운영</h4>
        <p class="training-desc">
          실습장을 활용한 현장 교육과<br>
          점포 당 2인의 바리스타 양성 교육
        </p>
      </li>
      <li class="training-item">
        <h4 class="training-tit">가맹점 운영 교육</h4>
        <p class="training-desc">
          오픈 전 운영에 관한 교육,<br>오픈 후 7일간 전담 매니저 1:1 운영 지도
        </p>
      </li>
      <li class="training-item">
        <h4 class="training-tit">표준 매뉴얼 제작</h4>
        <p class="training-desc">
          전 영역 관리로 전국 어느 점포에서나<br>
          배움터 앱을 통한 교육 편의성 증가
        </p>
      </li>
      </ul>
    </div>
  </article>
  <article class="competition-item quality clear">
    <div class="inner">
      <div class="competition-box">
        <em class="competition-num">03</em>
        <h3 class="franchise-tit">혁신적인 R&D 및 품질관리</h3>
        <div class="competition-txt">
          <p>
            130년간 이어진 이탈리아의 전통을 바탕으로<br>최고 품질의 제품을 맞추기 위해 지속적인 연구와 개발을 이어갑니다.
          </p>
          <p>
            또한 식품전문기업 ‘SPC그룹’에서 자체 식품안전센터 운영하고<br>카페 브랜드중 유일하게 매일 배송이 가능합니다.
          </p>
        </div>
      </div>
      <figure class="quality-inno">
        <figcaption class="hidden">이노베이션 랩</figcaption>
        <img src="/img/sub5-1-quality-inno.jpg" alt="">
      </figure>
      <figure class="quality-safe">
        <figcaption class="hidden">식품안전센터</figcaption>
        <img src="/img/sub5-1-quality-safe.jpg" alt="">
      </figure>
    </div>
  </article>
  <article class="competition-item community">
    <div class="inner">
      <div class="competition-box">
        <em class="competition-num">04</em>
        <h3 class="franchise-tit">적극적인 커뮤니케이션</h3>
        <p class="competition-txt">
          차별화된 광고 캠페인과 제휴 마케팅 및 점포 이벤트 효과를 극대화시키고<br>보도자료, 영상이나 지면광고는 물론 SNS 채널을 이용해 고객과 밀접한 관계를 유지시켜 나갑니다.<br>또한 가맹점 대표와 본사 임직원 간 브랜드 전반 운영 계획을 논의하고 추가적인 지원을 하고 있습니다.
        </p>
      </div>
      <ul class="community-wrap">
        <li class="community-item">
          <div class="community-txt">
            <h4 class="community-tit">홍보 활동</h4>
            <p class="community-desc">여러 미디어를 통해 행사 효과 극대화</p>
          </div>
          <figure class="community-img">
            <figcaption class="hidden">파스쿠찌 광고 촬영 이미지</figcaption>
            <img src="/img/sub5-1-community1.jpg" alt="">
          </figure>
        </li>
        <li class="community-item">
          <div class="community-txt">
            <h4 class="community-tit">가맹점 지원</h4>
            <p class="community-desc">자녀 학자금 및 우수 점포 장려금 지급</p>
          </div>
          <figure class="community-img">
            <figcaption class="hidden">파스쿠찌의 슈퍼바이저랑 대화하는 가맹점주</figcaption>
            <img src="/img/sub5-1-community2.jpg" alt="">
          </figure>
        </li>
        <li class="community-item">
          <div class="community-txt">
            <h4 class="community-tit">제휴 마케팅</h4>
            <p class="community-desc">해피포인트 카드 등 다양한 할인, 적립의 혜택</p>
          </div>
          <figure class="community-img">
            <figcaption class="hidden">해피포인트, 현대오일뱅크, 기아멤버스카드</figcaption>
            <img src="/img/sub5-1-community3.png" alt="">
          </figure>
        </li>
      </ul>
    </div>
  </article>
  <div class="inner">
    <div class="franchise-more">
      <a href="/sub/sub5-2.php" class="franchise-more-btn">개설안내</a>
      <a href="/sub/sub5-3.php" class="franchise-more-btn">가맹문의</a>
    </div>
  </div>
</section>


</main>
<aside class="side" aria-hidden="true">
  <button type="button" class="side-btn side-top"></button>
  <a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact" class="side-btn side-talk"><span>가맹문의</span></a>
</aside>
<footer class="footer">
  <div class="inner">
    <p class="f-logo">카페 파스쿠찌</p>
    <ul class="f-menu">
    <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
    <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
    <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    <li><a href="https://www.happypointcard.com/page/customer/term.spc">이용약관</a></li>
    <li><a href="https://www.spc.co.kr/share/right-mng/tip-off-intro/">윤리신고센터</a></li>
    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=E477ABF316702625A4017450F648607F">해피포인트</a></li>
    </ul>
    <div class="f-box clear">
    <ul class="f-sns">
      <li><a href="https://www.instagram.com/pascucci_kr/"><span class="hidden">인스타그램</span></a></li>
      <li><a href="https://blog.naver.com/pascucci1883"><span class="hidden">네이버블로그</span></a></li>
      <li><a href="https://www.youtube.com/channel/UCHKRIWTWjq0uzJOAm6KFHOg"><span class="hidden">유튜브</span></a></li>
      <li><a href="https://www.facebook.com/pascucci1883"><span class="hidden">페이스북</span></a></li>
    </ul>
    <div class="f-family"><span>FAMILY SITE</span>
      <ul class="f-family-wrap">
        <li><a href="https://www.pascucci.it/">파스쿠찌 이탈리아</a></li>
        <li><a href="https://www.happyconstore.com/">해피콘</a></li>
        <li><a href="https://www.happypointcard.com/page/main/index.spc">해피포인트카드</a></li>
        <li><a href="https://www.dunkindonuts.co.kr/">던킨도너츠</a></li>
        <li><a href="https://www.baskinrobbins.co.kr/">배스킨라빈스31</a></li>
        <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
        <li><a href="https://pariscroissantorder.com/">파리크라상</a></li>
        <li><a href="http://www.jambajuice.co.kr/">잠바주스</a></li>
        <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
      </ul>
    </div>
    <dl class="f-addr">
      <dt class="hidden">주소</dt>
      <dd><address>경기도 성남시 중원구 사기막골로 31번길 18</address></dd>
      <dt class="clear">사업자등록번호</dt>
      <dd>129-81-07244</dd>
      <dt>Fax</dt>
      <dd>0505-073-0210</dd>
      <dt>Tel</dt>
      <dd>080-731-2027</dd>
    </dl>
    <p class="f-copy clear">COPYRIGHT ⓒ 2023 CAFE PASCUCCI. ALL RIGHTS RESERVED.</p>
  </div>
</div>
</footer>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
