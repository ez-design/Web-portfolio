<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>CAFFE PASCUCCI</title>
<link rel="stylesheet" href="http://leedaegyu.pe.kr/css/default.css?ver=2303229">
<link rel="stylesheet" href="http://leedaegyu.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<!--[if lte IE 8]>
<script src="http://leedaegyu.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://leedaegyu.pe.kr";
var g5_bbs_url   = "http://leedaegyu.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.caffe-pascucci.co.kr/">
<meta property="og:title" content="CAFFE PASCUCCI">
<meta property="og:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta property="og:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:url" content="https://www.caffe-pascucci.co.kr/">
<meta name="twitter:title" content="CAFFE PASCUCCI">
<meta name="twitter:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta name="twitter:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<script defer src="/js/default.js"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-1.12.4.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery.menu.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/common.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/wrest.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/placeholders.min.js?ver=2210172"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-default.css">
<link rel="stylesheet" href="/css/policy.css">

<div class="skip-nav">
    <a href="#main-con">메인콘텐츠 바로가기</a>
</div>
<header class="header">
  <div class="inner">
    <h1 class="h-logo"><a href="http://leedaegyu.pe.kr/">카페 파스쿠찌</a></h1>
    <nav class="gnb">
     <ul>
        <li class="depth1"><a href="/sub/sub1-1.php"><span>BRAND</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub1-1.php"><span>카페 파스쿠찌</span></a></li>
            <li><a href="/sub/sub1-2.php"><span>커피 이야기</span></a></li>
            <li><a href="/sub/sub1-3.php"><span>에스프레소 바</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>MENU</span></a>
          <ul ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>시즌</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=coffee"><span>커피</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=beverage"><span>음료</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=food"><span>음식</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=product"><span>상품</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>STORE</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>매장찾기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=inquiry"><span>1:1 문의하기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=faq"><span>자주하는 질문</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>NEWS</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=sns"><span>SNS</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="/sub/sub5-1.php"><span>FRANCHISE</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
            <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
            <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
            <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="depth2-bg"></div>
    </nav>
    <nav class="tnb">
      <ul class="hd_login">        
                <li class="account">
          <a href="http://leedaegyu.pe.kr/bbs/register.php"><i class="xi-user-plus-o"></i>Sign&nbsp;Up</a>
        </li>
        <li class="login">
          <a href="http://leedaegyu.pe.kr/bbs/login.php"><i class="xi-log-in"></i>Sign&nbsp;In</a>
        </li>
            </ul>
    </nav>
  </div>
</header>
<main class="main" id="main-con">
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">POLICY</p>
    </div>
  </section>
  <div class="inner">
  <nav class="lnb inner">
    <ul class="lnb-wrap">
      <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
      <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
      <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    </ul>
  </nav>
    
<script>
$(document).ready(function(){
  $(".lnb-wrap li:nth-child(3)").addClass("on");
});
</script>

<section class="sub-wrap policy inner">
  <header class="sub-header hidden">
    <h2 class="sub-header-tit">안전보건경영방침</h2>
    <div class="sub-header-desc">
      <p>
        (주)파리크라상은 행복한 나눔으로 국리민복에 기여하며 고객과 이해관계자,<br>모든 근로자의 만족을 이루기 위해 안전보건이 최우선적인 기업경영을 수립 및 실천하며<br>무재해를 달성하고 즐겁고 건강한 일터가 되도록 한다.
      </p>
      <p>
        당사의 제품, 활동 및 서비스의 전반적인 활동에 대한 안전보건 경영체제를<br>
        효율적으로 운영하기 위하여 다음과 같이 방침을 설정한다.
      </p>
    </div>
  </header>
  <ol class="hidden">
    <li>
      안전사고 예방을 위해 안전보건활동을 최우선적으로 이행하며<br>
      맡은 직무에서 책임과 역할을 철저히 수행한다.
    </li>
    <li>
      안전보건 법규를 철저히 준수하고 모든 사업장은 안전보건 기본원칙과<br>
      지침을 반드시 실천한다.
    </li>
    <li>
      안전보건 목표를 설정하여 검토, 모니터링 및 평가하며 지속적으로 개선한다.
    </li>
    <li>
      선제적 안전보건관리로 위험요인을 제거하여 중대재해가 발생하지 않도록 한다.
    </li>
    <li>
      근로자와 이해관계자는 함께 참여하는 안전보건을 위해<br>
      다양한 소통방식을 운영하고 실천하는 안전문화를 조성한다.
    </li>
  </ol>
  <p class="hidden">2022년 1월 1일</p>
  <strong class="hidden">(주)파리크라상 대표이사 황재복</strong>
  <figure class="safety-img"> 
    <figcaption class="hidden">위의 안전보건경영방침의 내용이 담긴 이미지 파일</figcaption>
    <img src="/img/policy-safety.jpg" alt="">
  </figure>
</section>

  </div>
</main>
<aside class="side" aria-hidden="true">
  <button type="button" class="side-btn side-top"></button>
  <a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact" class="side-btn side-talk"><span>가맹문의</span></a>
</aside>
<footer class="footer">
  <div class="inner">
    <p class="f-logo">카페 파스쿠찌</p>
    <ul class="f-menu">
    <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
    <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
    <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    <li><a href="https://www.happypointcard.com/page/customer/term.spc">이용약관</a></li>
    <li><a href="https://www.spc.co.kr/share/right-mng/tip-off-intro/">윤리신고센터</a></li>
    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=E477ABF316702625A4017450F648607F">해피포인트</a></li>
    </ul>
    <div class="f-box clear">
    <ul class="f-sns">
      <li><a href="https://www.instagram.com/pascucci_kr/"><span class="hidden">인스타그램</span></a></li>
      <li><a href="https://blog.naver.com/pascucci1883"><span class="hidden">네이버블로그</span></a></li>
      <li><a href="https://www.youtube.com/channel/UCHKRIWTWjq0uzJOAm6KFHOg"><span class="hidden">유튜브</span></a></li>
      <li><a href="https://www.facebook.com/pascucci1883"><span class="hidden">페이스북</span></a></li>
    </ul>
    <div class="f-family"><span>FAMILY SITE</span>
      <ul class="f-family-wrap">
        <li><a href="https://www.pascucci.it/">파스쿠찌 이탈리아</a></li>
        <li><a href="https://www.happyconstore.com/">해피콘</a></li>
        <li><a href="https://www.happypointcard.com/page/main/index.spc">해피포인트카드</a></li>
        <li><a href="https://www.dunkindonuts.co.kr/">던킨도너츠</a></li>
        <li><a href="https://www.baskinrobbins.co.kr/">배스킨라빈스31</a></li>
        <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
        <li><a href="https://pariscroissantorder.com/">파리크라상</a></li>
        <li><a href="http://www.jambajuice.co.kr/">잠바주스</a></li>
        <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
      </ul>
    </div>
    <dl class="f-addr">
      <dt class="hidden">주소</dt>
      <dd><address>경기도 성남시 중원구 사기막골로 31번길 18</address></dd>
      <dt class="clear">사업자등록번호</dt>
      <dd>129-81-07244</dd>
      <dt>Fax</dt>
      <dd>0505-073-0210</dd>
      <dt>Tel</dt>
      <dd>080-731-2027</dd>
    </dl>
    <p class="f-copy clear">COPYRIGHT ⓒ 2023 CAFE PASCUCCI. ALL RIGHTS RESERVED.</p>
  </div>
</div>
</footer>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
