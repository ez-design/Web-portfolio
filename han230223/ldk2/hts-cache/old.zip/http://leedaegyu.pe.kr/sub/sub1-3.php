<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>CAFFE PASCUCCI</title>
<link rel="stylesheet" href="http://leedaegyu.pe.kr/css/default.css?ver=2303229">
<link rel="stylesheet" href="http://leedaegyu.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<!--[if lte IE 8]>
<script src="http://leedaegyu.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://leedaegyu.pe.kr";
var g5_bbs_url   = "http://leedaegyu.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.caffe-pascucci.co.kr/">
<meta property="og:title" content="CAFFE PASCUCCI">
<meta property="og:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta property="og:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:url" content="https://www.caffe-pascucci.co.kr/">
<meta name="twitter:title" content="CAFFE PASCUCCI">
<meta name="twitter:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta name="twitter:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<script defer src="/js/default.js"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-1.12.4.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery.menu.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/common.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/wrest.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/placeholders.min.js?ver=2210172"></script>
</head>
<body>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<link rel="stylesheet" href="/css/sub-default.css">
<link rel="stylesheet" href="/css/sub1.css">

<div class="skip-nav">
    <a href="#main-con">메인콘텐츠 바로가기</a>
</div>
<header class="header">
  <div class="inner">
    <h1 class="h-logo"><a href="http://leedaegyu.pe.kr/">카페 파스쿠찌</a></h1>
    <nav class="gnb">
     <ul>
        <li class="depth1"><a href="/sub/sub1-1.php"><span>BRAND</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub1-1.php"><span>카페 파스쿠찌</span></a></li>
            <li><a href="/sub/sub1-2.php"><span>커피 이야기</span></a></li>
            <li><a href="/sub/sub1-3.php"><span>에스프레소 바</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>MENU</span></a>
          <ul ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>시즌</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=coffee"><span>커피</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=beverage"><span>음료</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=food"><span>음식</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=product"><span>상품</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>STORE</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>매장찾기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=inquiry"><span>1:1 문의하기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=faq"><span>자주하는 질문</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>NEWS</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=sns"><span>SNS</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="/sub/sub5-1.php"><span>FRANCHISE</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
            <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
            <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
            <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="depth2-bg"></div>
    </nav>
    <nav class="tnb">
      <ul class="hd_login">        
                <li class="account">
          <a href="http://leedaegyu.pe.kr/bbs/register.php"><i class="xi-user-plus-o"></i>Sign&nbsp;Up</a>
        </li>
        <li class="login">
          <a href="http://leedaegyu.pe.kr/bbs/login.php"><i class="xi-log-in"></i>Sign&nbsp;In</a>
        </li>
            </ul>
    </nav>
  </div>
</header>
<main class="main" id="main-con">
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">BRAND</p>
    </div>
  </section>
  <nav class="lnb inner">
    <ul class="lnb-wrap">
      <li><a href="/sub/sub1-1.php">카페 파스쿠찌</a></li>
      <li><a href="/sub/sub1-2.php">커피 이야기</a></li>
      <li><a href="/sub/sub1-3.php">에스프레소 바</a></li>
    </ul>
  </nav>

<script defer src="/js/sub1.js"></script>

<section class="sub-wrap bar">
  <header class="sub-header inner">
    <em class="sub-header-eng">ESPRESSO BAR</em>
    <h2 class="sub-header-tit">에스프레소 바</h2>
    <p class="sub-header-desc">
      이탈리아 정통 커피 브랜드 정체성을 그대로 살려 '에스프레소'에 집중한<br>파스쿠찌의 시그니처 에스프레소 바에서의 특별한 경험을 제공합니다.
    </p>
  </header>
  <article class="bar-item overview">
    <div class="inner">
      <h3 class="bar-tit">OVERVIEW</h3>
      <div class="bar-txt">
        <p>
          <em>'크레마'속 황금색</em>을 포인트로 한 인테리어 컬러와<br>개방된 바(Bar) 형태의 좌석으로 여러분이 보다<br>자유롭고 편안하게 커피를 즐길 수 있도록 고안하였습니다.
        </p>
        <p>
          맛과 향은 물론 개성까지 내세운 에스프레소 중심의 커피문화가<br>되기까지, 파스쿠찌의 시그니처 브랜드 ‘에스프레소 바’에서<br>에스프레소가 가진 본연의 매력을 느껴보세요.
        </p>
      </div>
      <div class="swiper overview-swiper">
        <div class="swiper-wrapper">
          <div class="swiper-slide overview-item1"></div>
          <div class="swiper-slide overview-item2"></div>
          <div class="swiper-slide overview-item3"></div>
          <div class="swiper-slide overview-item4"></div>
          <div class="swiper-slide overview-item5"></div>
        </div>
        <div class="overview-swiper-btn overview-prev"></div>
        <div class="overview-swiper-btn overview-next"></div>
      </div>
    </div>
  </article>
  <article class="bar-item choose">
    <div class="inner">
      <h3 class="bar-tit">CHOOSE VARIATION</h3>
      <ul class="choose-wrap">
        <li class="choose-item">
          <div class="choose-box">
            <h4 class="choose-tit">비체린</h4>
            <p class="choose-desc">
              누텔라와 에스프레소, 우유거품층이 섞인 전통 음료
            </p>
          </div>
          <figure class="choose-img">
            <img src="/img/sub1-3-choose-bicerin.png" alt="">
            <figcaption class="choose-eng">Bicerin</figcaption>
          </figure>
        </li>
        <li class="choose-item">
          <div class="choose-box">
            <h4 class="choose-tit">바닐라 빈 판나코타</h4>
            <p class="choose-desc">
              바닐라 빈 시드, 밀크를 활용한<br>판나코타, 에스프레소
            </p>
          </div>
          <figure class="choose-img">
            <img src="/img/sub1-3-choose-vanillabean.png" alt="">
            <figcaption class="choose-eng">Vanilla Bean Panna Cotta</figcaption>
          </figure>
        </li>
        <li class="choose-item">
          <div class="choose-box">
            <h4 class="choose-tit">콘 파나</h4>
            <p class="choose-desc">
              에스프레소,<br>부드러운 휘핑크림
            </p>
          </div>
          <figure class="choose-img">
            <img src="/img/sub1-3-choose-conpanna.png" alt="">
            <figcaption class="choose-eng">Con Panna</figcaption>
          </figure>
        </li>            
        <li class="choose-item">
          <div class="choose-box">
            <h4 class="choose-tit">아포가또</h4>
            <p class="choose-desc">
              에스프레소와 젤라또를 함께<br>즐기는 오리지널 아포가또
            </p>
          </div>
          <figure class="choose-img">
            <img src="/img/sub1-3-choose-affogato.png" alt="">
            <figcaption class="choose-eng">Affogato</figcaption>
          </figure>
        </li>
        <li class="choose-item">
          <div class="choose-box">
            <h4 class="choose-tit">스트라파짜토</h4>
            <p class="choose-desc">
              이탈리아 남부<br>나폴리 스타일 에스프레소
            </p>
          </div>
          <figure class="choose-img">
            <img src="/img/sub1-3-choose-strapazatto.png" alt="">
            <figcaption class="choose-eng">Strapazatto</figcaption>
          </figure>
        </li>
        <li class="choose-item">
          <div class="choose-box">
            <h4 class="choose-tit">모카</h4>
            <p class="choose-desc">
              에스프레소, 모카크림,<br>스팀밀크, 코코아 파우더
            </p>
          </div>
          <figure class="choose-img">
            <img src="/img/sub1-3-choose-mocha.png" alt="">
            <figcaption class="choose-eng">Mocha</figcaption>
          </figure>
        </li>
        <li class="choose-item">
          <div class="choose-box">
            <h4 class="choose-tit">에스프레시노</h4>
            <p class="choose-desc">
              에스프레소, 모카크림,<br>코코아 파우더
            </p>
          </div>
          <figure class="choose-img">
            <img src="/img/sub1-3-choose-espressino.png" alt="">
            <figcaption class="choose-eng">Espressino</figcaption>
          </figure>
        </li>
        <li class="choose-item">
          <div class="choose-box">
            <h4 class="choose-tit">돌체</h4>
            <p class="choose-desc">
              에스프레소와 생크림,<br>스팀밀크가 조화된 달달함
            </p>
          </div>
          <figure class="choose-img">
            <img src="/img/sub1-3-choose-dolce.png" alt="">
            <figcaption class="choose-eng">Dolce</figcaption>
          </figure>
        </li>
      </ul>
    </div>
  </article>
  <article class="bar-item centro clear">
    <div class="inner">
      <h3 class="bar-tit">CENTRO SEOUL</h3>
      <div class="bar-txt">
        <p>
          파스쿠찌 <em>센트로 서울</em>은 분주한 일상 속, 조용하고 아늑한 공간에서<br>커피 한 잔을 즐기며 삶에 대한 여유와 감사함을 느끼는 문화 공간입니다.<br>이곳에 온 모두가 삶에 대한 더 나은 영감과 새로운 취향을 발견하길 바랍니다.
        </p>
        <p>
          이를 돕기 위해 이탈리아 지역의 다양한 원료와 제품을 발굴하고,<br>오감으로 경험할 수 있는 콘텐츠를 더욱 다양하게 제안합니다.
        </p>
      </div>
      <figure class="centro-img">
        <figcaption class="hidden">센트로서울 서울대점</figcaption>
        <img src="/img/sub1-3-centro.jpg" alt="">
      </figure>
    </div>
  </article>
  <article class="bar-item store">
    <div class="inner">
      <h3 class="bar-tit">STORE</h3>
      <div class="swiper store-swiper">
        <ul class="swiper-wrapper">
          <li class="swiper-slide store-item">
            <a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store&wr_id=32#">
              <h4 class="store-tit">에스프레소 바 양재점</h4>
              <figure class="store-img">
                <img src="/img/sub1-3-store-1.jpg" alt="">
              </figure>
            </a>
          </li>
          <li class="swiper-slide store-item">
            <a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store&wr_id=35">
              <h4 class="store-tit">센트로 서울 서울점</h4>
              <figure class="store-img">
                <img src="/img/sub1-3-store-2.jpg" alt="">
              </figure>
            </a>
          </li>
          <li class="swiper-slide store-item">
            <a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store&wr_id=53">
              <h4 class="store-tit">에스프레소 바 해운대 엘시티점</h4>
              <figure class="store-img">
                <img src="/img/sub1-3-store-3.jpg" alt="">
              </figure>
            </a>
          </li>
          <li class="swiper-slide store-item">
            <a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store&wr_id=50">
              <h4 class="store-tit">센트로 서울 서울대점</h4>
              <figure class="store-img">
                <img src="/img/sub1-3-store-4.jpg" alt="">
              </figure>
            </a>
          </li>
          <li class="swiper-slide store-item">
            <a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store&wr_id=31">
              <h4 class="store-tit">에스프레소 바 인천 송도점</h4>
              <figure class="store-img">
                <img src="/img/sub1-3-store-5.jpg" alt="">
              </figure>
            </a>
          </li>
        </ul>
      </div>
        <div class="store-swiper-btn store-prev"></div>
        <div class="store-swiper-btn store-next"></div>
    </div>
  </article>
</section>


</main>
<aside class="side" aria-hidden="true">
  <button type="button" class="side-btn side-top"></button>
  <a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact" class="side-btn side-talk"><span>가맹문의</span></a>
</aside>
<footer class="footer">
  <div class="inner">
    <p class="f-logo">카페 파스쿠찌</p>
    <ul class="f-menu">
    <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
    <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
    <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    <li><a href="https://www.happypointcard.com/page/customer/term.spc">이용약관</a></li>
    <li><a href="https://www.spc.co.kr/share/right-mng/tip-off-intro/">윤리신고센터</a></li>
    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=E477ABF316702625A4017450F648607F">해피포인트</a></li>
    </ul>
    <div class="f-box clear">
    <ul class="f-sns">
      <li><a href="https://www.instagram.com/pascucci_kr/"><span class="hidden">인스타그램</span></a></li>
      <li><a href="https://blog.naver.com/pascucci1883"><span class="hidden">네이버블로그</span></a></li>
      <li><a href="https://www.youtube.com/channel/UCHKRIWTWjq0uzJOAm6KFHOg"><span class="hidden">유튜브</span></a></li>
      <li><a href="https://www.facebook.com/pascucci1883"><span class="hidden">페이스북</span></a></li>
    </ul>
    <div class="f-family"><span>FAMILY SITE</span>
      <ul class="f-family-wrap">
        <li><a href="https://www.pascucci.it/">파스쿠찌 이탈리아</a></li>
        <li><a href="https://www.happyconstore.com/">해피콘</a></li>
        <li><a href="https://www.happypointcard.com/page/main/index.spc">해피포인트카드</a></li>
        <li><a href="https://www.dunkindonuts.co.kr/">던킨도너츠</a></li>
        <li><a href="https://www.baskinrobbins.co.kr/">배스킨라빈스31</a></li>
        <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
        <li><a href="https://pariscroissantorder.com/">파리크라상</a></li>
        <li><a href="http://www.jambajuice.co.kr/">잠바주스</a></li>
        <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
      </ul>
    </div>
    <dl class="f-addr">
      <dt class="hidden">주소</dt>
      <dd><address>경기도 성남시 중원구 사기막골로 31번길 18</address></dd>
      <dt class="clear">사업자등록번호</dt>
      <dd>129-81-07244</dd>
      <dt>Fax</dt>
      <dd>0505-073-0210</dd>
      <dt>Tel</dt>
      <dd>080-731-2027</dd>
    </dl>
    <p class="f-copy clear">COPYRIGHT ⓒ 2023 CAFE PASCUCCI. ALL RIGHTS RESERVED.</p>
  </div>
</div>
</footer>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
