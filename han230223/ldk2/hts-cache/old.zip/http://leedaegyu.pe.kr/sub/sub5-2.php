<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>CAFFE PASCUCCI</title>
<link rel="stylesheet" href="http://leedaegyu.pe.kr/css/default.css?ver=2303229">
<link rel="stylesheet" href="http://leedaegyu.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=2303229">
<!--[if lte IE 8]>
<script src="http://leedaegyu.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://leedaegyu.pe.kr";
var g5_bbs_url   = "http://leedaegyu.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.caffe-pascucci.co.kr/">
<meta property="og:title" content="CAFFE PASCUCCI">
<meta property="og:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta property="og:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:url" content="https://www.caffe-pascucci.co.kr/">
<meta name="twitter:title" content="CAFFE PASCUCCI">
<meta name="twitter:description" content="스토리를 마시는 일상, 카페 파스쿠찌">
<meta name="twitter:image" content="https://www.spcmagazine.com/wp-content/uploads/2019/06/PAS_ext-9331CR.jpg">
<link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico">
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<script defer src="/js/default.js"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-1.12.4.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/jquery.menu.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/common.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/wrest.js?ver=2210172"></script>
<script src="http://leedaegyu.pe.kr/js/placeholders.min.js?ver=2210172"></script>
</head>
<body>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<link rel="stylesheet" href="/css/sub-default.css">
<link rel="stylesheet" href="/css/sub5.css">

<script>
$(document).ready(function(){
  var menuUrl = window.location.href;
  if (menuUrl.includes('contact')) {
    $(".lnb-wrap li:nth-child(3)").addClass("on");
  }
});
</script>

<div class="skip-nav">
    <a href="#main-con">메인콘텐츠 바로가기</a>
</div>
<header class="header">
  <div class="inner">
    <h1 class="h-logo"><a href="http://leedaegyu.pe.kr/">카페 파스쿠찌</a></h1>
    <nav class="gnb">
     <ul>
        <li class="depth1"><a href="/sub/sub1-1.php"><span>BRAND</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub1-1.php"><span>카페 파스쿠찌</span></a></li>
            <li><a href="/sub/sub1-2.php"><span>커피 이야기</span></a></li>
            <li><a href="/sub/sub1-3.php"><span>에스프레소 바</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>MENU</span></a>
          <ul ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=season"><span>시즌</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=coffee"><span>커피</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=beverage"><span>음료</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=food"><span>음식</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=product"><span>상품</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>STORE</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=store"><span>매장찾기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=inquiry"><span>1:1 문의하기</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=faq"><span>자주하는 질문</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>NEWS</span></a>
          <ul class="depth2">
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/board.php?bo_table=sns"><span>SNS</span></a></li>
          </ul>
        </li>
        <li class="depth1"><a href="/sub/sub5-1.php"><span>FRANCHISE</span></a>
          <ul class="depth2">
            <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
            <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
            <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
            <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
            <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
          </ul>
        </li>
      </ul>
      <div class="depth2-bg"></div>
    </nav>
    <nav class="tnb">
      <ul class="hd_login">        
                <li class="account">
          <a href="http://leedaegyu.pe.kr/bbs/register.php"><i class="xi-user-plus-o"></i>Sign&nbsp;Up</a>
        </li>
        <li class="login">
          <a href="http://leedaegyu.pe.kr/bbs/login.php"><i class="xi-log-in"></i>Sign&nbsp;In</a>
        </li>
            </ul>
    </nav>
  </div>
</header>
<main class="main" id="main-con">
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">FRANCHISE</p>
    </div>
  </section>
  <nav class="lnb inner">
    <ul class="lnb-wrap">
      <li><a href="/sub/sub5-1.php"><span>경쟁력</span></a></li>
      <li><a href="/sub/sub5-2.php"><span>개설안내</span></a></li>
      <li><a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact"><span>가맹문의</span></a></li>
      <li><a href="/sub/sub5-4.php"><span>디자인 타입</span></a></li>
      <li><a href="/sub/sub5-5.php"><span>가맹설명회</span></a></li>
    </ul>
  </nav>
<script>
$(document).ready(function(){
  $(".lnb-wrap li:nth-child(2)").addClass("on");
});
</script>

<section class="sub-wrap guide inner">
  <header class="sub-header">
    <em class="sub-header-eng">Open Guide</em>
    <h2 class="sub-header-tit">개설안내</h2>
    <p class="sub-header-desc">
      프랜차이즈 가맹의 모든 준비과정은 약 60일 소요됩니다.
    </p>
  </header>
  <article class="step">
    <h3 class="franchise-tit">개설 절차</h3>
    <ul class="step-wrap">
      <li>
        <span class="step-num">STEP 01</span>
        <p class="step-tit">창업의뢰</p>
      </li>
      <li>
        <span class="step-num">STEP 02</span>
        <p class="step-tit">시장조사</p>
      </li>
      <li>
        <span class="step-num">STEP 03</span>
        <p class="step-tit">창업승인</p>
      </li>
      <li>
        <span class="step-num">STEP 04</span>
        <p class="step-tit">점포계약</p>
      </li>
      <li>
        <span class="step-num">STEP 05</span>
        <p class="step-tit">인테리어 설계, 실측</p>
      </li>
      <li>
        <span class="step-num">STEP 06</span>
        <p class="step-tit">인테리어 시공</p>
      </li>
      <li>
        <span class="step-num">STEP 07</span>
        <p class="step-tit">가맹점주 교육</p>
      </li>
      <li>
        <span class="step-num">STEP 08</span>
        <p class="step-tit">개점준비 및 교육</p>
      </li>
      <li>
        <p class="step-tit">GRAND OPEN</p>
      </li>
    </ul>
  </article>
  <article class="cost clear">
    <h3 class="franchise-tit">상세 투자 내역</h3>
    <em class="cost-info">132㎡(40평 기준) / 단위:만원(VAT별도)</em>
    <table class="cost-table">
      <colgroup>
        <col class="cost-col1">
        <col class="cost-col2">
        <col>
      </colgroup>
      <caption class="hidden">상세 투자 내역표</caption>
      <thead>
        <tr>
          <th>구분</th>
          <th>단가</th>
          <th>비고</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>개점비</th>
          <td>1,000</td>
          <td>소멸성 비용</td>
        </tr>
        <tr>
          <th>기획 관리비</th>
          <td>300</td>
          <td>공사 관리, 감독비용</td>
        </tr>
        <tr>
          <th>교육비</th>
          <td>150</td>
          <td>2주과정(이론1주/ 실습1주), 점주포함 2명 입과</td>
        </tr>
        <tr>
          <th>계약이행보증금</th>
          <td>1,000</td>
          <td>계약 종료 시 반환, VAT없음</td>
        </tr>
        <tr>
          <th>인테리어</th>
          <td>약 9,000</td>
          <td>약 2,200평/ 3.3㎡당(외부 및 기타 공사 미포함)</td>
        </tr>
        <tr>
          <th>간판/사인물</th>
          <td>약 1,000</td>
          <td>전면 7m기준(어닝 공사 별도)</td>
        </tr>
        <tr>
          <th>장비/가구류</th>
          <td>약 10,300</td>
          <td>커피머신, 케익쇼케이스, 가구, 집기류 등</td>
        </tr>
        <tr>
          <th>최초 공급 상품 비용</th>
          <td>약 500</td>
          <td>제품 등 초도 물량 비용(점포환경에 따라 유동적)</td>
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <th>총계</th>
          <td>23,250</td>
          <td>구매 형태에 따라 상이함, 에어컨 및 전기 증설 제외</td>
        </tr>
      </tfoot>
    </table>
  </article>
  <div class="franchise-more">
    <a href="/sub/sub5-1.php" class="franchise-more-btn">경쟁력</a>
    <a href="/sub/sub5-3.php" class="franchise-more-btn">가맹문의</a>
  </div>
</section>


</main>
<aside class="side" aria-hidden="true">
  <button type="button" class="side-btn side-top"></button>
  <a href="http://leedaegyu.pe.kr/bbs/write.php?bo_table=contact" class="side-btn side-talk"><span>가맹문의</span></a>
</aside>
<footer class="footer">
  <div class="inner">
    <p class="f-logo">카페 파스쿠찌</p>
    <ul class="f-menu">
    <li><a href="/sub/policy1.php">개인정보처리방침</a></li>
    <li><a href="/sub/policy2.php">영상정보처리기기운영·관리방침</a></li>
    <li><a href="/sub/policy3.php">안전보건경영방침</a></li>
    <li><a href="https://www.happypointcard.com/page/customer/term.spc">이용약관</a></li>
    <li><a href="https://www.spc.co.kr/share/right-mng/tip-off-intro/">윤리신고센터</a></li>
    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=E477ABF316702625A4017450F648607F">해피포인트</a></li>
    </ul>
    <div class="f-box clear">
    <ul class="f-sns">
      <li><a href="https://www.instagram.com/pascucci_kr/"><span class="hidden">인스타그램</span></a></li>
      <li><a href="https://blog.naver.com/pascucci1883"><span class="hidden">네이버블로그</span></a></li>
      <li><a href="https://www.youtube.com/channel/UCHKRIWTWjq0uzJOAm6KFHOg"><span class="hidden">유튜브</span></a></li>
      <li><a href="https://www.facebook.com/pascucci1883"><span class="hidden">페이스북</span></a></li>
    </ul>
    <div class="f-family"><span>FAMILY SITE</span>
      <ul class="f-family-wrap">
        <li><a href="https://www.pascucci.it/">파스쿠찌 이탈리아</a></li>
        <li><a href="https://www.happyconstore.com/">해피콘</a></li>
        <li><a href="https://www.happypointcard.com/page/main/index.spc">해피포인트카드</a></li>
        <li><a href="https://www.dunkindonuts.co.kr/">던킨도너츠</a></li>
        <li><a href="https://www.baskinrobbins.co.kr/">배스킨라빈스31</a></li>
        <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
        <li><a href="https://pariscroissantorder.com/">파리크라상</a></li>
        <li><a href="http://www.jambajuice.co.kr/">잠바주스</a></li>
        <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
      </ul>
    </div>
    <dl class="f-addr">
      <dt class="hidden">주소</dt>
      <dd><address>경기도 성남시 중원구 사기막골로 31번길 18</address></dd>
      <dt class="clear">사업자등록번호</dt>
      <dd>129-81-07244</dd>
      <dt>Fax</dt>
      <dd>0505-073-0210</dd>
      <dt>Tel</dt>
      <dd>080-731-2027</dd>
    </dl>
    <p class="f-copy clear">COPYRIGHT ⓒ 2023 CAFE PASCUCCI. ALL RIGHTS RESERVED.</p>
  </div>
</div>
</footer>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
