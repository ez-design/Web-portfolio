<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>그누보드5</title>
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/css/default.css?ver=220620">
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/theme/basic/skin/latest/pic_block/style.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://lee-song-yi.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://lee-song-yi.pe.kr";
var g5_bbs_url   = "http://lee-song-yi.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="keywords" content="밀크티, 버블티, 커피, 디저트, 차, 홍차"/> 
  <meta name="description" content="자연의 찻집 팔공티입니다."/>

  <meta property="og:title" content="팔공티-PALGONGTEA"/>
  <meta property="og:type" content="website"/>
  <meta property="og:description" content="PALGONGTEA 밀크티가 맛있는 카페입니다.">
  <meta property="og:image" content="img/og.png">
<script src="http://lee-song-yi.pe.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/common.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/wrest.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

  <link rel="stylesheet" href="/css/index.css">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />  

  <script src="https://kit.fontawesome.com/979b8c848e.js" crossorigin="anonymous"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="js/jquery.vide.js"></script>


<!-- 상단 시작 { -->

<div id="skip-nav"><a href="#container">본문 바로가기</a></div>
<header id="header">
  <div class="inner">
    <h1 class="logo"><a href="/index.php">logo</a></h1>
    <ul class="gnb">
      <li class="depth1"><a href="/sub/sub1-1.php">브랜드소개</a>
        <ul class="depth2">
          <li><a href="/sub/sub1-1.php">팔공티소개</a></li>
          <li><a href="/sub/sub1-2.php">연혁</a></li>
          <li><a href="/sub/sub1-3.php">오시는길</a></li>
          <li><a href="/sub/sub1-4.php">해외사업</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">메뉴</a>
        <ul class="depth2">
          <li><a href="/sub/sub2-1.php">주문TIP</a></li>
          <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub3-1.php">창업문의</a>
        <ul class="depth2">
          <li><a href="/sub/sub3-1.php">가맹절차</a></li>
          <li><a href="/sub/sub3-2.php">인테리어</a></li>
          <li><a href="/sub/sub3-3.php">가맹비용</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담신청</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">매장안내</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내매장</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외매장</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub5-1.php">멤버십</a>
        <ul class="depth2">
          <li><a href="/sub/sub6-1.php">팔공티APP</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">팔공티소식</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">고객문의</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드제휴</a></li>
        </ul>
      </li>
    </ul>
    <div class="tnb">
      <ul class="login-box">        
                <li class="join"><a href="http://lee-song-yi.pe.kr/bbs/register.php">회원가입</a></li>
        <li class="login"><a href="http://lee-song-yi.pe.kr/bbs/login.php">로그인</a></li>
              </ul>
      <nav class="allmenu">
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
      </nav>
      <div class="allmenu-wrap">
        <p>All Menu</p>
        <ul class="allmenu-box">
          <li class="allmenu-depth1">
            <a href="#"><p>브랜드 소개</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub1-1.php">팔공티 소개</a></li>
              <li><a href="/sub/sub1-2.php">연혁</a></li>
              <li><a href="/sub/sub1-3.php">오시는 길</a></li>
              <li><a href="/sub/sub1-4.php">해외 사업</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="#"><p>메뉴</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub2-1.php">주문 TIP</a></li>
              <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴/신메뉴</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub3-1.php"><p>창업 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub3-1.php">가맹 절차</a></li>
              <li><a href="/sub/sub3-2.php">인테리어</a></li>
              <li><a href="/sub/sub3-3.php">가맹 비용</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map"><p>매장 안내</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내 매장</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외 매장</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub5-1.php"><p>멤버쉽</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub6-1.php">팔공티 APP</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice"><p>팔공티 소식</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand"><p>고객 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드 제휴</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <script>
    var allBtn = $('.allmenu');
        allBtn.each(function(index){
        var $this = $(this);
          $this.on('click', function(e){
            e.preventDefault();
            $(this).toggleClass('active');
          });
        });
    var depth1 = $('.allmenu-depth1');
        depth1.each(function(index){
    var $this = $(this);
        $('.allmenu-depth1 > a').on('click', function(e){
          e.preventDefault();
          $('.allmenu-depth1').removeClass('on');
          $(this).parent().toggleClass('on');
        });
    });
  </script>
</header>
<!-- } 상단 끝 -->


<hr>

<!-- 콘텐츠 시작 { -->
<main id="main">
  
<nav class="hidden">메인 콘텐츠</nav>
  <section class="visual" data-vide-bg="/mov/visual-mov.mp4">
    <div class="inner">
      <p class="visual-tit">기분 좋은 하루의 시작,</p>
      <span class="visual-txt">Coffee doesn't ask silly questions, Coffe understand.</span>
    </div>
  </section>
  <section class="menu sec">
    <div class="menu-inner inner">
      <h2 class="tit">PALGONGTEA MENU</h2>
      <p class="desc">팔공티의 대표 메뉴와 시즌 메뉴를 알아보세요.</p>
      <div class="menu-wrap">
        <div class="menu-tab-signature menu-tab">
          <strong class="signature-name menu-name">Signature Menu</strong>
          <div class="manu-tab-box swiper mySwiper">
            <div class="menu-tab-wrap swiper-wrapper">
              <div class="swiper-slide">
                <p>블랙 밀크티(ICE)</p>
                <span>진하고 감미로운 홍차와<br>쫀득한 타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=18" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p>블랙 밀크티(HOT)</p>
                <span>진하고 감미로운 홍차 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=17" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="garlgrey-ice-tit">얼그레이 밀크티(ICE)</p>
                <span class="garlgrey-ice-txt">베르가못 향이 감도는 티와<br>타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=16" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="garlgrey-hot-tit">얼그레이밀크티(HOT)</p>
                <span class="garlgrey-hot-txt">베르가못 향이 감도는 티 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=15" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="woolong-ice-tit">우롱 밀크티(ICE)</p>
                <span class="woolong-ice-txt">깊고 구수한 향이 감도는 티와 쫀득한 타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=14" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="woolong-hot-tit">우롱밀크티(HOT)</p>
                <span class="woolong-hot-txt">깊고 구수한 향이 감도는 티 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=13" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="Jasminum-ice-tit">자스민 그린 밀크티(ICE)</p>
                <span class="Jasminum-ice-txt">꽃잎 향이 감도는 티와 쫀득한 타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=12" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="Jasminum-hot-tit">자스민 그린 밀크티(HOT)</p>
                <span class="Jasminum-hot-txt">꽃잎 향이 감도는 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=11" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="dolce-ice-tit">돌체 블랙 밀크티(ICE)</p>
                <span class="dolce-ice-txt">프리미엄 시럽을 추가하여, 밸런스 잡힌 깔끔한 단맛의 블랙 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=10&page=2" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="dolce-hot-tit">돌체 블랙 밀크티(HOT)</p>
                <span class="dolce-hot-txt">프리미엄 시럽을 추가하여, 밸런스 잡힌 깔끔한 단맛의 블랙 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=9&page=2" class="btn">더 알아보기</a>
              </div>
            </div>
          </div>
        </div>
        <div class="menu-tab-season menu-tab">
          <strong class="season-name menu-name">Season Menu</strong>
          <div class="manu-tab-box swiper mySwiper">
            <div class="menu-tab-wrap swiper-wrapper">
              <div class="swiper-slide">
                <p class="sweetpotato-ice-tit">자색 군고구마 밀크티(ICE)</p>
                <span class="sweetpotato-ice-txt">군고구마의 풍미를 살리고<br>타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season&wr_id=11" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="sweetpotato-hot-tit">자색 군고구마 밀크티(HOT)</p>
                <span class="sweetpotato-hot-txt">군고구마의 풍미를 살린<br>달콤한 맛의 군고구마 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season&wr_id=10" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="sweetpotato-ice-tit">초당 옥수수 밀크티(ICE)</p>
                <span class="sweetpotato-ice-txt">옥수수의 단맛에<br>타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season&wr_id=9" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="sweetpotato-hot-tit">초당 옥수수 밀크티(HOT)</p>
                <span class="sweetpotato-hot-txt">초당 옥수수의 풍미를 살린 달콤한 맛의 옥수수 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season&wr_id=8" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="sweetpotato-ice-tit">치즈폼 군고구마라떼(ICE)</p>
                <span class="sweetpotato-ice-txt">군고구마의 풍미를 살리고, 고소한 치즈폼이 올라간 달콤하고 시원한 고구마 라떼.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season&wr_id=7" class="btn">더 알아보기</a>
              </div>
              <div class="swiper-slide">
                <p class="sweetpotato-hot-tit">치즈폼 군고구마라떼(HOT)</p>
                <span class="sweetpotato-hot-txt">군고구마의 풍미를 살리고, 고소한 치즈폼이 올라간 달콤하고 따뜻한 고구마 라떼.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season&wr_id=6" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="sweetpotato-ice-tit">치즈폼 초당 옥수수라떼(ICE)</p>
                <span class="sweetpotato-ice-txt">초당 옥수수의 단맛이 가득하고, 고소한 치즈폼이 올라간 시원한 옥수수 라떼.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season&wr_id=5" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="sweetpotato-hot-tit">치즈폼 초당 옥수수라떼(HOT)</p>
                <span class="sweetpotato-hot-txt">초당 옥수수의 단맛이 가득하고, 고소한 치즈폼이 올라간 옥수수 라떼.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season&wr_id=4" class="btn">더 알아보기</a> 
              </div>
            </div>
          </div>
        </div>
        <div class="menu-tab-all menu-tab">
          <strong class="all-name menu-name">All Menu</strong>
          <div class="manu-tab-box swiper mySwiper">
            <div class="menu-tab-wrap swiper-wrapper">
              <div class="swiper-slide">
                <p class="black-ice-tit">블랙 밀크티(ICE)</p>
                <span class="black-ice-txt">감미로운 홍차와 타피오카<br>펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=18" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="black-hot-tit">블랙밀크티(HOT)</p>
                <span class="black-hot-txt">진하고 감미로운 홍차 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=17" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="garlgrey-ice-tit">얼그레이 밀크티(ICE)</p>
                <span class="garlgrey-ice-txt">베르가못 향이 감도는 티와<br>쫀득한 타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=16" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="garlgrey-hot-tit">얼그레이밀크티(HOT)</p>
                <span class="garlgrey-hot-txt">은은하게 베르가못 향이 감도는 티 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=15" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="woolong-ice-tit">우롱 밀크티(ICE)</p>
                <span class="woolong-ice-txt">깊고 구수한 향이 감도는 티와 쫀득한 타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=14" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="woolong-hot-tit">우롱밀크티(HOT)</p>
                <span class="woolong-hot-txt">깊고 구수한 향이 감도는 티 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=13" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="Jasminum-ice-tit">자스민 그린 밀크티(ICE)</p>
                <span class="Jasminum-ice-txt">꽃잎 향이 감도는 티와 쫀득한 타피오카 펄이 어우러진 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=12" class="btn">더 알아보기</a> 
              </div>
              <div class="swiper-slide">
                <p class="Jasminum-hot-tit">자스민 그린 밀크티(HOT)</p>
                <span class="Jasminum-hot-txt">꽃잎 향이 감도는 밀크티.</span>
                <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery&wr_id=11" class="btn">더 알아보기</a> 
              </div>
            </div>
          </div>
        </div>
      </div>
      <aside class="leaves" >
        <div class="inner">
          <figure class="leaves1"><img src="img/leaves1.png" alt="#"></figure>
          <figure class="leaves2"><img src="img/leaves2.png" alt="#"></figure>
          <figure class="leaves3"><img src="img/leaves3.png" alt="#"></figure>
          <figure class="circle"><img src="img/circle-text.png" alt="#"></figure>
        </div>
      </aside>
    </div>
  </section>
  <section class="quick sec">
    <div class="inner">
      <h2 class="tit">QUICK MENU</h2>
      <p class="desc">팔공티의 가맹점 안내입니다.</p>
      <div class="quick-wrap">
        <article class="quick-wrap-founding">
          <dl class="founding-box">
            <dt class="founding-tit"><a href="/sub/sub3-1.php">가맹 절차</a></dt>
            <dd class="founding-txt">가맹 절차 안내입니다.</dd>
          </dl>
        </article>
        <article class="quick-wrap-join">
          <dl class="join-box">
            <dt class="join-tit"><a href="/sub/sub3-3.php">가맹 비용</a></dt>
            <dd class="join-txt">가맹 비용 안내입니다.</dd>
          </dl>
        </article>
        <article class="quick-wrap-market">
          <dl class="market-box">
            <dt class="market-tit"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">매장 안내</a></dt>
            <dd class="market-txt">전국 각지의 팔공티 매장 안내입니다.</dd>
          </dl>
        </article>
        <article class="quick-wrap-shop">
          <dl class="shop-box">
            <dt class="shop-tit"><a href="#">브랜드 제휴</a></dt>
            <dd class="shop-txt">브랜드 제휴 문의 안내입니다.</dd>
          </dl>
        </article>
      </div>
    </div>
    <aside class="quick-leaves" >
      <div class="inner">
        <figure class="quick-leaves1"><img src="img/quick-leaves1.png" alt="#"></figure>
        <figure class="quick-leaves2"><img src="img/quick-leaves2.png" alt="#"></figure>
        <figure class="quick-leaves3"><img src="img/quick-leaves3.png" alt="#"></figure>
      </div>
    </aside>
  </section>
  <section class="open sec">
    <div class="inner">
      <div class="open-wrap">
        <h2 class="open-tit">PALGONGTEA</h2>
        <div class="open-desc">신규 오픈 매장</div>
        <p class="open-txt">팔공티의 새롭게 오픈한 매장을<br>빠르게 확인해 보세요!</p>
        <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">VIEW MORE</a>
      </div>
      <div class="open-slide-box-wrap">
        <div class="open-slide-box mySwiper2">
          <div class="open-slide swiper-wrapper">
            <article class="open-slide-daegu swiper-slide">
              <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map&wr_id=32" class="open-tit-wrap">
                <h3 class="slide-tit">PALGONGTEA</h3>
                <p class="slide-desc">대구구지점</p>
              </a>
              <figure class="slide-img"><img src="img/daegoo.png" alt="#"></figure>
            </article>
            <article class="open-slide-jeju swiper-slide">
              <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map&wr_id=33" class="open-tit-wrap">
                <h3 class="slide-tit">PALGONGTEA</h3>
                <p class="slide-desc">제주노형점</p>
              </a>
              <figure class="slide-img"><img src="img/nohyeong.png" alt="#"></figure>
            </article>
            <article class="open-slide-junju swiper-slide">
              <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map&wr_id=34" class="open-tit-wrap">
                <h3 class="slide-tit">PALGONGTEA</h3>
                <p class="slide-desc">전주만성점</p>
              </a>
              <figure class="slide-img"><img src="img/mansung.png" alt="#"></figure>
            </article>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="commu sec">
    <div class="inner">
      <h2 class="tit">PALGONGTEA NOTICE</h2>
      <p class="desc">팔공티의 공지사항을 안내합니다.</p>
      <div class="commu-wrap">
        
<div class="pic_lt">
    <ul>
            <li class="galley_li">
            <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice&amp;wr_id=14" class="lt_img"><img src="http://lee-song-yi.pe.kr/data/file/notice/thumb-124ff4517aaeb5ce12c71ca6b4e78089_jMnHfGsY_68b17db379d3e88ab2c293f0be9fccf0dcf73391_210x150.jpg" alt="" ></a>
            <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice&amp;wr_id=14"> 팔공티 서포터즈 6기 모집</a>
        </li>
            <li class="galley_li">
            <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice&amp;wr_id=13" class="lt_img"><img src="http://lee-song-yi.pe.kr/data/file/notice/thumb-124ff4517aaeb5ce12c71ca6b4e78089_RMWzVOiq_d4c871c5d4ef27e27fb8e114b47876e9b768a2b1_210x150.jpg" alt="" ></a>
            <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice&amp;wr_id=13"> 팔공티 App 출시 후 적립 서비스 변경</a>
        </li>
            <li class="galley_li">
            <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice&amp;wr_id=12" class="lt_img"><img src="http://lee-song-yi.pe.kr/data/file/notice/thumb-124ff4517aaeb5ce12c71ca6b4e78089_0KF5NZSW_1ca6b7c2215b036847d1ed962fa33b6d3ecce050_210x150.jpg" alt="" ></a>
            <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice&amp;wr_id=12"> 팔공티 서포터즈 에이티 5기 종료</a>
        </li>
            </ul>
    <a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice" class="lt_more"><span class="sound_only">공지사항</span>더보기</a>

</div>
      </div>
    </div>
  </section>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

    <!-- Initialize Swiper -->
    <script>
      var swiper = new Swiper(".mySwiper", {
        slidesPerView: 3,
        spaceBetween: 10,
        autoplay: {     //자동슬라이드 (false-비활성화)
          delay: 2500, // 시간 설정
          disableOnInteraction: false, // false-스와이프 후 자동 재생
        },

        loop : false,   // 슬라이드 반복 여부

        loopAdditionalSlides : 1,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        breakpoints: {
          "@0.00": {
            slidesPerView: 1,
            spaceBetween: 10,
          },
          "@0.75": {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          "@1.00": {
            slidesPerView: 3,
            spaceBetween: 40,
          },
        },
      });
    </script>
    <script>
      var swiper = new Swiper(".mySwiper2", {
        slidesPerView : 'auto', // 한 슬라이드에 보여줄 갯수
        spaceBetween: 10,
        autoplay: {     //자동슬라이드 (false-비활성화)
          delay: 2500, // 시간 설정
          disableOnInteraction: false, // false-스와이프 후 자동 재생
        },
        loop : false,   // 슬라이드 반복 여부
        loopAdditionalSlides : 1,
      });
    </script>
    <script>
      $(function(){
        $('.menu-name').on('click' , function(){
            $('.manu-tab-box').hide();
            $(this).next().show()
        })
    });
    $(function(){
          $('.commu-tab-click').on('click' , function(){
              $('.commu-tab-box').hide();
              $(this).next().show()
          })
      });
    </script>
</section>
<!-- } 콘텐츠 끝 -->

<hr>

<!-- 하단 시작 { -->
<footer id="footer">
  <div class="inner">
    <h4 class="f-logo"><a href="#">logo</a></h4>
    <ul class="f-menu">
      <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
      <li><a href="/sub/sub-f-terms.php">이용약관</a></li>
      <li><a href="/sub/sub-f-collection.php">이메일무단수집거부</a></li>
      <li><a href="/sub/sub1-3.php">오시는길</a></li>
    </ul>
    <div class="f-hours">
      <ul class="f-open">OPENING HOURS
        <li>MON-FRI</li>
        <li>09:00 AM ~ 06:00 PM</li>
        <li>주말, 공휴일 휴무</li>
      </ul>
      <ul class="f-sns">
        <li><a href="https://ko-kr.facebook.com/Palgongtea.official/">페이스북</a></li>
        <li><a href="https://www.instagram.com/palgongtea.official/">인스타그램</a></li>
        <li><a href="https://blog.naver.com/palgongtea_official">네이버블로그</a></li>
      </ul>
    </div>
    <div class="f-adrr">
      <ul class="f-number">
        <li>사업자번호 669-88-01126</li>
        <li>㈜팔공티 대표이사 김종현</li>
      </ul>
      <ul class="f-txt">
        <li><adrress>주소 : 서울 강남구 밤고개로1길 10, 현대벤처빌 1822호 팔공티</adrress></li>
        <li>연락처 : 02-6928-8286</li>
        <li>이메일 : palgongtea@palgongtea.com</li>
      </ul>
      <p class="f-copy">ⓒ 2021 PALGONG TEA All rights reserved.</p>
    </div>
  </div>
</footer>
<!-- } 하단 끝 -->
<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
