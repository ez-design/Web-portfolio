<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>그누보드5</title>
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/css/default.css?ver=220620">
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://lee-song-yi.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://lee-song-yi.pe.kr";
var g5_bbs_url   = "http://lee-song-yi.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="keywords" content="밀크티, 버블티, 커피, 디저트, 차, 홍차"/> 
  <meta name="description" content="자연의 찻집 팔공티입니다."/>

  <meta property="og:title" content="팔공티-PALGONGTEA"/>
  <meta property="og:type" content="website"/>
  <meta property="og:description" content="PALGONGTEA 밀크티가 맛있는 카페입니다.">
  <meta property="og:image" content="img/og.png">
<script src="http://lee-song-yi.pe.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/common.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/wrest.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

  <link rel="stylesheet" href="/css/sub-f-personal.css">
  <link rel="stylesheet" href="/css/sub-f-terms.css">
  <link rel="stylesheet" href="/css/sub-f-collection.css">
  

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />  

  <script src="https://kit.fontawesome.com/979b8c848e.js" crossorigin="anonymous"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="js/jquery.vide.js"></script>


<!-- 상단 시작 { -->

<div id="skip_to_container"><a href="#container">본문 바로가기</a></div>
<header id="header">
  <div class="inner">
    <h1 class="logo"><a href="/index.php">logo</a></h1>
    <ul class="gnb">
      <li class="depth1"><a href="/sub/sub1-1.php">브랜드소개</a>
        <ul class="depth2">
          <li><a href="/sub/sub1-1.php">팔공티소개</a></li>
          <li><a href="/sub/sub1-2.php">연혁</a></li>
          <li><a href="/sub/sub1-3.php">오시는길</a></li>
          <li><a href="/sub/sub1-4.php">해외사업</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">메뉴</a>
        <ul class="depth2">
          <li><a href="/sub/sub2-1.php">주문TIP</a></li>
          <li><a href="#">티 컬렉션</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub3-1.php">창업문의</a>
        <ul class="depth2">
          <li><a href="/sub/sub3-1.php">가맹절차</a></li>
          <li><a href="/sub/sub3-2.php">인테리어</a></li>
          <li><a href="/sub/sub3-3.php">가맹비용</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담신청</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">매장안내</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내매장</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외매장</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub5-1.php">멤버십</a>
        <ul class="depth2">
          <li><a href="/sub/sub6-1.php">팔공티APP</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">팔공티소식</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=counsel_br">고객문의</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드제휴</a></li>
        </ul>
      </li>
    </ul>
    <div class="tnb">
      <ul class="login-box">        
                <li class="join"><a href="http://lee-song-yi.pe.kr/bbs/register.php">회원가입</a></li>
        <li class="login"><a href="http://lee-song-yi.pe.kr/bbs/login.php">로그인</a></li>
              </ul>
      <nav class="allmenu">
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
      </nav>
      <div class="allmenu-wrap">
        <ul class="allmenu-box">
          <p>All Menu</p>
          <li class="allmenu-depth1"><a href="#"><p>브랜드 소개</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub1-1.php">팔공티 소개</a></li>
              <li><a href="/sub/sub1-2.php">연혁</a></li>
              <li><a href="/sub/sub1-3.php">오시는 길</a></li>
              <li><a href="/sub/sub1-4.php">해외 사업</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="#"><p>메뉴</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub2-1.php">주문 TIP</a></li>
              <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴/신메뉴</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub3-1.php"><p>창업 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub3-1.php">가맹 절차</a></li>
              <li><a href="/sub/sub3-2.php">인테리어</a></li>
              <li><a href="/sub/sub3-3.php">가맹 비용</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map"><p>매장 안내</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내 매장</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외 매장</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub5-1.php"><p>멤버쉽</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub6-1.php">팔공티 APP</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice"><p>팔공티 소식</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=counsel_br"><p>고객 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드 제휴</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</header>
<!-- } 상단 끝 -->


<hr>

<!-- 콘텐츠 시작 { -->
<main id="main">
    <nav class="hidden">메인 콘텐츠</nav>
  <div class="terms-inner inner">
    <div class="terms-box">
      <h3 class="terms-tit">팔공티 이용 약관</h3>
      <div class="agree" style="line-height:30px;">
      제 1 조 (목적)<br>
본 이용약관(이하 '약관'이라 함)은 사단법인 굿피플 인터내셔널(이하 '우리 기관'이라 함)과 이용 고객(이하<br> '회원'이라 함)간에 우리 기관이 제공하는 인터넷 관련 서비스(http://www.goodpeople.or.kr) 을 말하며<br> 이하 '서비스'라 함)를 이용함에 있어 회원과 우리 기관간의 권리, 의무 및 책임사항 등 기본적인 제반 사항과 기타 필요한 사항을 구체적으로 규정함을 목적으로 합니다.<br>
<br>
제 2 조 (용어의 정의)<br>
(1) 본 약관에서 사용하는 용어의 정의는 다음과 같습니다.<br>
- '회원'이라 함은 본 약관에 동의하고 서비스를 이용하는 이용자를 말합니다.<br>
- '정기후원회원'이라 함은 우리 기관의 긴급구호와 개발사업에 참여하기 위해 매월 정기적으로 회비를 납부하는 회원을 말합니다.<br>
- '이용계약'이라 함은 본 약관을 포함하여 서비스 이용과 관련하여 우리 기관과 회원 간에 체결하는 모든 계약을 말합니다.<br>
- '이용자ID'라 함은 회원의 식별 및 서비스 이용을 위하여 회원의 신청에 따라 우리 기관이 회원별로 부여하는,<br> 고유한 문자와 숫자로 조합된 계정을 말하며, 회원 1인당 부여 받은 1개의 공통 계정으로 우리 기관의 모든 서비스를 이용할 수 있습니다.<br>
- '비밀번호'라 함은 이용자ID로 식별되는 회원의 본인 여부를 검증하기 위하여 회원이 설정하여 우리 기관에 등록한 고유의 문자와 숫자의 조합을 말합니다.<br>
- '게시물'이라 함은 회원이 서비스를 이용하면서 게시한 글, 사진, 각종 파일과 링크 등을 말합니다.<br>
(2) 본 약관에서 사용하는 용어 중 본조 제1항에서 정하지 아니한 것은 관계 법령 및 서비스별 안내에서 정하는 바에 따르며, 그 외에는 일반 관례에 따릅니다.<br>
<br>
제 3 조 (이용약관의 효력 및 변경)<br>
(1) 본 약관은 서비스를 통해 온라인으로 공시하고 회원의 동의와 우리 기관의 승낙으로 효력을 발생합니다.<br>
(2) 우리 기관은 합리적인 사유가 발생할 경우 관련 법령에 위배되지 않는 범위 안에서 이용약관을 개정할 수 있습니다.<br> 개정된 약관은 정당한 절차에 따라 서비스를 통해 공지함으로써 효력을 발휘합니다. (3) 회원은 <br>정기적으로 서비스를 방문하여 약관의 변경사항을 확인하여야 합니다. 변경된 약관에 대한 정보를 알지 못해 발생하는 회원의 피해는 우리 기관에서 책임지지 않습니다.<br>
(4) 회원은 변경된 약관 사항에 동의하지 않을 경우 서비스 이용을 중단하고 이용계약을 해지할 수 있습니다.<br>
<br>
제 4 조 (약관 외 준칙)<br>
(1) 본 약관에 명시되지 않은 사항에 대해서는 전기통신기본법 등 그 외 관계법령에 의합니다.<br>
(2) 우리 기관은 필요한 경우 서비스 내의 개별항목에 대하여 개별약관 또는 운영원칙(이하 '서비스별 안내'라 <br>합니다)를 정할 수 있으며, 본 약관과 서비스별 안내의 내용이 상충되는 경우에는 서비스별 안내의 내용을 우선하여 적용합니다.<br>
      </div>
    </div>
  </div>
  
</section>
<!-- } 콘텐츠 끝 -->

<hr>

<!-- 하단 시작 { -->
<footer id="footer">
  <div class="inner">
    <h4 class="f-logo"><a href="#">logo</a></h4>
    <ul class="f-menu">
      <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
      <li><a href="/sub/sub-f-terms.php">이용약관</a></li>
      <li><a href="/sub/sub-f-collection.php">이메일무단수집거부</a></li>
      <li><a href="/sub/sub1-3.php">오시는길</a></li>
    </ul>
    <div class="f-hours">
      <ul class="f-open">OPENING HOURS
        <li>MON-FRI</li>
        <li>09:00 AM ~ 06:00 PM</li>
        <li>주말, 공휴일 휴무</li>
      </ul>
      <ul class="f-sns">
        <li><a href="https://ko-kr.facebook.com/Palgongtea.official/">페이스북</a></li>
        <li><a href="https://www.instagram.com/palgongtea.official/">인스타그램</a></li>
        <li><a href="https://blog.naver.com/palgongtea_official">네이버블로그</a></li>
      </ul>
    </div>
    <div class="f-adrr">
      <ul class="f-number">
        <li>사업자번호 669-88-01126</li>
        <li>㈜팔공티 대표이사 김종현</li>
      </ul>
      <ul class="f-txt">
        <li><adrress>주소 : 서울 강남구 밤고개로1길 10, 현대벤처빌 1822호 팔공티</adrress></li>
        <li>연락처 : 02-6928-8286</li>
        <li>이메일 : palgongtea@palgongtea.com</li>
      </ul>
      <p class="f-copy">ⓒ 2021 PALGONG TEA All rights reserved.</p>
    </div>
  </div>
</footer>
<!-- } 하단 끝 -->
<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
