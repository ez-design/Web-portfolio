<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>그누보드5</title>
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/css/default.css?ver=220620">
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://lee-song-yi.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://lee-song-yi.pe.kr";
var g5_bbs_url   = "http://lee-song-yi.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="keywords" content="밀크티, 버블티, 커피, 디저트, 차, 홍차"/> 
  <meta name="description" content="자연의 찻집 팔공티입니다."/>

  <meta property="og:title" content="팔공티-PALGONGTEA"/>
  <meta property="og:type" content="website"/>
  <meta property="og:description" content="PALGONGTEA 밀크티가 맛있는 카페입니다.">
  <meta property="og:image" content="img/og.png">
<script src="http://lee-song-yi.pe.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/common.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/wrest.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

  <link rel="stylesheet" href="/css/sub2-common.css">
  <link rel="stylesheet" href="/css/sub2-1-index.css">
  <link rel="stylesheet" href="/css/sub2-2-index.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />  

  <script src="https://kit.fontawesome.com/979b8c848e.js" crossorigin="anonymous"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


<!-- 상단 시작 { -->

<div id="skip_to_container"><a href="#container">본문 바로가기</a></div>
<header id="header">
  <div class="inner">
    <h1 class="logo"><a href="/index.php">logo</a></h1>
    <ul class="gnb">
      <li class="depth1"><a href="/sub/sub1-1.php">브랜드소개</a>
        <ul class="depth2">
          <li><a href="/sub/sub1-1.php">팔공티소개</a></li>
          <li><a href="/sub/sub1-2.php">연혁</a></li>
          <li><a href="/sub/sub1-3.php">오시는길</a></li>
          <li><a href="/sub/sub1-4.php">해외사업</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">메뉴</a>
        <ul class="depth2">
          <li><a href="/sub/sub2-1.php">주문TIP</a></li>
          <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub3-1.php">창업문의</a>
        <ul class="depth2">
          <li><a href="/sub/sub3-1.php">가맹절차</a></li>
          <li><a href="/sub/sub3-2.php">인테리어</a></li>
          <li><a href="/sub/sub3-3.php">가맹비용</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">매장안내</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내매장</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외매장</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub5-1.php">멤버십</a>
        <ul class="depth2">
          <li><a href="/sub/sub6-1.php">팔공티APP</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">팔공티소식</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">고객문의</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드제휴</a></li>
        </ul>
      </li>
    </ul>
    <div class="tnb">
      <ul class="login-box">        
                <li class="join"><a href="http://lee-song-yi.pe.kr/bbs/register.php">회원가입</a></li>
        <li class="login"><a href="http://lee-song-yi.pe.kr/bbs/login.php">로그인</a></li>
              </ul>
      <nav class="allmenu">
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
      </nav>
      <div class="allmenu-wrap">
        <p>All Menu</p>
        <ul class="allmenu-box">
          <li class="allmenu-depth1">
            <a href="#"><p>브랜드 소개</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub1-1.php">팔공티 소개</a></li>
              <li><a href="/sub/sub1-2.php">연혁</a></li>
              <li><a href="/sub/sub1-3.php">오시는 길</a></li>
              <li><a href="/sub/sub1-4.php">해외 사업</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="#"><p>메뉴</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub2-1.php">주문 TIP</a></li>
              <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴/신메뉴</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub3-1.php"><p>창업 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub3-1.php">가맹 절차</a></li>
              <li><a href="/sub/sub3-2.php">인테리어</a></li>
              <li><a href="/sub/sub3-3.php">가맹 비용</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map"><p>매장 안내</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내 매장</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외 매장</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub5-1.php"><p>멤버쉽</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub6-1.php">팔공티 APP</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice"><p>팔공티 소식</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand"><p>고객 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드 제휴</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <script>
    var allBtn = $('.allmenu');
        allBtn.each(function(index){
        var $this = $(this);
          $this.on('click', function(e){
            e.preventDefault();
            $(this).toggleClass('active');
          });
        });
    var depth1 = $('.allmenu-depth1');
        depth1.each(function(index){
    var $this = $(this);
        $('.allmenu-depth1 > a').on('click', function(e){
          e.preventDefault();
          $('.allmenu-depth1').removeClass('on');
          $(this).parent().toggleClass('on');
        });
    });
  </script>
</header>
<!-- } 상단 끝 -->
<!-- 콘텐츠 시작 { -->
<main id="main">
  <h2 class="hidden">메인 콘텐츠</h2>
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">메뉴</p>
    </div>
  </section>
  <nav class="lnb">
    <div class="inner">
      <ul class="lnb-menu">
        <li class="lnb-menu1-current"><a href="/sub/sub2-1.php">주문 TIP</a></li>
        <li class="lnb-menu2-current"><a href="/sub/sub2-2.php">티 컬렉션</a></li>
        <li class="lnb-menu3-current"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴</a></li>
        <li class="lnb-menu4-current"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
        <li class="lnb-menu4-current"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
      </ul>
    </div>
  </nav>
  <section class="palgongtea-menu inner">  <nav class="hidden">메인 콘텐츠</nav>
  <h3 class="tip-tit"><strong>PALGONGTEA</strong> 주문 TIP</h3>
  <p class=tip-desc>맛있는 음료를 주문하기 위한 TIP입니다</p>
  <article class="tip-step1 tip-step">
    <p class="step1-tit tip-step-tit">STEP1. <strong>MENU</strong></p>
    <span class="step1-desc tip-step-desc">맛있는 팔공티 메뉴를 선택해 주세요.</span>
    <ul class="step1-menulist">
      <li>
        <p class="step1-menu-name">오리지널 밀크티</p>
        <em class="step1-menu-engname">Original Milk Tea</em>
      </li>
      <li>
        <p class="step1-menu-name">블렌디드 밀크티</p>
        <em class="step1-menu-engname">Blendid Milk Tea</em>
      </li>
      <li>
        <p class="step1-menu-name">오리지널 티</p>
        <em class="step1-menu-engname">Original Tea</em>
      </li>
      <li>
        <p class="step1-menu-name">커피</p>
        <em class="step1-menu-engname">Coffee</em>
      </li>
      <li>
        <p class="step1-menu-name">프룻티</p>
        <em class="step1-menu-engname">Fluit Tea</em>
      </li>
      <li>
        <p class="step1-menu-name">스무디</p>
        <em class="step1-menu-engname">Smoothie</em>
      </li>
      <li>
        <p class="step1-menu-name">논커피</p>
        <em class="step1-menu-engname">Beverage</em>
      </li>
      <li>
        <p class="step1-menu-name">에이드</p>
        <em class="step1-menu-engname">Aid</em>
      </li>
    </ul>
  </article>
  <article class="tip-step2 tip-step">
    <p class="step2-tit tip-step-tit">STEP 2. <strong>HOT/ICE</strong></p>
    <span class="step2-desc tip-step-desc">HOT 또는 ICE를 선택해 주세요.</span>
    <article class="step2-ice">
      <strong class="step2-ice-tit">ICE MILK TEA</strong>
      <span class="step2-ice-desc"><em>ICE MILK TEA</em>는<br>기본 펄이 제공됩니다</span>
      <em class="step2-ice-txt">(ICE MILK TEA 외 음료에는 기본 펄이 제공되지 않습니다)</em>
      <p>기본 펄 있음</p>
    </article>
    <article class="step2-hot">
      <strong class="step2-hot-tit">HOT MILK TEA</strong>
      <span class="step2-hot-desc"><em>HOT MILK TEA</em>는 기본 펄이 없으며<br>주문 시 타피오카 추가가 가능합니다.</span>
      <em class="step2-hot-txt">(원하시는 분은 펄 추가 +500원으로 제공됩니다)</em>
      <p>펄 추가 시 +500원</p>
    </article>
  </article>
  <article class="tip-step3 tip-step">
    <p class="step3-tit tip-step-tit">STEP 3. <strong>TOPPING</strong></p>
    <span class="step3-desc tip-step-desc">토핑 추가 옵션을 선택해 주세요.</span>
    <ul class="step3-menulist">
      <li>
        <p class="step3-topping-name">헤이즐넛 시럽</p>
        <em class="step3-topping-engname">Hazelnut Syrup</em>
        <span class="step3-topping-desc">헤이즐넛 향이 풍부한 시럽으로<br>고소한 풍미가 한층 UP</span>
      </li>
      <li>
        <p class="step3-topping-name">크림치즈폼</p>
        <em class="step3-topping-engname">Cream Cheese Foam</em>
        <span class="step3-topping-desc">풍부한 크림치즈의<br>풍미와 쫀득함이 매력</span>
      </li>
      <li>
        <p class="step3-topping-name">휘핑크림</p>
        <em class="step3-topping-engname">Whipped Cream</em>
        <span class="step3-topping-desc">새하얗고 달콤한 크림을<br>듬뿍 얹어 즐겨 보세요</span>
      </li>
      <li>
        <p class="step3-topping-name">에스프레소</p>
        <em class="step3-topping-engname">Espresso</em>
        <span class="step3-topping-desc">더욱 더 깊은 커피의 맛을<br>즐기고자 한다면 샷 추가</span>
      </li>
      <li>
        <p class="step3-topping-name">타피오카펄</p>
        <em class="step3-topping-engname">Tapioca Pearl</em>
        <span class="step3-topping-desc">쫀득쫀득하고 달콤한<br>타피오카펄을 넣어 보세요</span>
      </li>
      <li>
        <p class="step3-topping-name">코코넛펄</p>
        <em class="step3-topping-engname">Cocounut Pearl</em>
        <span class="step3-topping-desc">쫄깃쫄깃하고 달달한<br>코코넛펄 추가는 필수!</span>
      </li>
      <li>
        <p class="step3-topping-name">알로에펄</p>
        <em class="step3-topping-engname">Aloe Pearl</em>
        <span class="step3-topping-desc">달콤하고 아삭한 식감의<br>알로에펄을 빼놓을 수 없죠</span>
      </li>
      <li>
        <p class="step3-topping-name">곤약펄</p>
        <em class="step3-topping-engname">Konjac Pearl</em>
        <span class="step3-topping-desc">쫄깃한 식감과 식이섬유가 듬뿍!<br>인기만점 곤약 젤리</span>
      </li>
    </ul>
  </article>
  <article class="tip-step4 tip-step">
    <p class="step4-tit tip-step-tit">STEP 4. <strong>ICE/SWEET</strong></p>
    <span class="step4-desc tip-step-desc">얼음 양과 당도를 선택해 주세요.</span>
    <article class="step4-txt-box">
      <p class="step4-txt">옵션을 선택하지 않으시는 경우 기본 옵션으로 제공됩니다.<br>선택하시는 얼음 양과 관계없이 제공되는 음료의 양은 동일합니다.</p>
    </article>
    <article class="step4-ice-box step4-box">
      <p>얼음 선택</p>
      <ul>
        <li>조금</li>
        <li>기본</li>
        <li>가득</li>
      </ul>
    </article>
    <article class="step4-sweet-box step4-box">
      <p>당도 선택</p>
      <ul>
        <li class="step4-sweet">0%</li>
        <li class="step4-sweet">25%</li>
        <li class="step4-sweet">50%</li>
        <li class="step4-sweet">75%</li>
        <li class="step4-sweet">100%</li>
      </ul>
      <em>거의 달지 않은 맛</em>
      <em>가장 단 맛</em>
    </article>
  </article>
<!-- } 콘텐츠 끝 -->
<!-- 하단 시작 { -->
  </section>
</main>
<footer id="footer">
  <div class="inner">
    <h4 class="f-logo"><a href="#">logo</a></h4>
    <ul class="f-menu">
      <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
      <li><a href="/sub/sub-f-terms.php">이용약관</a></li>
      <li><a href="/sub/sub-f-collection.php">이메일무단수집거부</a></li>
      <li><a href="/sub/sub1-3.php">오시는길</a></li>
    </ul>
    <div class="f-hours">
      <ul class="f-open">OPENING HOURS
        <li>MON-FRI</li>
        <li>09:00 AM ~ 06:00 PM</li>
        <li>주말, 공휴일 휴무</li>
      </ul>
      <ul class="f-sns">
        <li><a href="https://ko-kr.facebook.com/Palgongtea.official/">페이스북</a></li>
        <li><a href="https://www.instagram.com/palgongtea.official/">인스타그램</a></li>
        <li><a href="https://blog.naver.com/palgongtea_official">네이버블로그</a></li>
      </ul>
    </div>
    <div class="f-adrr">
      <ul class="f-number">
        <li>사업자번호 669-88-01126</li>
        <li>㈜팔공티 대표이사 김종현</li>
      </ul>
      <ul class="f-txt">
        <li><adrress>주소 : 서울 강남구 밤고개로1길 10, 현대벤처빌 1822호 팔공티</adrress></li>
        <li>연락처 : 02-6928-8286</li>
        <li>이메일 : palgongtea@palgongtea.com</li>
      </ul>
      <p class="f-copy">ⓒ 2021 PALGONG TEA All rights reserved.</p>
    </div>
  </div>
</footer>
<!-- } 하단 끝 -->
<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
