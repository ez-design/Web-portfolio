<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>그누보드5</title>
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/css/default.css?ver=220620">
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://lee-song-yi.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://lee-song-yi.pe.kr";
var g5_bbs_url   = "http://lee-song-yi.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="keywords" content="밀크티, 버블티, 커피, 디저트, 차, 홍차"/> 
  <meta name="description" content="자연의 찻집 팔공티입니다."/>

  <meta property="og:title" content="팔공티-PALGONGTEA"/>
  <meta property="og:type" content="website"/>
  <meta property="og:description" content="PALGONGTEA 밀크티가 맛있는 카페입니다.">
  <meta property="og:image" content="img/og.png">
<script src="http://lee-song-yi.pe.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/common.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/wrest.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

  <link rel="stylesheet" href="/css/sub5-common.css">
  <link rel="stylesheet" href="/css/sub5-1-index.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />  

  <script src="https://kit.fontawesome.com/979b8c848e.js" crossorigin="anonymous"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


<!-- 상단 시작 { -->

<div id="skip_to_container"><a href="#container">본문 바로가기</a></div>
<header id="header">
  <div class="inner">
    <h1 class="logo"><a href="/index.php">logo</a></h1>
    <ul class="gnb">
      <li class="depth1"><a href="/sub/sub1-1.php">브랜드소개</a>
        <ul class="depth2">
          <li><a href="/sub/sub1-1.php">팔공티소개</a></li>
          <li><a href="/sub/sub1-2.php">연혁</a></li>
          <li><a href="/sub/sub1-3.php">오시는길</a></li>
          <li><a href="/sub/sub1-4.php">해외사업</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">메뉴</a>
        <ul class="depth2">
          <li><a href="/sub/sub2-1.php">주문TIP</a></li>
          <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub3-1.php">창업문의</a>
        <ul class="depth2">
          <li><a href="/sub/sub3-1.php">가맹절차</a></li>
          <li><a href="/sub/sub3-2.php">인테리어</a></li>
          <li><a href="/sub/sub3-3.php">가맹비용</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">매장안내</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내매장</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외매장</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub5-1.php">멤버십</a>
        <ul class="depth2">
          <li><a href="/sub/sub6-1.php">팔공티APP</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">팔공티소식</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">고객문의</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드제휴</a></li>
        </ul>
      </li>
    </ul>
    <div class="tnb">
      <ul class="login-box">        
                <li class="join"><a href="http://lee-song-yi.pe.kr/bbs/register.php">회원가입</a></li>
        <li class="login"><a href="http://lee-song-yi.pe.kr/bbs/login.php">로그인</a></li>
              </ul>
      <nav class="allmenu">
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
      </nav>
      <div class="allmenu-wrap">
        <p>All Menu</p>
        <ul class="allmenu-box">
          <li class="allmenu-depth1">
            <a href="#"><p>브랜드 소개</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub1-1.php">팔공티 소개</a></li>
              <li><a href="/sub/sub1-2.php">연혁</a></li>
              <li><a href="/sub/sub1-3.php">오시는 길</a></li>
              <li><a href="/sub/sub1-4.php">해외 사업</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="#"><p>메뉴</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub2-1.php">주문 TIP</a></li>
              <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴/신메뉴</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub3-1.php"><p>창업 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub3-1.php">가맹 절차</a></li>
              <li><a href="/sub/sub3-2.php">인테리어</a></li>
              <li><a href="/sub/sub3-3.php">가맹 비용</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map"><p>매장 안내</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내 매장</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외 매장</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub5-1.php"><p>멤버쉽</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub6-1.php">팔공티 APP</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice"><p>팔공티 소식</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand"><p>고객 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드 제휴</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <script>
    var allBtn = $('.allmenu');
        allBtn.each(function(index){
        var $this = $(this);
          $this.on('click', function(e){
            e.preventDefault();
            $(this).toggleClass('active');
          });
        });
    var depth1 = $('.allmenu-depth1');
        depth1.each(function(index){
    var $this = $(this);
        $('.allmenu-depth1 > a').on('click', function(e){
          e.preventDefault();
          $('.allmenu-depth1').removeClass('on');
          $(this).parent().toggleClass('on');
        });
    });
  </script>
</header>
<!-- } 상단 끝 -->
<!-- 콘텐츠 시작 { -->
<main id="main">
  <h2 class="hidden">메인 콘텐츠</h2>
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">멤버쉽</p>
    </div>
  </section>
  <nav class="lnb">
    <div class="inner">
      <ul class="lnb-menu">
        <li class="lnb-menu1-current"><a href="/sub/sub5-1.php">팔공티 APP</a></li>
      </ul>
    </div>
  </nav>
  <section class="palgongtea-member inner">  <nav class="hidden">메인 콘텐츠</nav>
  <h3 class="member-tit"><strong>PALGONGTEA</strong> MEMBERSHIP</h3>
  <p class="member-desc">비대면으로 주문 가능한 스마트한 방법</p>
  <section class="member-wrap clearfix">
    <article class="member-head">
      <div class="member-text-box">
        <p class="member-txt">팔공티 APP 이용 가이드</p>
        <span class="member-txt-eng">PALGONGTEA APP USER GUIDE</span>
      </div>
      <div class="member-img-box">
        <figure><img src="/img/member-iphone.png" alt="#"></figure>
      </div>
    </article>
    <article class="member-guide">
      <strong>팔공티 앱 설치하는 방법</strong>
      <article class="member-android">
        <p>안드로이드(android)</p>
        <ul class="member-android-li">
          <li>Play Store 접속</li>
          <li>팔공티 검색</li>
          <li>설치</li>
        </ul>
        <span class="member-android-qr">QR코드를 스캔하시면, 팔공티 앱을<br>편리하게 설치하실 수 있습니다.</span>
      </article>
      <article class="member-iphone">
        <p>아이폰(iOS)</p>
        <ul class="member-iphone-li">
          <li>App Store 접속</li>
          <li>팔공티 검색</li>
          <li>설치</li>
        </ul>
        <span class="member-iphone-qr">QR코드를 스캔하시면, 팔공티 앱을<br>편리하게 설치하실 수 있습니다.</span>
      </article>
    </article>
    <article class="member-app">
      <strong>PALGONGTEA APP 설치하기</strong>
      <p>POS 및 키오스크 앞에서 기다리지 마세요.<br>팔공티 앱은 매장에 방문 시 <em>줄을 서지 않고<br>메뉴를 픽업</em> 할 수 있는 서비스입니다.</p>
      <figure><img src="/img/member-iphone.png" alt="#"></figure>
    </article>
    <article class="member-use">
      <p>메뉴를 간편하게 주문할 수 있는</p>
      <strong>쉽고 빠른 팔공티 앱</strong>
      <em>지금 사용해 보세요!</em>
      <div class="member-use-box">
        <p class="member-use-tit">사용 방법</p>
        <ul>
          <li>
            <p>1. 회원가입</p>
            <span>팔공티에 접속하여<br>회원가입을 클릭한 뒤<br>고객님의 개인 정보 입력.</span>
          </li>
          <li>
            <p>2. 메뉴선택</p>
            <span>APP 메인 화면에<br>'스마트 오더'를<br>클릭해 주세요.</span>
          </li>
          <li>
            <p>3. 내 주변매장 확인</p>
            <span>가까운 매장을 자동 검색<br>주문하고자 하는 매장을<br>선택해 주세요.</span>
          </li>
          <li>
            <p>4. 메뉴주문</p>
            <span>주문하고자 하는<br>메뉴와 옵션 선택.</span>
          </li>
          <li>
            <p>5. 결제하기</p>
            <span>주문을 완료 후,<br>결제창에서 결제해 주세요.</span>
          </li>
          <li>
            <p>6. 주문완료</p>
            <span>주문 현황을 확인하시고<br>메뉴 제조가 완료되면 픽업대에서<br>메뉴를 픽업해 주세요.</span>
          </li>
        </ul>
      </div>
    </article>
  </section>
<!-- } 콘텐츠 끝 -->
<!-- 하단 시작 { -->
  </section>
</main>
<footer id="footer">
  <div class="inner">
    <h4 class="f-logo"><a href="#">logo</a></h4>
    <ul class="f-menu">
      <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
      <li><a href="/sub/sub-f-terms.php">이용약관</a></li>
      <li><a href="/sub/sub-f-collection.php">이메일무단수집거부</a></li>
      <li><a href="/sub/sub1-3.php">오시는길</a></li>
    </ul>
    <div class="f-hours">
      <ul class="f-open">OPENING HOURS
        <li>MON-FRI</li>
        <li>09:00 AM ~ 06:00 PM</li>
        <li>주말, 공휴일 휴무</li>
      </ul>
      <ul class="f-sns">
        <li><a href="https://ko-kr.facebook.com/Palgongtea.official/">페이스북</a></li>
        <li><a href="https://www.instagram.com/palgongtea.official/">인스타그램</a></li>
        <li><a href="https://blog.naver.com/palgongtea_official">네이버블로그</a></li>
      </ul>
    </div>
    <div class="f-adrr">
      <ul class="f-number">
        <li>사업자번호 669-88-01126</li>
        <li>㈜팔공티 대표이사 김종현</li>
      </ul>
      <ul class="f-txt">
        <li><adrress>주소 : 서울 강남구 밤고개로1길 10, 현대벤처빌 1822호 팔공티</adrress></li>
        <li>연락처 : 02-6928-8286</li>
        <li>이메일 : palgongtea@palgongtea.com</li>
      </ul>
      <p class="f-copy">ⓒ 2021 PALGONG TEA All rights reserved.</p>
    </div>
  </div>
</footer>
<!-- } 하단 끝 -->
<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
