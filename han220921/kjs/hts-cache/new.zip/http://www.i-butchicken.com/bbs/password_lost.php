<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>아이벗치킨</title>

<meta name="keywords" content="청주 맛집,청주 프랜차이즈,청주 치킨,소자본 창업,치킨 프랜차이즈 추천,소자본 프랜차이즈,치킨 창업,아이프랜드,아이벗,아이벗치킨,아이벗 치킨,프랜차이즈,간장치킨,매콤치킨,강정치킨,후라이드치킨,옛날 후라이드 치킨,순살치킨,고상한 파풍기,아이매워,옛날 후라이드,옛날 양념치킨,달콤치킨,화이트 어니언,순살세트,똥집튀김,닭발튀김,웨지감자튀김,크림치즈볼,떡볶이">
<meta name="description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">

<meta property="og:title" content="아이벗치킨">
<meta property="og:type" content="website">
<meta property="og:description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">
<meta property="og:url" content="http://i-butchicken.com">
<meta property="og:image" content="/img/og-image.png">
<title>회원정보 찾기 | 아이벗치킨</title>
<link rel="stylesheet" href="http://www.i-butchicken.com/css/default.css?ver=220620">
<link rel="stylesheet" href="http://www.i-butchicken.com/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://www.i-butchicken.com/skin/member/basic/style.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://www.i-butchicken.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://www.i-butchicken.com";
var g5_bbs_url   = "http://www.i-butchicken.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<title>아이벗치킨</title>

<meta name="keywords" content="청주 맛집,청주 프랜차이즈,청주 치킨,소자본 창업,치킨 프랜차이즈 추천,소자본 프랜차이즈,치킨 창업,아이프랜드,아이벗,아이벗치킨,아이벗 치킨,프랜차이즈,간장치킨,매콤치킨,강정치킨,후라이드치킨,옛날 후라이드 치킨,순살치킨,고상한 파풍기,아이매워,옛날 후라이드,옛날 양념치킨,달콤치킨,화이트 어니언,순살세트,똥집튀김,닭발튀김,웨지감자튀김,크림치즈볼,떡볶이">
<meta name="description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">

<meta property="og:title" content="아이벗치킨">
<meta property="og:type" content="website">
<meta property="og:description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">
<meta property="og:url" content="http://i-butchicken.com">
<meta property="og:image" content="/img/og-image.png">

<link rel="shortcut icon" href="/favicon.ico">






<script src="http://www.i-butchicken.com/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/jquery.menu.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/common.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/wrest.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/placeholders.min.js?ver=221017"></script>
</head>
<body>


<link rel="stylesheet" href="/css/main.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8.4.6/swiper.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8.4.6/swiper-bundle.css">
                

<script src="https://kit.fontawesome.com/15dfde8f2b.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@8.4.6/swiper-bundle.esm.browser.js"></script>
<script src="/js/header.js"></script>


<div class="skip-nav"><a href="#container">본문 바로가기</a></div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/"><img src="/img/logo-w.svg" alt="아이벗치킨"></a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인 메뉴</h2>
            <ul>
                <li class="depth1"><a href="/sub/sub1-1.php"><span>아이벗스토리</span></a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php"><span>CEO 인사말</span></a></li>
                        <li><a href="/sub/sub1-2.php"><span>브랜드 소개</span></a></li>
                        <li><a href="/sub/sub1-3.php"><span>BI</span></a></li>
                        <li><a href="/sub/sub1-4.php"><span>오시는 길</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>메뉴 소개</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>신메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=chicken_menu"><span>치킨 메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=alcohol_menu"><span>술한잔 메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=side_menu"><span>사이드 메뉴</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="/sub/sub3-1.php"><span>창업 안내</span></a>
                    <ul class="depth2">
                        <li><a href="/sub/sub3-1.php"><span>아이벗의 약속</span></a></li>
                        <li><a href="/sub/sub3-2.php"><span>성공포인트</span></a></li>
                        <li><a href="/sub/sub3-3.php"><span>절차 및 비용</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><span>창업 상담</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>커뮤니티</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=qna"><span>고객의 소리</span></a></li>
                    </ul>
                </li>
            </ul>
            <p class="gnb-bg"></p>
        </nav>
        <ul class="tnb">        
                        <li><a href="http://www.i-butchicken.com/bbs/register.php">회원가입</a></li>
            <li><a href="http://www.i-butchicken.com/bbs/login.php">로그인</a></li>
                    </ul>
        <button type="button" class="all-menu-open">
            <i class="fa-solid fa-bars-staggered"></i>
        </button>
        <nav class="all-menu">
            <h2 class="hidden">모바일 전체메뉴</h2>
            <div class="all-menu-wrap">
                <div class="all-menu-box">
                    <header class="all-menu-header">
                        <h3 class="m-logo"><a href="/"><img src="/img/logo-b.svg" alt="아이벗치킨"></a></h3>
                        <ul class="m-tnb">        
                                                        <li><a href="http://www.i-butchicken.com/bbs/register.php">회원가입</a></li>
                            <li><a href="http://www.i-butchicken.com/bbs/login.php">로그인</a></li>
                                                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult">창업상담</a></li>
                        </ul>
                    </header>
                    <div class="all-menu-body">
                        <ul class="gnb-m">
                            <li class="depth1">
                                <a href="#">
                                    아이벗스토리
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="/sub/sub1-1.php"><span>CEO 인사말</span></a></li>
                                    <li><a href="/sub/sub1-2.php"><span>브랜드 소개</span></a></li>
                                    <li><a href="/sub/sub1-3.php"><span>BI</span></a></li>
                                    <li><a href="/sub/sub1-4.php"><span>오시는 길</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    메뉴 소개
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>신메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=chicken_menu"><span>치킨 메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=alcohol_menu"><span>술한잔 메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=side_menu"><span>사이드 메뉴</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    창업 안내
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="/sub/sub3-1.php"><span>아이벗의 약속</span></a></li>
                                    <li><a href="/sub/sub3-2.php"><span>성공포인트</span></a></li>
                                    <li><a href="/sub/sub3-3.php"><span>절차 및 비용</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><span>창업 상담</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    매장 찾기
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    커뮤니티
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=qna"><span>고객의 소리</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <button type="button" class="all-menu-close">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </nav>
    </div>
</header>

<main id="container">


<!-- 회원정보 찾기 시작 { -->
<div id="find_info" class="new_win">
    <div class="new_win_con">
        <form name="fpasswordlost" action="http://www.i-butchicken.com/bbs/password_lost2.php" onsubmit="return fpasswordlost_submit(this);" method="post" autocomplete="off">
        <h3>이메일로 찾기</h3>
        <fieldset id="info_fs">
            <p>
                회원가입 시 등록하신 이메일 주소를 입력해 주세요.<br>
                해당 이메일로 아이디와 비밀번호 정보를 보내드립니다.
            </p>
            <label for="mb_email" class="sound_only">E-mail 주소<strong class="sound_only">필수</strong></label>
            <input type="text" name="mb_email" id="mb_email" required class="required frm_input full_input email" size="30" placeholder="E-mail 주소">
        </fieldset>
        
<script>var g5_captcha_url  = "http://www.i-butchicken.com/plugin/kcaptcha";</script>
<script src="http://www.i-butchicken.com/plugin/kcaptcha/kcaptcha.js"></script>
<fieldset id="captcha" class="captcha">
<legend><label for="captcha_key">자동등록방지</label></legend>
<img src="http://www.i-butchicken.com/plugin/kcaptcha/img/dot.gif" alt="" id="captcha_img"><input type="text" name="captcha_key" id="captcha_key" required class="captcha_box required" size="6" maxlength="6">
<button type="button" id="captcha_mp3"><span></span>숫자음성듣기</button>
<button type="button" id="captcha_reload"><span></span>새로고침</button>
<span id="captcha_info">자동등록방지 숫자를 순서대로 입력하세요.</span>
</fieldset>
        <div class="win_btn">
            <button type="submit" class="btn_submit">인증메일 보내기</button>
        </div>
        </form>
    </div>
    </div>
<script>    
$(function() {
    $("#reg_zip_find").css("display", "inline-block");
    var pageTypeParam = "pageType=find";

	        });
function fpasswordlost_submit(f)
{
    if (!chk_captcha()) return false;

    return true;
}
</script>
<!-- } 회원정보 찾기 끝 -->
</main>

<footer id="footer">
  <aside class="consult">
      <a href="/sub/sub3-2.php">
          <em>창업문의
              <strong>
                  <span>1588</span>
                  <span>- 6616</span>
              </strong>
          </em>
      </a>
      <a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><strong>창업상담 신청하기</strong></a>
  </aside>
  <button type="button" id="top_btn">
    <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
  </button>
  <div class="inner">
  <h2 class="f-logo"><figure><img src="/img/logo-w.svg" alt="아이벗치킨"></figure></h2>
    <ul class="f-menu">
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=provision">이용약관</a></li>
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=e_mail">이메일무단수집거부</a></li>
        <li><a href="/sub/sub1-4.php">오시는 길</a></li>
    </ul>
    <div class="f-copy">
        <ul class="f-copy-addr">
            <li>아이프랜드 대표자 : 김보경</li>
            <li>
                <address>충북 청주시 서원구 남이면 2순환로 1704 (남이면 가마리 127)</address>
            </li>
            <li>사업자등록번호 315-03-64324</li>
            <li>Tel) 043-291-2389</li>
            <li>Fax) 043-293-9979</li>
        </ul>
        <p class="f-copy-copy">&copy;I-FRIEND CHICKEN. ALL RIGHTS RESERVED.</p>
    </div>
  </div>        
</footer>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@8.4.6/swiper-bundle.min.js"></script>
<script type="module">
  import Swiper from 'https://cdn.jsdelivr.net/npm/swiper@8.4.6/swiper-bundle.esm.browser.js'

  const swiper = new Swiper(...)
</script>
<!-- Initialize Swiper -->
<script>
  var swiper = new Swiper(".visual", {
    effect: "fade",
    fadeEffect: {
      crossFade: true
    },
    loop: true, 
    speed: 700,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    }, 
    pagination: {
        el: ".swiper-pagination",
        type: "fraction",
        formatFractionCurrent: function (number) {
        switch(number)
        {
        case 1:
        myNum='01'
        break;
        case 2:
        myNum='02'
        break;
        case 3:
        myNum='03'
        break;
        case 4:
        myNum='04'
        break;
        default:myNum= number
        }
        return myNum;
        },
        el: ".swiper-pagination",
        type: "fraction",
        formatFractionTotal: function (number) {
        switch(number)
        {
        case 1:
        myNum='01'
        break;
        case 2:
        myNum='02'
        break;
        case 3:
        myNum='03'
        break;
        case 4:
        myNum='04'
        break;
        default:myNum= number
        }
        return myNum;
        }
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});
</script>

<script>
  var swiper = new Swiper(".menu-swiper", {
    slidesPerView: "auto",
    spaceBetween: 0,
    autoplay: {
      delay: 2500,
      disableOnInteraction: false,
  }, 
    loop: true,
    loopFillGroupWithBlank: false,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
</script>

<script>
  var swiper = new Swiper(".review-swiper", {
    slidesPerView: "auto",
    spaceBetween: 0,
    autoplay: {
      delay: 4500,
      disableOnInteraction: false,
  }, 
    loop: true,
    loopFillGroupWithBlank: false,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
      },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
</script>

    
<script>
$(function() {
    $("#top_btn").on("click", function() {
        $("html, body").animate({scrollTop:0}, '500');
        return false;
    });
});
</script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
