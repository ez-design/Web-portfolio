<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>아이벗치킨</title>

<meta name="keywords" content="청주 맛집,청주 프랜차이즈,청주 치킨,소자본 창업,치킨 프랜차이즈 추천,소자본 프랜차이즈,치킨 창업,아이프랜드,아이벗,아이벗치킨,아이벗 치킨,프랜차이즈,간장치킨,매콤치킨,강정치킨,후라이드치킨,옛날 후라이드 치킨,순살치킨,고상한 파풍기,아이매워,옛날 후라이드,옛날 양념치킨,달콤치킨,화이트 어니언,순살세트,똥집튀김,닭발튀김,웨지감자튀김,크림치즈볼,떡볶이">
<meta name="description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">

<meta property="og:title" content="아이벗치킨">
<meta property="og:type" content="website">
<meta property="og:description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">
<meta property="og:url" content="http://i-butchicken.com">
<meta property="og:image" content="/img/og-image.png">
<title>아이벗치킨</title>
<link rel="stylesheet" href="http://www.i-butchicken.com/css/default.css?ver=220620">
<link rel="stylesheet" href="http://www.i-butchicken.com/js/font-awesome/css/font-awesome.min.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://www.i-butchicken.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://www.i-butchicken.com";
var g5_bbs_url   = "http://www.i-butchicken.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<title>아이벗치킨</title>

<meta name="keywords" content="청주 맛집,청주 프랜차이즈,청주 치킨,소자본 창업,치킨 프랜차이즈 추천,소자본 프랜차이즈,치킨 창업,아이프랜드,아이벗,아이벗치킨,아이벗 치킨,프랜차이즈,간장치킨,매콤치킨,강정치킨,후라이드치킨,옛날 후라이드 치킨,순살치킨,고상한 파풍기,아이매워,옛날 후라이드,옛날 양념치킨,달콤치킨,화이트 어니언,순살세트,똥집튀김,닭발튀김,웨지감자튀김,크림치즈볼,떡볶이">
<meta name="description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">

<meta property="og:title" content="아이벗치킨">
<meta property="og:type" content="website">
<meta property="og:description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">
<meta property="og:url" content="http://i-butchicken.com">
<meta property="og:image" content="/img/og-image.png">

<link rel="shortcut icon" href="/favicon.ico">






<script src="http://www.i-butchicken.com/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/jquery.menu.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/common.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/wrest.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub3.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css">

<script src="https://kit.fontawesome.com/15dfde8f2b.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="/js/header.js"></script>


<div class="skip-nav"><a href="#container">본문 바로가기</a></div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/"><img src="/img/logo-w.svg" alt="아이벗치킨"></a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인 메뉴</h2>
            <ul>
                <li class="depth1"><a href="/sub/sub1-1.php"><span>아이벗스토리</span></a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php"><span>CEO 인사말</span></a></li>
                        <li><a href="/sub/sub1-2.php"><span>브랜드 소개</span></a></li>
                        <li><a href="/sub/sub1-3.php"><span>BI</span></a></li>
                        <li><a href="/sub/sub1-4.php"><span>오시는 길</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>메뉴 소개</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>신메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=chicken_menu"><span>치킨 메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=alcohol_menu"><span>술한잔 메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=side_menu"><span>사이드 메뉴</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="/sub/sub3-1.php"><span>창업 안내</span></a>
                    <ul class="depth2">
                        <li><a href="/sub/sub3-1.php"><span>아이벗의 약속</span></a></li>
                        <li><a href="/sub/sub3-2.php"><span>성공포인트</span></a></li>
                        <li><a href="/sub/sub3-3.php"><span>절차 및 비용</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><span>창업 상담</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>커뮤니티</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=qna"><span>고객의 소리</span></a></li>
                    </ul>
                </li>
            </ul>
            <p class="gnb-bg"></p>
        </nav>
        <ul class="tnb">        
                        <li><a href="http://www.i-butchicken.com/bbs/register.php">회원가입</a></li>
            <li><a href="http://www.i-butchicken.com/bbs/login.php">로그인</a></li>
                    </ul>
        <button type="button" class="all-menu-open">
            <i class="fa-solid fa-bars-staggered"></i>
        </button>
        <nav class="all-menu">
            <h2 class="hidden">모바일 전체메뉴</h2>
            <div class="all-menu-wrap">
                <div class="all-menu-box">
                    <header class="all-menu-header">
                        <h3 class="m-logo"><a href="/"><img src="/img/logo-b.svg" alt="아이벗치킨"></a></h3>
                        <ul class="m-tnb">        
                                                        <li><a href="http://www.i-butchicken.com/bbs/register.php">회원가입</a></li>
                            <li><a href="http://www.i-butchicken.com/bbs/login.php">로그인</a></li>
                                                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult">창업상담</a></li>
                        </ul>
                    </header>
                    <div class="all-menu-body">
                        <ul class="gnb-m">
                            <li class="depth1">
                                <a href="#">
                                    아이벗스토리
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="/sub/sub1-1.php"><span>CEO 인사말</span></a></li>
                                    <li><a href="/sub/sub1-2.php"><span>브랜드 소개</span></a></li>
                                    <li><a href="/sub/sub1-3.php"><span>BI</span></a></li>
                                    <li><a href="/sub/sub1-4.php"><span>오시는 길</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    메뉴 소개
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>신메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=chicken_menu"><span>치킨 메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=alcohol_menu"><span>술한잔 메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=side_menu"><span>사이드 메뉴</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    창업 안내
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="/sub/sub3-1.php"><span>아이벗의 약속</span></a></li>
                                    <li><a href="/sub/sub3-2.php"><span>성공포인트</span></a></li>
                                    <li><a href="/sub/sub3-3.php"><span>절차 및 비용</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><span>창업 상담</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    매장 찾기
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    커뮤니티
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=qna"><span>고객의 소리</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <button type="button" class="all-menu-close">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </nav>
    </div>
</header>

<main id="container">
    <section class="sub-visual">
        <h2 class=hidden>서브비쥬얼</h2>
        <div class="inner">
            <strong class="visual-name"><span>창업 안내</span></strong>
        </div>
    </section>
    <nav class="lnb">
        <h2 class="hidden">서브메뉴</h2>
        <div class="inner">
            <ul class="lnb-list">
                <li><a href="/sub/sub3-1.php">아이벗의 약속</a></li>
                <li><a href="/sub/sub3-2.php">성공포인트</a></li>
                <li><a href="/sub/sub3-3.php">절차 및 비용</a></li>
                <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult">창업 상담</a></li>
            </ul>
        </div>
    </nav>
    <section class="sub-franchise sub-sec">

<script>
  $(function(){
    $('.lnb li').eq(2).addClass('on')
  })
</script>

<div class="inner process">
    <h2 class="sub-tit">절차 및 비용</h2>
    <article class="guide sub-article-narrow">
        <header>
            <h3 class="sub-sec-tit-small"><span class="txt-red">아이벗치킨</span> 창업가이드</h3>
            <p class="sub-sec-desc">아이벗만의 전문적이고 효율적인 오픈 프로세스로 신뢰가 쑥!</p>
        </header>
        <ul class="guide-list">
            <li>
                <strong><span>01</span>가맹상담</strong>
                <p class="sub-txt">상담을 통한 적성 검사 및<br>브랜드 경쟁력 및 컨셉 이해도 점검<br>(전화, 인터넷, 내사, 현장 방문상담)</p>
            </li>
            <li>
                <strong><span>02</span>상권분석 &middot; 점포개발</strong>
                <p class="sub-txt">전문가 참여를 통한<br>집중 &middot; 중복상권&sol;예상손익분기 분석<br>등기부등본 검토, 권리 및 임대차 계약</p>
            </li>
            <li>
                <strong><span>03</span>가맹계약</strong>
                <p class="sub-txt">가맹사업 공정화에 의한 법률에 의거<br>가맹점계약서 작성 지원<br>및 오픈일정 설명</p>
            </li>
            <li>
                <strong><span>04</span>실측&middot;도면 작성</strong>
                <p class="sub-txt">내 &middot; 외부 공사용 실측 도면 작성<br>고객 및 작업동선을 검토하여<br>점포최적화 인테리어 설계</p>
            </li>
            <li>
                <strong><span>05</span>인테리어 공사 &middot; 가맹점주 교육</strong>
                <p class="sub-txt">본사 임원 감독하에 인테리어 공사 진행<br>공사 기간동안 교육 매뉴얼에 의한<br>교육 이수(이론, 서비스, 주방 교육)</p>
            </li>
            <li>
                <strong><span>06</span>각종시설 &middot; 집기 입고</strong>
                <p class="sub-txt">물류 목록 체크리스트 전달<br>식자재류, 홍보물류, 기타 비품 입고</p>
            </li>
            <li>
                <strong><span>07</span>오픈</strong>
                <p class="sub-txt">점포별 상권에 최적화된 광고 진행<br>오픈 이벤트, 전단물 배포,<br>플랫폼 별 프리미엄 광고 진행</p>
            </li>
            <li>
                <strong><span>08</span>지속적인 관리 및 지원</strong>
                <p class="sub-txt">지속적인 맨투맨 관리 지원<br>점주와의 소통을 통하여<br>동반성장을 위한 관리 프로세스 지원</p>
            </li>
        </ul>
    </article>
    <article class="costs sub-article-narrow">
        <header>
            <h3 class="sub-sec-tit-small"><span class="txt-red">아이벗치킨</span> 창업비용</h3>
            <p class="sub-sec-desc">아이벗만의 맞춤형 전수 창업으로 기름기를 확 Down!</p>
        </header>
        <div class="costs-table-wrap">
            <em class="costs-unit">(단위 : 만원)</em>
            <table class="costs-table">
                <caption class="hidden">아이벗치킨 창업비용 표</caption>
                <colgroup>
                    <col class="c1">
                    <col class="c2">
                    <col class="c3">
                    <col class="c4">
                </colgroup>
                <thead>
                    <tr>
                        <th><strong>항목</strong></th>
                        <th><strong>세부내역</strong></th>
                        <th><strong>비용</strong></th>
                        <th><strong>비고</strong></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th><strong>가맹비</strong></th>
                        <td>
                            <em class="sub-txt">상표 및 지적재산권 사용</em>
                            <em class="sub-txt">상권보호 &middot; 분석 &middot; 점포개발 지원</em>
                        </td>
                        <td><em class="sub-txt">300</em></td>
                        <td><em class="sub-txt">한시적 면제</em></td>
                    </tr>
                    <tr>
                        <th><strong>교육비</strong></th>
                        <td>
                            <em class="sub-txt">상호 &middot; 상표 사용 및 제반 사항</em>
                            <em class="sub-txt">제품 준비 및 체인 경영 교육</em>
                        </td>
                        <td><em>200</em></td>
                        <td><em>&dash;</em></td>
                    </tr>
                    <tr>
                        <th><strong>간판</strong></th>
                        <td>
                            <em class="sub-txt">전면간판, 돌출간판</em>
                            <em class="sub-txt">와이드 컬러 및 실사</em>
                            <em class="sub-txt">네온(LCD 시공은 상담 후 결정)</em>
                        </td>
                        <td><em class="sub-txt">200</em></td>
                        <td><em class="sub-txt">한시적 지원</em></td>
                    </tr>
                    <tr>
                        <th><strong>인테리어</strong></th>
                        <td>
                            <em class="sub-txt">창업자 직접 시공 가능 (업체 자율/본사의뢰)</em>
                            <strong class="txt-red sub-txt">*인테리어, 디자인 시안 등 가이드라인 제공</strong>
                        </td>
                        <td><em class="sub-txt">3.3m&sup2; 당 150</em></td>
                        <td><em class="sub-txt">조건 충족시<br>자율 시공 가능</em></td>
                    </tr>
                    <tr>
                        <th><strong>주방설비 및 집기</strong></th>
                        <td><em class="sub-txt">튀김기, 탈유대, 싱크대, 업소용 냉장고, 정제기, 주방용품 등</em></td>
                        <td><em class="sub-txt">650</em></td>
                        <td><em class="sub-txt">&dash;</em></td>
                    </tr>
                    <tr>
                        <th><strong>개점 홍보비</strong></th>
                        <td>
                            <em class="sub-txt">개업선물, 오픈전단지</em>
                            <em class="sub-txt">배달 플랫폼을 통한 홍보</em>
                        </td>
                        <td><em class="sub-txt">200</em></td>
                        <td><em class="sub-txt">&dash;</em></td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <th><strong>합계</strong></th>
                        <td><em class="sub-txt">&dash;</em></td>
                        <td><em class="sub-txt">1050~</em></td>
                        <td><em class="sub-txt">최소비용</em></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </article>
</div>


    </section> 
</main>

<footer id="footer">
  <aside class="consult">
      <a href="/sub/sub3-2.php">
          <em>창업문의
              <strong>
                  <span>1588</span>
                  <span>- 6616</span>
              </strong>
          </em>
      </a>
      <a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><strong>창업상담 신청하기</strong></a>
  </aside>
  <button type="button" id="top_btn">
    <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
  </button>
  <div class="inner">
  <h2 class="f-logo"><figure><img src="/img/logo-w.svg" alt="아이벗치킨"></figure></h2>
    <ul class="f-menu">
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=provision">이용약관</a></li>
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=e_mail">이메일무단수집거부</a></li>
        <li><a href="/sub/sub1-4.php">오시는 길</a></li>
    </ul>
    <div class="f-copy">
        <ul class="f-copy-addr">
            <li>아이프랜드 대표자 : 김보경</li>
            <li>
                <address>충북 청주시 서원구 남이면 2순환로 1704 (남이면 가마리 127)</address>
            </li>
            <li>사업자등록번호 315-03-64324</li>
            <li>Tel) 043-291-2389</li>
            <li>Fax) 043-293-9979</li>
        </ul>
        <p class="f-copy-copy">&copy;I-FRIEND CHICKEN. ALL RIGHTS RESERVED.</p>
    </div>
  </div>        
</footer>




    
<script>
$(function() {
    $("#top_btn").on("click", function() {
        $("html, body").animate({scrollTop:0}, '500');
        return false;
    });
});
</script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
