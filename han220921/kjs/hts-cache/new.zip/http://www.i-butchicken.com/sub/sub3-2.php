<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>아이벗치킨</title>

<meta name="keywords" content="청주 맛집,청주 프랜차이즈,청주 치킨,소자본 창업,치킨 프랜차이즈 추천,소자본 프랜차이즈,치킨 창업,아이프랜드,아이벗,아이벗치킨,아이벗 치킨,프랜차이즈,간장치킨,매콤치킨,강정치킨,후라이드치킨,옛날 후라이드 치킨,순살치킨,고상한 파풍기,아이매워,옛날 후라이드,옛날 양념치킨,달콤치킨,화이트 어니언,순살세트,똥집튀김,닭발튀김,웨지감자튀김,크림치즈볼,떡볶이">
<meta name="description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">

<meta property="og:title" content="아이벗치킨">
<meta property="og:type" content="website">
<meta property="og:description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">
<meta property="og:url" content="http://i-butchicken.com">
<meta property="og:image" content="/img/og-image.png">
<title>아이벗치킨</title>
<link rel="stylesheet" href="http://www.i-butchicken.com/css/default.css?ver=220620">
<link rel="stylesheet" href="http://www.i-butchicken.com/js/font-awesome/css/font-awesome.min.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://www.i-butchicken.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://www.i-butchicken.com";
var g5_bbs_url   = "http://www.i-butchicken.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<title>아이벗치킨</title>

<meta name="keywords" content="청주 맛집,청주 프랜차이즈,청주 치킨,소자본 창업,치킨 프랜차이즈 추천,소자본 프랜차이즈,치킨 창업,아이프랜드,아이벗,아이벗치킨,아이벗 치킨,프랜차이즈,간장치킨,매콤치킨,강정치킨,후라이드치킨,옛날 후라이드 치킨,순살치킨,고상한 파풍기,아이매워,옛날 후라이드,옛날 양념치킨,달콤치킨,화이트 어니언,순살세트,똥집튀김,닭발튀김,웨지감자튀김,크림치즈볼,떡볶이">
<meta name="description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">

<meta property="og:title" content="아이벗치킨">
<meta property="og:type" content="website">
<meta property="og:description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">
<meta property="og:url" content="http://i-butchicken.com">
<meta property="og:image" content="/img/og-image.png">

<link rel="shortcut icon" href="/favicon.ico">






<script src="http://www.i-butchicken.com/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/jquery.menu.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/common.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/wrest.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub3.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css">

<script src="https://kit.fontawesome.com/15dfde8f2b.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="/js/header.js"></script>


<div class="skip-nav"><a href="#container">본문 바로가기</a></div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/"><img src="/img/logo-w.svg" alt="아이벗치킨"></a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인 메뉴</h2>
            <ul>
                <li class="depth1"><a href="/sub/sub1-1.php"><span>아이벗스토리</span></a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php"><span>CEO 인사말</span></a></li>
                        <li><a href="/sub/sub1-2.php"><span>브랜드 소개</span></a></li>
                        <li><a href="/sub/sub1-3.php"><span>BI</span></a></li>
                        <li><a href="/sub/sub1-4.php"><span>오시는 길</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>메뉴 소개</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>신메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=chicken_menu"><span>치킨 메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=alcohol_menu"><span>술한잔 메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=side_menu"><span>사이드 메뉴</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="/sub/sub3-1.php"><span>창업 안내</span></a>
                    <ul class="depth2">
                        <li><a href="/sub/sub3-1.php"><span>아이벗의 약속</span></a></li>
                        <li><a href="/sub/sub3-2.php"><span>성공포인트</span></a></li>
                        <li><a href="/sub/sub3-3.php"><span>절차 및 비용</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><span>창업 상담</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>커뮤니티</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=qna"><span>고객의 소리</span></a></li>
                    </ul>
                </li>
            </ul>
            <p class="gnb-bg"></p>
        </nav>
        <ul class="tnb">        
                        <li><a href="http://www.i-butchicken.com/bbs/register.php">회원가입</a></li>
            <li><a href="http://www.i-butchicken.com/bbs/login.php">로그인</a></li>
                    </ul>
        <button type="button" class="all-menu-open">
            <i class="fa-solid fa-bars-staggered"></i>
        </button>
        <nav class="all-menu">
            <h2 class="hidden">모바일 전체메뉴</h2>
            <div class="all-menu-wrap">
                <div class="all-menu-box">
                    <header class="all-menu-header">
                        <h3 class="m-logo"><a href="/"><img src="/img/logo-b.svg" alt="아이벗치킨"></a></h3>
                        <ul class="m-tnb">        
                                                        <li><a href="http://www.i-butchicken.com/bbs/register.php">회원가입</a></li>
                            <li><a href="http://www.i-butchicken.com/bbs/login.php">로그인</a></li>
                                                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult">창업상담</a></li>
                        </ul>
                    </header>
                    <div class="all-menu-body">
                        <ul class="gnb-m">
                            <li class="depth1">
                                <a href="#">
                                    아이벗스토리
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="/sub/sub1-1.php"><span>CEO 인사말</span></a></li>
                                    <li><a href="/sub/sub1-2.php"><span>브랜드 소개</span></a></li>
                                    <li><a href="/sub/sub1-3.php"><span>BI</span></a></li>
                                    <li><a href="/sub/sub1-4.php"><span>오시는 길</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    메뉴 소개
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>신메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=chicken_menu"><span>치킨 메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=alcohol_menu"><span>술한잔 메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=side_menu"><span>사이드 메뉴</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    창업 안내
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="/sub/sub3-1.php"><span>아이벗의 약속</span></a></li>
                                    <li><a href="/sub/sub3-2.php"><span>성공포인트</span></a></li>
                                    <li><a href="/sub/sub3-3.php"><span>절차 및 비용</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><span>창업 상담</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    매장 찾기
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    커뮤니티
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=qna"><span>고객의 소리</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <button type="button" class="all-menu-close">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </nav>
    </div>
</header>

<main id="container">
    <section class="sub-visual">
        <h2 class=hidden>서브비쥬얼</h2>
        <div class="inner">
            <strong class="visual-name"><span>창업 안내</span></strong>
        </div>
    </section>
    <nav class="lnb">
        <h2 class="hidden">서브메뉴</h2>
        <div class="inner">
            <ul class="lnb-list">
                <li><a href="/sub/sub3-1.php">아이벗의 약속</a></li>
                <li><a href="/sub/sub3-2.php">성공포인트</a></li>
                <li><a href="/sub/sub3-3.php">절차 및 비용</a></li>
                <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult">창업 상담</a></li>
            </ul>
        </div>
    </nav>
    <section class="sub-franchise sub-sec">

<script>
  $(function(){
    $('.lnb li').eq(1).addClass('on')
  })
</script>

<h2 class="sub-tit">성공 포인트</h2>
<article class="start sub-article-wide">
    <div class="inner">
        <h3 class="hidden">인트로</h3>
        <div class="start-txt-box">
            <div class="upper-txt-box">
                <p>너무나도 많은 치킨 브랜드 중 고민되신다면,<br><em class="red-highlight">
                소자본 고효율</em>의 합리적인 창업을 원한다면,</p>
            </div>
            <strong><span>아이벗치킨</span>이 도와드립니다.</strong>
        </div>
    </div>
    <figure class="start-img img1"><img src="/img/sub3-2-intro01.png" alt="후라이드치킨"></figure>
    <figure class="start-img img2"><img src="/img/sub3-2-intro02.png" alt="달콤치킨"></figure>
</article>
<article class="low-costs sub-article-wide">
    <div class="inner">
        <h3 class="success-tit sub-sec-tit-big"><em class="sucess-tit-small">아이벗치킨 성공포인트 01</em><strong class="txt-red">소자본 창업</strong>의 끝판왕</h3>
        <strong class="balloon success-sub-tit">부당한 본사 이익은 NO!</strong>
        <strong class="success-sub-tit">정직한 창업 혜택을 통해 <em class="yellow-highlight">창업비용 <span class="dot-highlight">최</span><span class="dot-highlight">소</span><span class="dot-highlight">화</span>!</em></strong>
        <ul class="costs-list">
            <li>
                <strong class="costs-list-tit">
                    <span class="number">1</span>
                    창업의 부담을 가중시키는<em class="txt-red"><br>가맹비 &middot; 로열티</em>는 <em class="txt-red">NO</em>!
                </strong>
                <p class="costs-list-desc sub-txt">
                    가맹점의 부담만 늘리는 불필요한 비용을 확 줄였습니다.<br>아이벗치킨 본사는 무엇보다 가맹점과의 상생을<br>우선으로 생각합니다. 창업의 부담을 줄여드리기 위해<br>가맹비와 로열티는 받지 않겠습니다.
                </p>
            </li>
            <li>
                <strong class="costs-list-tit">
                    <span class="number">2</span>감리비 &middot; 공사 마진 NO!<br><em class="txt-red">실내 인테리어 자유</em>
                </strong>
                <p class="costs-list-desc sub-txt">
                    인테리어 자율 시공 가능. 집기류만 있으면 만사 OK!<br>거품을 걷어낸 실속 있는 인테리어가 가능합니다.<br>아이벗치킨은 인테리어 비용을 통해 본사 수익을<br>전혀 남기지 않습니다.
                </p>                        
            </li>
            <li>
                <strong class="costs-list-tit">
                    <span class="number">3</span>아이벗의 통큰 지원!<br>가맹 계약시 <em class="txt-red">간판 무상지원</em>
                </strong>
                <p class="costs-list-desc sub-txt">
                    창업비용을 한번 더 확 줄일 수 있는 아이벗의 통큰 지원책!<br>가맹 계약시 한시적으로 간판을 무상지원해드립니다.<br>바로 지금만 누릴수 있는 특별한 혜택을 놓치지 마세요!
                </p>
            </li>
        </ul>
    </div>
</article>
<article class="taste sub-article-wide">
    <div class="inner">
        <h3 class="success-tit sub-sec-tit-big"><em class="sucess-tit-small">아이벗치킨 성공포인트 02</em><strong class="txt-red">아이벗</strong>만의 특별한 <strong class="txt-red">맛</strong></h3>
        <ul class="taste-list">
            <li>
                <strong class="taste-list-tit red-radius-bg"><span class="number">비법 01</span>아이벗만의 수제 튀김 파우더</strong>
                <em class="taste-list-quote">아니, 다음날 먹어도<br>이렇게 바삭하다고?</em>
                <p class="taste-list-desc">아이벗이 <em class="yellow-highlight">독자적인 개발</em>을 통해 만든<br>수제 튀김 파우더!</p>
                <p class="taste-list-desc">시간이 지나도 <em class="yellow-highlight">한결같은 맛과 식감</em>을<br>유지할 수 있는 비법입니다.</p>
            </li>
            <li>
                <strong class="taste-list-tit red-radius-bg"><span class="number">비법 02</span>다양한 소스와 부위육</strong>
                <em class="taste-list-quote">무슨 맛을 골라 먹지?<br>부위도 정말 다양하네!</em>
                <p class="taste-list-desc">수십년에 걸쳐 쌓이 노하우로 만들어낸<br><em class="yellow-highlight">7가지 소스</em>와<em class="yellow-highlight">부위육</em>!</p>
                <p class="taste-list-desc">한마리, 다리, 날개, 스페셜, 순살까지<br>다양한 맛과 부위를 골라드세요!</p>
            </li>
            <li>
                <strong class="taste-list-tit red-radius-bg"><span class="number">비법 03</span>아이벗만의 특별한 닭고기</strong>
                <em class="taste-list-quote">이렇게 신선하면서<br>양도 푸짐하다니!</em>
                <p class="taste-list-desc">아이벗치킨은 <em class="yellow-highlight">100% 국내산 냉장육</em>만을<br>사용하여 신선함을 보장합니다.</p>
                <p class="taste-list-desc">또한 <em class="yellow-highlight">11닭을 사용</em>하여 더 크고<br>맛있게 치킨을 즐기실 수 있습니다.</p>
            </li>
        </ul>
    </div>
</article>
<article class="sub-review sub-article-wide">
    <div class="inner">
        <h3 class="sub-review-tit sub-sec-tit-big">아이벗치킨만의<br>막강한 <em class="yellow-highlight">후기 POWER</em></h3>
        <p class="sub-review-desc">지금 당장 배달플랫폼을 켜보세요!<br>리뷰 평점만 보더라도 왜 점주님들이 아이벗을 선택하는지 알 수 있습니다.<br>이렇게 저희 브랜드를 다시 찾아주시는 단골이 많다는 걸 한 눈에 확인할 수 있으니까요.</p>
        <div class="swiper mySwiper sub-review-swiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review01.png" alt="간장치킨 리뷰"></figure>
                </div>
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review02.png" alt="반반치킨 리뷰"></figure>
                </div>
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review03.png" alt="매콤스페셜 리뷰"></figure>
                </div>
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review04.png" alt="반반날개 리뷰"></figure>
                </div>
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review05.png" alt="아이매워 리뷰"></figure>
                </div>
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review06.png" alt="순살치킨 리뷰"></figure>
                </div>
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review07.png" alt="반반스페셜 리뷰"></figure>
                </div>
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review08.png" alt="순살세트 리뷰"></figure>
                </div>
                <div class="swiper-slide">
                <figure><img src="/img/sub3-2-review09.png" alt="순살세트 리뷰"></figure>
                </div>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </div>
</article>
<article class="system sub-article-wide">
    <div class="inner">
        <h3 class="success-tit sub-sec-tit-big"><em class="sucess-tit-small">아이벗치킨 성공포인트 03</em><strong class="txt-red">초보자</strong>도 시작할 수 있는 <strong class="txt-red">창업 시스템</strong></h3>
        <ul class="system-list">
            <li>
                <strong class="system-list-tit success-sub-tit">
                    <span class="number">POINT <span>01</span></span>
                    <em class="red-highlight">전문 상권 분석</em> 시스템
                </strong>
                <p class="system-list-desc sub-txt">
                    아이벗만의 <strong>상권 분석 전문 인력 지원</strong>으로 초기 입점 단계부터 <strong>상권 유형, 고객 유형 상세 분석</strong><br>중복상권 없이 가맹점 출범 가능하여 보다 <strong class="bold">넓은 상권</strong>을 통해 매출 극대화
                </p>
            </li>
            <li>
                <strong class="system-list-tit success-sub-tit">
                    <span class="number">POINT <span>02</span></span>
                    <em class="red-highlight">1:1 교육</em> 시스템
                </strong>
                <p class="system-list-desc sub-txt">
                    실무 위주의 <strong> 1:1 맞춤 소통 교육</strong> 을 제공합니다.<br>이를 통해 아이벗만의 비법 레시피, 매출 증대 노하우 등을 아낌없이 전수해드립니다.
                </p>
            </li>
            <li>
                <strong class="system-list-tit success-sub-tit">
                    <span class="number">POINT <span>03</span></span>
                    지속적인 <em class="red-highlight">관리 &middot; 지원</em> 시스템
                </strong>
                <p class="system-list-desc sub-txt">
                    오픈 후에도 생길 수 있는 고민과 문제점을 해결할 수 있도록 도와드리겠습니다.<br><strong>가맹점이 매출을 증대시킬 수 있도록</strong> 지속적으로 관리하고 지원해드립니다.
                </p>
            </li>
        </ul>
    </div>
</article>
<article class="education sub-article-wide">
    <div class="inner">
        <h3 class="sub-sec-tit-big">
            <em>
                아이벗만의 <span class="dot-highlight">특</span><span class="dot-highlight">급</span> <span class="dot-highlight">교</span><span class="dot-highlight">육</span>시스템
            </em>
            <strong class="red-highlight">직접 찾아가는</strong>1:1 맞춤 소통 교육
        </h3>
        <p>
            어떤 시기에도 점주님께 <span class="dot-highlight">직</span><span class="dot-highlight">접</span> <span class="dot-highlight">찾</span><span class="dot-highlight">아</span><span class="dot-highlight">가</span><span class="dot-highlight">는</span> 아이벗치킨 슈퍼바이저들의 열정은 막을 수 없습니다!<br>직접 오시겠다고요? 아닙니다! 어디시죠? 저희가 가겠습니다!<br>치킨을 맛있게 만드는 법, 매출을 올릴 수 있는 법. 다 알려드리겠습니다.
        </p>
        <p>함께 배우고 알아가봅시다. 기다리고만 계세요!</p>
    </div>
</article>
<article class="zone sub-article-wide">
    <div class="inner">
        <h3 class="success-tit sub-sec-tit-big"><em class="sucess-tit-small">아이벗치킨 성공포인트 04</em>안정적인 <strong class="txt-red">영업 상권 보장</strong></h3>
        <ul class="zone-list">
            <li>
                <strong class="balloon grey">
                    1개의 상권에서 3개 이상 지점이 매출을 나눠 갖는 구조
                </strong>
                <figure class="zone-img img1"><img src="/img/sub3-2-map01.png" alt="타사 영업 상권"></figure>
            </li>
            <li>
                <strong class="balloon red">
                    1개의 상권에 1개 지점 단독 영업 상권 부여
                </strong>
                <figure class="zone-img img2"><img src="/img/sub3-2-map02.png" alt="아이벗치킨 영업 상권"></figure>
            </li>
        </ul>
        <p class="success-sub-tit">배달 영업 <span class="dot-highlight">상</span><span class="dot-highlight">권</span><span class="dot-highlight">보</span><span class="dot-highlight">호</span>를 위해<br>기존 가맹점 상권 구역에 <em class="txt-red">추가 입점</em>을 <em class="txt-red">제한</em>합니다.</p>
        <p class="zone-desc">아이벗치킨에서는 입점 초기 단계에서부터 <em class="yellow-highlight">상권이 중복되는 가맹점이 출범되는 것을 제한</em>하고 있으며<br>관계 법령에 의거하여 상권이 보호될 수 있도록 입점지역을 선정하고 있습니다.<br>보다 넓은 상권을 제공하여 <em class="yellow-highlight">가맹점의 매출을 극대화</em> 시킬 수 있도록 적극적으로 지원해드립니다.</p>
    </div>
</article>
<article class="consulting sub-article-wide">
    <div class="inner">
        <h3 class="success-tit sub-sec-tit-big"><em class="sucess-tit-small">아이벗치킨 성공포인트 05</em><strong class="txt-red">맞춤형</strong> 창업 유형 <strong class="txt-red">컨설팅</strong></h3>
        <ul class="consulting-list">
            <li>
                <div class="consulting-txt-box">
                    <strong class="consulting-list-tit red-radius-bg">매장 특화형</strong>
                    <p class="consulting-list-desc sub-txt">주류 매출로 수익률이 높아지고<br>아파트 단지 등 주거 단지 근처 매장에서<br>높은 매출을 기대할 수 있는 유형</p>
                </div>
            </li>
            <li>
                <div class="consulting-txt-box">
                    <strong class="consulting-list-tit red-radius-bg">배달 특화형</strong>
                    <p class="consulting-list-desc sub-txt">가장 창업비용이 적게 드는 유형으로<br>매장 면적이 적어도 가능<br>투자 대비 효율이 가장 높은 창업 유형</p>
                </div>
            </li>
            <li>
                <div class="consulting-txt-box">
                    <strong class="consulting-list-tit red-radius-bg">복합(배달+매장)형</strong>
                    <p class="consulting-list-desc sub-txt">매장 영업과 배달의 장점을 모두<br>가지고 있으며<br>가장 높은 매출이 기대할 수 있는 유형</p> 
                </div>
            </li>
        </ul>
    </div>
</article>
<article class="waiting sub-article-wide">
    <div class="inner">
        <div class="waiting-box">
            <figure class="waiting-img"><img src="/img/logo-b.svg" alt="아이벗치킨"></figure>
            <p>
                저희들은 언제나 열린 마음으로<br>함께 일하실 점주님들을 <strong>기다리고 있습니다.</strong>
            </p>
            <p>고민들을 <strong>속시원하게 상담</strong>해드립니다.<p>
            <a href="http://jinsongweb.pe.kr/bbs/write.php?bo_table=consult">창업상담 신청하기</a>
            <span></span>
            <span></span>
        </div>
    </div>
</article>




<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
  var swiper = new Swiper(".sub-review-swiper", {
    slidesPerView: "auto",
    spaceBetween: 15,
    centeredSlides: true,
    autoplay: {
    delay: 1700,
    disableOnInteraction: false,
    }, 
    loop: true,
    loopFillGroupWithBlank: false,
   
  });
</script>


    </section> 
</main>

<footer id="footer">
  <aside class="consult">
      <a href="/sub/sub3-2.php">
          <em>창업문의
              <strong>
                  <span>1588</span>
                  <span>- 6616</span>
              </strong>
          </em>
      </a>
      <a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><strong>창업상담 신청하기</strong></a>
  </aside>
  <button type="button" id="top_btn">
    <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
  </button>
  <div class="inner">
  <h2 class="f-logo"><figure><img src="/img/logo-w.svg" alt="아이벗치킨"></figure></h2>
    <ul class="f-menu">
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=provision">이용약관</a></li>
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=e_mail">이메일무단수집거부</a></li>
        <li><a href="/sub/sub1-4.php">오시는 길</a></li>
    </ul>
    <div class="f-copy">
        <ul class="f-copy-addr">
            <li>아이프랜드 대표자 : 김보경</li>
            <li>
                <address>충북 청주시 서원구 남이면 2순환로 1704 (남이면 가마리 127)</address>
            </li>
            <li>사업자등록번호 315-03-64324</li>
            <li>Tel) 043-291-2389</li>
            <li>Fax) 043-293-9979</li>
        </ul>
        <p class="f-copy-copy">&copy;I-FRIEND CHICKEN. ALL RIGHTS RESERVED.</p>
    </div>
  </div>        
</footer>




    
<script>
$(function() {
    $("#top_btn").on("click", function() {
        $("html, body").animate({scrollTop:0}, '500');
        return false;
    });
});
</script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
