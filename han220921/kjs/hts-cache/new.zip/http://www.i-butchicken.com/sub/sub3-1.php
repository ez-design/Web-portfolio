<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" id="meta_viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>아이벗치킨</title>

<meta name="keywords" content="청주 맛집,청주 프랜차이즈,청주 치킨,소자본 창업,치킨 프랜차이즈 추천,소자본 프랜차이즈,치킨 창업,아이프랜드,아이벗,아이벗치킨,아이벗 치킨,프랜차이즈,간장치킨,매콤치킨,강정치킨,후라이드치킨,옛날 후라이드 치킨,순살치킨,고상한 파풍기,아이매워,옛날 후라이드,옛날 양념치킨,달콤치킨,화이트 어니언,순살세트,똥집튀김,닭발튀김,웨지감자튀김,크림치즈볼,떡볶이">
<meta name="description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">

<meta property="og:title" content="아이벗치킨">
<meta property="og:type" content="website">
<meta property="og:description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">
<meta property="og:url" content="http://i-butchicken.com">
<meta property="og:image" content="/img/og-image.png">
<title>아이벗치킨</title>
<link rel="stylesheet" href="http://www.i-butchicken.com/css/default.css?ver=220620">
<link rel="stylesheet" href="http://www.i-butchicken.com/js/font-awesome/css/font-awesome.min.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://www.i-butchicken.com/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://www.i-butchicken.com";
var g5_bbs_url   = "http://www.i-butchicken.com/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<title>아이벗치킨</title>

<meta name="keywords" content="청주 맛집,청주 프랜차이즈,청주 치킨,소자본 창업,치킨 프랜차이즈 추천,소자본 프랜차이즈,치킨 창업,아이프랜드,아이벗,아이벗치킨,아이벗 치킨,프랜차이즈,간장치킨,매콤치킨,강정치킨,후라이드치킨,옛날 후라이드 치킨,순살치킨,고상한 파풍기,아이매워,옛날 후라이드,옛날 양념치킨,달콤치킨,화이트 어니언,순살세트,똥집튀김,닭발튀김,웨지감자튀김,크림치즈볼,떡볶이">
<meta name="description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">

<meta property="og:title" content="아이벗치킨">
<meta property="og:type" content="website">
<meta property="og:description" content="식어도 맛있는 치킨 프랜차이즈, 아이벗치킨입니다.">
<meta property="og:url" content="http://i-butchicken.com">
<meta property="og:image" content="/img/og-image.png">

<link rel="shortcut icon" href="/favicon.ico">






<script src="http://www.i-butchicken.com/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/jquery.menu.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/common.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/wrest.js?ver=221017"></script>
<script src="http://www.i-butchicken.com/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub3.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css">

<script src="https://kit.fontawesome.com/15dfde8f2b.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="/js/header.js"></script>


<div class="skip-nav"><a href="#container">본문 바로가기</a></div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/"><img src="/img/logo-w.svg" alt="아이벗치킨"></a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인 메뉴</h2>
            <ul>
                <li class="depth1"><a href="/sub/sub1-1.php"><span>아이벗스토리</span></a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php"><span>CEO 인사말</span></a></li>
                        <li><a href="/sub/sub1-2.php"><span>브랜드 소개</span></a></li>
                        <li><a href="/sub/sub1-3.php"><span>BI</span></a></li>
                        <li><a href="/sub/sub1-4.php"><span>오시는 길</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>메뉴 소개</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>신메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=chicken_menu"><span>치킨 메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=alcohol_menu"><span>술한잔 메뉴</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=side_menu"><span>사이드 메뉴</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="/sub/sub3-1.php"><span>창업 안내</span></a>
                    <ul class="depth2">
                        <li><a href="/sub/sub3-1.php"><span>아이벗의 약속</span></a></li>
                        <li><a href="/sub/sub3-2.php"><span>성공포인트</span></a></li>
                        <li><a href="/sub/sub3-3.php"><span>절차 및 비용</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><span>창업 상담</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a></li>
                    </ul>
                </li>
                <li class="depth1"><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>커뮤니티</span></a>
                    <ul class="depth2">
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=qna"><span>고객의 소리</span></a></li>
                    </ul>
                </li>
            </ul>
            <p class="gnb-bg"></p>
        </nav>
        <ul class="tnb">        
                        <li><a href="http://www.i-butchicken.com/bbs/register.php">회원가입</a></li>
            <li><a href="http://www.i-butchicken.com/bbs/login.php">로그인</a></li>
                    </ul>
        <button type="button" class="all-menu-open">
            <i class="fa-solid fa-bars-staggered"></i>
        </button>
        <nav class="all-menu">
            <h2 class="hidden">모바일 전체메뉴</h2>
            <div class="all-menu-wrap">
                <div class="all-menu-box">
                    <header class="all-menu-header">
                        <h3 class="m-logo"><a href="/"><img src="/img/logo-b.svg" alt="아이벗치킨"></a></h3>
                        <ul class="m-tnb">        
                                                        <li><a href="http://www.i-butchicken.com/bbs/register.php">회원가입</a></li>
                            <li><a href="http://www.i-butchicken.com/bbs/login.php">로그인</a></li>
                                                        <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult">창업상담</a></li>
                        </ul>
                    </header>
                    <div class="all-menu-body">
                        <ul class="gnb-m">
                            <li class="depth1">
                                <a href="#">
                                    아이벗스토리
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="/sub/sub1-1.php"><span>CEO 인사말</span></a></li>
                                    <li><a href="/sub/sub1-2.php"><span>브랜드 소개</span></a></li>
                                    <li><a href="/sub/sub1-3.php"><span>BI</span></a></li>
                                    <li><a href="/sub/sub1-4.php"><span>오시는 길</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    메뉴 소개
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=new_menu"><span>신메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=chicken_menu"><span>치킨 메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=alcohol_menu"><span>술한잔 메뉴</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=side_menu"><span>사이드 메뉴</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    창업 안내
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="/sub/sub3-1.php"><span>아이벗의 약속</span></a></li>
                                    <li><a href="/sub/sub3-2.php"><span>성공포인트</span></a></li>
                                    <li><a href="/sub/sub3-3.php"><span>절차 및 비용</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><span>창업 상담</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    매장 찾기
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=branch"><span>매장 찾기</span></a></li>
                                </ul>
                            </li>
                            <li class="depth1">
                                <a href="#">
                                    커뮤니티
                                    <i class="fa-solid fa-chevron-down"></i>
                                </a>
                                <ul class="depth2">
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=notice"><span>공지사항</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/board.php?bo_table=event"><span>이벤트</span></a></li>
                                    <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=qna"><span>고객의 소리</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <button type="button" class="all-menu-close">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </nav>
    </div>
</header>

<main id="container">
    <section class="sub-visual">
        <h2 class=hidden>서브비쥬얼</h2>
        <div class="inner">
            <strong class="visual-name"><span>창업 안내</span></strong>
        </div>
    </section>
    <nav class="lnb">
        <h2 class="hidden">서브메뉴</h2>
        <div class="inner">
            <ul class="lnb-list">
                <li><a href="/sub/sub3-1.php">아이벗의 약속</a></li>
                <li><a href="/sub/sub3-2.php">성공포인트</a></li>
                <li><a href="/sub/sub3-3.php">절차 및 비용</a></li>
                <li><a href="http://i-butchicken.com/bbs/write.php?bo_table=consult">창업 상담</a></li>
            </ul>
        </div>
    </nav>
    <section class="sub-franchise sub-sec">
<script>
  $(function(){
    $('.lnb li').eq(0).addClass('on')
  })
</script>

<div class="inner promise">
    <h2 class="sub-tit">아이벗의 약속</h2>
    <div class="sub-article-narrow">
        <ul class="promise-list">
            <li>
                <div class="promise-txt-box"> 
                    <strong class="sub-sec-tit-small"><span class="promise-number">01</span>아이벗치킨은 <span class="txt-red">가맹비 &middot; 로열티</span>가 없습니다.</strong>
                    <p class="sub-txt">아이벗치킨은 가맹점주님들의 부담을 덜어드리기 위해서<br>가맹비와 로열티를 따로 요구하지 않습니다.</p>
                </div>
                <div class="promise-img-box">
                    <figure class="promise-img"><img src="/img/sub3-1-img1.png" alt=""></figure>
                </div>
            </li>
            <li>
                <div class="promise-txt-box"> 
                    <strong class="sub-sec-tit-small"><span class="promise-number">02</span>인테리어와 시설&sol;설비 품목을 <span class="txt-red">강매</span>하지 않습니다</strong>
                    <p class="sub-txt">개점 시 인테리어에 최소한의 가이드라인만을 제공하며 자율 시공이 가능합니다.</p>
                    <p class="sub-txt">또한 주기적으로 리모델링을 강요하지도 않습니다.</p>
                    <p class="sub-txt">필요한 시설과 설비 품목으로 이윤을 남기지 않으며 투명하게 공개합니다.</p>
                </div>
                <div class="promise-img-box">
                    <figure class="promise-img"><img src="/img/sub3-1-img2.png" alt=""></figure>
                </div>
            </li>
            <li>
                <div class="promise-txt-box"> 
                    <strong class="sub-sec-tit-small"><span class="promise-number">03</span>매출이 <span class="txt-red">성장</span>할 수 있도록 꾸준히 <span class="txt-red">지원</span>해드리겠습니다.</strong>
                    <p class="sub-txt">점포별로 상권에 최적화된 광고를 진행할 수 있도록 지원해드립니다.</p>
                    <p class="sub-txt">오랜 시간 동안 쌓아온 아이벗만의 노하우로<br>꾸준히 매출이 증가할 수 있도록 도와드릴 것을 약속드립니다.</p>
                </div>
                <div class="promise-img-box">
                    <figure class="promise-img"><img src="/img/sub3-1-img3.png" alt=""></figure>
                </div>
            </li>
            <li>
                <div class="promise-txt-box"> 
                    <strong class="sub-sec-tit-small"><span class="promise-number">04</span>아이벗치킨은 항상 점주님들과 <span class="txt-red">소통</span>하겠습니다.</strong>
                    <p class="sub-txt">본사의 갑질이나 물품 강매는 일절 없을 것이라고 자신있게 약속드립니다.</p>
                    <p class="sub-txt">본사에서는 항상 점주님들과 소통하여 문의사항, 불만사항에 귀를 기울이겠습니다.
                    </p>
                </div>
                <div class="promise-img-box">
                    <figure class="promise-img"><img src="/img/sub3-1-img4.png" alt=""></figure>
                </div>
            </li>
        </ul>
    </div>
</div>


    </section> 
</main>

<footer id="footer">
  <aside class="consult">
      <a href="/sub/sub3-2.php">
          <em>창업문의
              <strong>
                  <span>1588</span>
                  <span>- 6616</span>
              </strong>
          </em>
      </a>
      <a href="http://i-butchicken.com/bbs/write.php?bo_table=consult"><strong>창업상담 신청하기</strong></a>
  </aside>
  <button type="button" id="top_btn">
    <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
  </button>
  <div class="inner">
  <h2 class="f-logo"><figure><img src="/img/logo-w.svg" alt="아이벗치킨"></figure></h2>
    <ul class="f-menu">
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=provision">이용약관</a></li>
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
        <li><a href="http://www.i-butchicken.com/bbs/content.php?co_id=e_mail">이메일무단수집거부</a></li>
        <li><a href="/sub/sub1-4.php">오시는 길</a></li>
    </ul>
    <div class="f-copy">
        <ul class="f-copy-addr">
            <li>아이프랜드 대표자 : 김보경</li>
            <li>
                <address>충북 청주시 서원구 남이면 2순환로 1704 (남이면 가마리 127)</address>
            </li>
            <li>사업자등록번호 315-03-64324</li>
            <li>Tel) 043-291-2389</li>
            <li>Fax) 043-293-9979</li>
        </ul>
        <p class="f-copy-copy">&copy;I-FRIEND CHICKEN. ALL RIGHTS RESERVED.</p>
    </div>
  </div>        
</footer>




    
<script>
$(function() {
    $("#top_btn").on("click", function() {
        $("html, body").animate({scrollTop:0}, '500');
        return false;
    });
});
</script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
