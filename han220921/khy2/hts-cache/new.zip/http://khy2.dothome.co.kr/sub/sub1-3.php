<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>프랭크버거</title>
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/css/default.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://khy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://khy2.dothome.co.kr";
var g5_bbs_url   = "http://khy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<script src="http://khy2.dothome.co.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/common.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/wrest.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>
<meta name="keywords" content="수제버거, 수제버거창업, 프랭크버거, 햄버거, 햄버거창업, 버거창업, 수제햄버거, 버거">
<meta name="description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:title" content="대한민국 수제버거 No.1 프랭크 버거">
<meta property="og:type" content="website">
<meta property="og:description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:image" content="/img/bi.jpg">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="/css/font.css">
<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub1.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/js/jquery.vide.js"></script>
<script src="https://kit.fontawesome.com/50dc02b2ac.js" crossorigin="anonymous"></script>

<div class="skip-nav">
    <a href="#main">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/">프랭크버거</a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인메뉴</h2>
            <ul>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거</dt>
                        <dd class="gnb-start-desc">정통 미국식<br><span>프랭크</span> 치즈버거</dd>
                    </dl>
                    <a href="/sub/sub1-1.php">브랜드소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php">프랭크 버거</a></li>
                        <li><a href="/sub/sub1-2.php">특별함의 이유</a></li>
                        <li><a href="/sub/sub1-3.php">경영철학</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 메뉴</dt>
                        <dd class="gnb-start-desc">프랭크버거 만의<br><span>특화</span>된 메뉴</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">메뉴소개</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">Single</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery2">Side</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery3">Set</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 매장</dt>
                        <dd class="gnb-start-desc"><span>가까운</span> 매장을<br>찾아보세요</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">매장찾기</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">가까운 매장찾기</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=newstore">신규매장</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=partner">오픈예정</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=excellent">우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 소식</dt>
                        <dd class="gnb-start-desc">빠르게 만나는<br>프랭크 <span>최신 소식</span></dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">뉴스</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">새소식</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=event">이벤트</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube">홍보광고</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=instagram">SNS</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube2">성공스토리</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 회사</dt>
                        <dd class="gnb-start-desc">명품 브랜드<br>프랭크 <span>F&B</span></dd>
                    </dl>
                    <a href="/sub/sub5-1.php">회사소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub5-1.php">프랭크 F&B</a></li>
                        <li><a href="/sub/sub5-2.php">본사 시스템</a></li>
                        <li><a href="/sub/sub5-3.php">연혁</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 창업</dt>
                        <dd class="gnb-start-desc">체계적인 프랜차이즈<br>프랭크버거 <span>창업하기</span></dd>
                    </dl>
                    <a href="/sub/sub6-1.php">창업안내</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub6-1.php">창업 성공전략</a></li>
                        <li><a href="/sub/sub6-2.php">창업 아카데미</a></li>
                        <li><a href="/sub/sub6-3.php">창업조건 및 비용</a></li>
                        <li><a href="/sub/sub6-4.php">창업자금 지원</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=qa">가맹FAQ</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/qawrite.php">가맹상담</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <p class="gnb-bg"></p>
        <nav class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://khy2.dothome.co.kr/bbs/register.php">회원가입</a></li>
                <li>
                    <a href="http://khy2.dothome.co.kr/bbs/login.php">로그인<figure><img src="/img/tnb-icon.png" alt=""></figure></a></li>
                            </ul>
        </nav>
    </div>
</header>

<main id="brand">
    <h2 class="hidden">브랜드소개</h2>
    <section class="visual">
        <div class="inner">
            <strong>브랜드소개</strong>
            <em>정통 미국식 프리미엄 치즈버거</em>
        </div>
    </section>
    <nav class="lnb">
        <div class="inner">
            <ul class="lnb-list">
                <li><a href="/sub/sub1-1.php">프랭크버거</a></li>
                <li><a href="/sub/sub1-2.php">특별함의 이유</a></li>
                <li><a href="/sub/sub1-3.php">경영철학</a></li>
            </ul>
        </div>
    </nav>
    <section class="sec inner">
<script>
    $(function(){
        $('.lnb-list li').removeClass('on')
        $('.lnb-list li').eq(2).addClass('on')
    })
</script>

<header class="sub-header">
    <h3 class="sub-tit">프랭크 <span>경영철학</span></h3>
    <p class="sub-desc">(주)Frank F&B 경영철학에서 성공을 보다.</p>
</header>
<div class="management-desc">
    <p>프랭크버거의 성공은 그냥 어느 날 우연히 이루어진 게 아닙니다. </p>
    <p>무한 책임과 노력, 그리고 가맹점을 우선하고 실천하는 문화를 정착시켰기 때문에 많은 가맹점으로부터 인정받은 것입니다.</p>
</div>
<article class="management-vision">
    <h4 class="hidden">프랭크F&B VISION</h4>
    <div class="management-vision-infographic">
        <strong>FRANK</strong>
        <ul class="clearfix">
            <li>신뢰</li>
            <li>예의</li>
            <li>도전</li>
        </ul>
    </div>
    <ul class="management-vision-wrap">
        <li class="management-vision-list clearfix">
            <strong>신뢰</strong>
            <div class="management-vision-desc">
                <p>약속은 반드시 이행합니다.</p>
                <p>정직한 마음과 프랭크버거의 자부심을 바탕으로 꾸준히 성장하는 햄버거 브랜드로 나아가겠습니다.</p>
            </div>
        </li>
        <li class="management-vision-list clearfix">
            <strong>예의</strong>
            <div class="management-vision-desc">
                <p>가맹점은 회사의 주주이므로 예로 섬깁니다.</p>
                <p>프랭크버거와 함께해주시는 고객님과 가맹점주님, 파트타이머와 임직원까지 모두의 곁에서 믿음직한 상생 파트너로서 최선을 다하겠습니다.</p>
            </div>
        </li>
        <li class="management-vision-list clearfix">
            <strong>도전</strong>
            <div class="management-vision-desc">
                <p>잘못된 것은 모두 다 바꾸겠습니다.</p>
                <p>실패에 대한 두려움보다는 자신감 있는 도전으로 이유 있는 변화를 만들어냅니다.  합리적인 가격을 선보였던 도전정신으로 의미 있는 변화들을 만들어 나가겠습니다.</p>
            </div>
        </li>
    </ul>
</article>
<article class="real-burger">
    <h4 class="sub-article-tit">진짜 수제 버거! 바로 이런 버거!</h4>
    <ul class="real-burger-wrap clearfix">
        <li class="real-burger-list">
            <strong>100%<br>쇠고기 패티</strong>
            <p>신선하고 믿을 수 있는 100% 소고기로 매장에서 직접 조리하는 건강한 수제 패티입니다.</p>
        </li>
        <li class="real-burger-list">
            <strong>직접 굽는<br>흑미 빵</strong>
            <p>천연효모로 자연발효시키고 진도산 무농약 흑미를 더한 반죽으로 매장에서 매일 직접 구워냅니다.</p>
        </li>
        <li class="real-burger-list">
            <strong>매일 아침<br>신선 야채</strong>
            <p>매일 이른 아침 배송 받은 신선한 야채와 국내산 토마토를 사용해서 맛과 영양이 뛰어납니다.</p>
        </li>
        <li class="real-burger-list">
            <strong>건강한<br>수제 소스</strong>
            <p>화학조미료와 첨가물을 최소화하여 건강하게 만든 소스를 사용합니다.</p>
        </li>
        <li class="real-burger-list">
            <strong>유기농<br>목장의 우유</strong>
            <p>친환경 목장에서 키운 유기농 우유로 건강하고 맛있는 음료를 만듭니다.</p>
        </li>
    </ul>
</article>
<article class="interior">
    <h4 class="sub-article-tit">인테리어</h4>
    <div class="interior-desc">
        <p>트렌디하고 감각적인 공간 디자인과 전략적인 아이덴티티의 배치로 고객들의 시선을 끌고 만족감을 높입니다</p>
        <p>전문점의 공간 활용도를 높인 카운터 일체화, 편안하고 모던한 느낌의 공간 그리고 건강을 먼저 생각하는 청결한 브랜드 이미지를 위한 화이트&에메랄드 컬러를 사용하였습니다.</p>
    </div>
    <ul class="interior-detail clearfix">
        <li class="interior-detail-list">
            <strong>그린과 에메랄드로<br>맑고 통통튀는 브랜드 이미지</strong>
            <p>외부 파사드는 그린과 에메랄드, 두 가지 컬러를 사용하여 위생적이고 건강한 수제버거 전문점임을 드러냅니다. <br>내부의 가구는 자작나무를 사용하여 자연 친화적이고 따뜻한 색감을 연출하고, 바닥과 벽면 조명 등이 조화롭게 브랜드 컬러를 강조하는 전략적인 인테리어 디자인을 선보이고 있습니다.</p>
            <figure class="interior-detail-img"><img src="/img/sub/interior1.jpg" alt="FRANK BURGER"></figure>
        </li>
        <li class="interior-detail-list">
            <strong>시선을 사로잡고<br>고객을 끌어들이는 간판</strong>
            <p>간판부의 상하좌우에 초록 직선을 평행으로 배치하여 간판을 좀 더 안정감 있게 잡아주었으며, 가운데 햄버거 아이콘을 배치해 브랜드의 상징인 햄버거를 강조하며 시선을 사로잡습니다.<br> 미니멀하고 트렌디한 이미지의 간판이 브랜드에 대한 고객의 신뢰도를 높입니다.</p>
            <figure class="interior-detail-img"><img src="/img/sub/interior2.jpg" alt="FRANK BURGER Handmade Cheeseburger"></figure>
        </li>
        <li class="interior-detail-list">
            <strong>브랜드의 경쟁력을 드러내는<br>시각 디자인</strong>
            <p>프랭크버거는 브랜드 아이덴티티를 선명하게 드러내고,<br>다른 곳과 확연히 다른 버거의 퀄리티와 이를 완성하기 위한 노력들을 다양한 시각 디자인으로 표현하고 있습니다.<br>인쇄물과 포스터, POP 등 고객들의 시선이 닿는 곳마다 브랜드의 경쟁력을 효과적으로 배치하고 있습니다.</p>
            <figure class="interior-detail-img"><img src="/img/sub/interior3.jpg" alt="FRANK"></figure>
        </li>
    </ul>
</article>

</section>
</main>

<footer id="footer">
    <button type="button" id="top_btn">
        <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
    </button>
    <div class="inner">
        <h2 class="f-logo">(주)프랭크 에프앤비</h2>
        <ul class="f-menu">
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=provision">이용약관</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=email">이메일무단수집거부</a></li>
        </ul>
        <div class="f-center">
            <em>고객지원 및 상담센터</em>
            <strong>1544 - 7733</strong>
            <p>평일 09:00 ~ 18:00 / 점심 12:00 ~ 13:00<br>(토요일 / 일요일 / 공휴일 휴무)</p>
        </div>
        <div class="f-link">
            <div class="f-link-sns">
                <a href="https://www.instagram.com/frankburger_official_/">인스타그램</a>
                <a href="https://www.youtube.com/channel/UCo3DjdEjQrr8uD_-YUt8mnA">유튜브</a>
                <a href="https://blog.naver.com/bpr2012">네이버 블로그</a>
            </div>
            <div class="f-link-family">
                <a href="http://co-tabe.co.kr/">코앤타베</a>
                <a href="http://bapuri.co.kr/new2/">밥푸리</a>
            </div>
        </div>
        <ul class="f-info">
            <li class="f-info-addr"><address>(주)프랭크 에프앤비 사업자번호 : 130-86-76090 경기도 부천시 옥산로 181</address></li>
            <li class="f-info-copy">COPYRIGHT ⓒ 2019 FRANK F&B. All Rights Reserved.</li>
        </ul>
    </div>
</footer>

    <script>
        $(function() {
            $("#top_btn").on("click", function() {
                $("html, body").animate({scrollTop:0}, '500');
                return false;
            });
        });
    </script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        });
    </script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
