<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>프랭크버거</title>
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/css/default.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://khy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://khy2.dothome.co.kr";
var g5_bbs_url   = "http://khy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<script src="http://khy2.dothome.co.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/common.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/wrest.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>
<meta name="keywords" content="수제버거, 수제버거창업, 프랭크버거, 햄버거, 햄버거창업, 버거창업, 수제햄버거, 버거">
<meta name="description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:title" content="대한민국 수제버거 No.1 프랭크 버거">
<meta property="og:type" content="website">
<meta property="og:description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:image" content="/img/bi.jpg">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="/css/font.css">
<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub5.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/js/jquery.vide.js"></script>
<script src="https://kit.fontawesome.com/50dc02b2ac.js" crossorigin="anonymous"></script>

<div class="skip-nav">
    <a href="#main">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/">프랭크버거</a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인메뉴</h2>
            <ul>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거</dt>
                        <dd class="gnb-start-desc">정통 미국식<br><span>프랭크</span> 치즈버거</dd>
                    </dl>
                    <a href="/sub/sub1-1.php">브랜드소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php">프랭크 버거</a></li>
                        <li><a href="/sub/sub1-2.php">특별함의 이유</a></li>
                        <li><a href="/sub/sub1-3.php">경영철학</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 메뉴</dt>
                        <dd class="gnb-start-desc">프랭크버거 만의<br><span>특화</span>된 메뉴</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">메뉴소개</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">Single</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery2">Side</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery3">Set</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 매장</dt>
                        <dd class="gnb-start-desc"><span>가까운</span> 매장을<br>찾아보세요</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">매장찾기</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">가까운 매장찾기</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=newstore">신규매장</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=partner">오픈예정</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=excellent">우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 소식</dt>
                        <dd class="gnb-start-desc">빠르게 만나는<br>프랭크 <span>최신 소식</span></dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">뉴스</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">새소식</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=event">이벤트</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube">홍보광고</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=instagram">SNS</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube2">성공스토리</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 회사</dt>
                        <dd class="gnb-start-desc">명품 브랜드<br>프랭크 <span>F&B</span></dd>
                    </dl>
                    <a href="/sub/sub5-1.php">회사소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub5-1.php">프랭크 F&B</a></li>
                        <li><a href="/sub/sub5-2.php">본사 시스템</a></li>
                        <li><a href="/sub/sub5-3.php">연혁</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 창업</dt>
                        <dd class="gnb-start-desc">체계적인 프랜차이즈<br>프랭크버거 <span>창업하기</span></dd>
                    </dl>
                    <a href="/sub/sub6-1.php">창업안내</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub6-1.php">창업 성공전략</a></li>
                        <li><a href="/sub/sub6-2.php">창업 아카데미</a></li>
                        <li><a href="/sub/sub6-3.php">창업조건 및 비용</a></li>
                        <li><a href="/sub/sub6-4.php">창업자금 지원</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=qa">가맹FAQ</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/qawrite.php">가맹상담</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <p class="gnb-bg"></p>
        <nav class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://khy2.dothome.co.kr/bbs/register.php">회원가입</a></li>
                <li>
                    <a href="http://khy2.dothome.co.kr/bbs/login.php">로그인<figure><img src="/img/tnb-icon.png" alt=""></figure></a></li>
                            </ul>
        </nav>
    </div>
</header>

<main id="company">
    <h2 class="hidden">회사소개</h2>
    <section class="visual">
        <div class="inner">
            <strong>회사소개</strong>
            <em>명품 브랜드 완성을 위해 노력하는 F&B</em>
        </div>
    </section>
    <nav class="lnb">
        <div class="inner">
            <ul class="lnb-list">
                <li class="on"><a href="/sub/sub5-1.php">프랭크 F&B</a></li>
                <li><a href="/sub/sub5-2.php">본사 시스템</a></li>
                <li><a href="/sub/sub5-3.php">연혁</a></li>
            </ul>
        </div>
    </nav>
    <section class="sec inner">
<script>
    $(function(){
        $('.lnb-list li').removeClass('on')
        $('.lnb-list li').eq(2).addClass('on')
    })
</script>

<header class="sub-header">
    <h3 class="sub-tit">프랭크 F&B <span>연혁</span></h3>
    <p class="sub-desc">㈜프랭크 F&B가 2012년부터 걸어온 길</p>
</header>
<ul class="history-wrap">
    <strong>FRANK</strong>
    <li class="history-list">
        <strong class="history-list-tit">2022</strong>
        <div class="history-list-txt">
            <p>2022년 하반기 부천시 복지공간, 혜림 나눔 캠페인 후원</p>
            <p>2022 KFA 한국프랜차이즈산업협회 회장상 수상</p>
            <p>프랭크버거 2022년 하반기 신메뉴 출시</p>
            <p>프랭크버거 전국 550호점 돌파</p>
            <p>수재민 돕기 성금 2,000만원 기부(전국재해구호협회)</p>
            <p>IBK 기업은행 동반자상 수상</p>
            <p>2022 스포츠조선 고객만족도 1위 수상</p>
            <p>KBS2 TV 예능 '1박2일' 협찬, 일일드라마 ‘황금가면’ PPL 제작지원</p>
            <p>2022년 상반기 부천시 복지공간, 혜림 나눔 캠페인 후원</p>
            <p>부천시 모퉁이쉼터 나눔 캠페인 후원</p>
            <p>BMW 경품 이벤트 지원</p>
            <p>김종국 전속모델 확정 & 홍보·광고 지원</p>
            <p>2022 KBPA 한국브랜드선호도 1위 수상</p>
        </div>
        <figure class="history-list-img"><img src="/img/sub/history-2022.jpg" alt="프랭크버거 2대 전속모델 김종국"></figure>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2021</strong>
        <div class="history-list-txt">
            <p>본사 확장이전 (경기도 부천시 옥산로 181)</p>
            <p>프랭크버거 전국 200호점 돌파</p>
            <p>KBS 라디오 '프랭크버거 CM송' 홍보 광고 지원</p>
            <p>공중파 & 케이블 TV CF 광고 송출 지원</p>
            <p>미스터트롯 나태주 전속모델 발탁</p>
            <p>2021 KCA 프랜차이즈 어워즈 수상</p>
            <p>SBS 라디오 '조정식의 펀펀투데이', '배성재의 텐' 홍보 광고 지원</p>
            <p>SBS 라디오 '이준의 영스트리트' 홍보 광고 지원</p>
            <p>이천 아동복지시설 나눔 캠페인 후원</p>
            <p>부천시 취약계층 아동 간식 나눔 캠페인 후원</p>
            <p>'씀씀이가 바른기업 선정' by 대한적십자사</p>
        </div>
        <figure class="history-list-img"><img src="/img/sub/history-2021.jpg" alt="프랭크버거 1대 전속모델 나태주"></figure>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2020</strong>
        <div class="history-list-txt">
            <p>프랭크버거 전국 60호점 돌파</p>
            <p>2020 한국프랜차이즈 대상 수상</p>
            <p>햄버거 패티 자동화 생산라인 구축</p>
            <p>중앙일보 후원 2020년 올해의 브랜드 대상 수상</p>
            <p>종합식품쇼핑몰 '바푸리 담짜몰' 론칭</p>
            <p>착한프랜차이즈 선정 by 한국공정거래조정원</p>
            <p>SBS '생활의 달인', '좋은아침' 홍보 광고 지원</p>
            <p>SBS 라디오 '이준의 영스트리트', '황제성의 레디요 팡팡' 홍보 광고 지원</p>
            <p>KBS '1박2일' 홍보광고 지원</p>
        </div>
        <figure class="history-list-img"><img src="/img/sub/history-2020.jpg" alt=""></figure>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2019</strong>
        <div class="history-list-txt">
            <p>프랭크버거 목동직영점 오픈</p>
            <p>KBS 시니어토크쇼 '황금연못' 방송촬영</p>
        </div>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2018</strong>
        <div class="history-list-txt">
            <p>프랭크버거 연구센터 설립</p>
            <p>프랭크버거 브랜드 런칭</p>
            <p>프랭크버거 브랜드 런칭 착수(미국현지답사)</p>
        </div>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2017</strong>
        <div class="history-list-txt">
            <p>2017 바푸리 신컨셉 리뉴얼 론칭</p>
            <p>양준혁 바푸리 전속모델 선정</p>
            <p>신메뉴 5종 숯불김밥 시리즈 출시</p>
            <p>바푸리포 베트남쌀국수 런칭 및 전국 50호점 돌파</p>
            <p>바푸리 베이커리사업부 발족</p>
        </div>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2016</strong>
        <div class="history-list-txt">
            <p>MBC ‘서프라이즈’, SBS ‘스타킹’, ‘생활의달인’, KBS ‘생생정보’ 협찬광고</p>
            <p>바푸리 TV-CF공모전 실시</p>
            <p>㈜BPR ‘식품개발연구소’ 기업부설연구소 인증서 취득</p>
        </div>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2015</strong>
        <div class="history-list-txt">
            <p>대한민국 브랜드스타 수상</p>
            <p>품질경영시스템 국제규격 ‘ISO 9001’인증 취득</p>
            <p>하계 신메뉴 출시 및 홍보 마케팅 지원</p>
            <p>1/4분기 위생점검 완료</p>
            <p>신학기 이벤트 장학금 전달 완료</p>
            <p>바푸리전국 300호점 돌파</p>
            <p>바푸리 상반기 가맹점 간담회 완료</p>
            <p>바푸리 가맹점 발전위원회 발족</p>
            <p>여성소비자가 뽑은 프리미엄 브랜드 대상 수상</p>
        </div>
        <figure class="history-list-img"><img src="/img/sub/history-2015.jpg" alt=""></figure>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2014</strong>
        <div class="history-list-txt">
            <p>바푸리 우수가맹점 선정 및 시상</p>
            <p>사회적 약자, 불우이웃 장학금 수여 및 사랑의 쌀 전달식</p>
            <p>KBS 방송 ‘1박2일’, ‘연예가중계’ TV 홍보 광고 지원</p>
            <p>JTBC 방송 ‘대단한 시집’ TV 홍보 광고 지원</p>
            <p>바푸리 전국 200호점 돌파</p>
            <p>4월 1일 부산 사업본부 출범</p>
            <p>바푸리 C.F광고 지원</p>
            <p>2014년 바푸리 동계 신메뉴 출시 완료</p>
            <p>MBC ‘압구정 백야’, KBS ‘달콤한비밀’ 광고 및 제작지원</p>
            <p>12월 1일 호남 사업본부 출범</p>
        </div>
        <figure class="history-list-img"><img src="/img/sub/history-2014.jpg" alt=""></figure>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2013</strong>
        <div class="history-list-txt">
            <p>바푸리 홍대직영점 오픈</p>
            <p>서울경제TV ‘조영구의 트랜드 핫 이슈’ 방영</p>
            <p>조선일보, 중앙일보, 동아일보 등 주요 일간지 및 인터넷 광고 지원</p>
            <p>MBC 라디오 ‘싱글벙글쇼’, ‘지금은 라디오 시대’ 홍보 광고 지원</p>
            <p>2013년 바푸리 동계 신메뉴 출시 완료</p>
            <p>‘나도 파워블로거’ 이벤트 지원</p>
            <p>‘바푸리 맛 평가단’ 이벤트 지원</p>
            <p>‘누가누가잘하나’ 크리스마스 이벤트 지원</p>
            <p>바푸리 전국 50호점 돌파</p>
        </div>
        <figure class="history-list-img"><img src="/img/sub/history-2013.jpg" alt=""></figure>
    </li>
    <li class="history-list">
        <strong class="history-list-tit">2012</strong>
        <div class="history-list-txt">
            <p>MBC 라디오 ‘2시만세 싱글벙글쇼’ 광고협찬</p>
            <p>육류구이기 실용 신안 등록 완료</p>
            <p>좋은 재료, 좋은 음식 바푸리 브랜드 런칭 착수</p>
            <p>한국프랜차이즈협회 부회장 취임</p>
        </div>
    </li>
</ul>

</section>
</main>

<footer id="footer">
    <button type="button" id="top_btn">
        <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
    </button>
    <div class="inner">
        <h2 class="f-logo">(주)프랭크 에프앤비</h2>
        <ul class="f-menu">
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=provision">이용약관</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=email">이메일무단수집거부</a></li>
        </ul>
        <div class="f-center">
            <em>고객지원 및 상담센터</em>
            <strong>1544 - 7733</strong>
            <p>평일 09:00 ~ 18:00 / 점심 12:00 ~ 13:00<br>(토요일 / 일요일 / 공휴일 휴무)</p>
        </div>
        <div class="f-link">
            <div class="f-link-sns">
                <a href="https://www.instagram.com/frankburger_official_/">인스타그램</a>
                <a href="https://www.youtube.com/channel/UCo3DjdEjQrr8uD_-YUt8mnA">유튜브</a>
                <a href="https://blog.naver.com/bpr2012">네이버 블로그</a>
            </div>
            <div class="f-link-family">
                <a href="http://co-tabe.co.kr/">코앤타베</a>
                <a href="http://bapuri.co.kr/new2/">밥푸리</a>
            </div>
        </div>
        <ul class="f-info">
            <li class="f-info-addr"><address>(주)프랭크 에프앤비 사업자번호 : 130-86-76090 경기도 부천시 옥산로 181</address></li>
            <li class="f-info-copy">COPYRIGHT ⓒ 2019 FRANK F&B. All Rights Reserved.</li>
        </ul>
    </div>
</footer>

    <script>
        $(function() {
            $("#top_btn").on("click", function() {
                $("html, body").animate({scrollTop:0}, '500');
                return false;
            });
        });
    </script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        });
    </script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
