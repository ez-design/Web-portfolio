<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>프랭크버거</title>
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/css/default.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://khy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://khy2.dothome.co.kr";
var g5_bbs_url   = "http://khy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<script src="http://khy2.dothome.co.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/common.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/wrest.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>
<meta name="keywords" content="수제버거, 수제버거창업, 프랭크버거, 햄버거, 햄버거창업, 버거창업, 수제햄버거, 버거">
<meta name="description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:title" content="대한민국 수제버거 No.1 프랭크 버거">
<meta property="og:type" content="website">
<meta property="og:description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:image" content="/img/bi.jpg">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="/css/font.css">
<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub6.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/js/jquery.vide.js"></script>
<script src="https://kit.fontawesome.com/50dc02b2ac.js" crossorigin="anonymous"></script>

<div class="skip-nav">
    <a href="#main">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/">프랭크버거</a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인메뉴</h2>
            <ul>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거</dt>
                        <dd class="gnb-start-desc">정통 미국식<br><span>프랭크</span> 치즈버거</dd>
                    </dl>
                    <a href="/sub/sub1-1.php">브랜드소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php">프랭크 버거</a></li>
                        <li><a href="/sub/sub1-2.php">특별함의 이유</a></li>
                        <li><a href="/sub/sub1-3.php">경영철학</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 메뉴</dt>
                        <dd class="gnb-start-desc">프랭크버거 만의<br><span>특화</span>된 메뉴</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">메뉴소개</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">Single</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery2">Side</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery3">Set</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 매장</dt>
                        <dd class="gnb-start-desc"><span>가까운</span> 매장을<br>찾아보세요</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">매장찾기</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">가까운 매장찾기</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=newstore">신규매장</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=partner">오픈예정</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=excellent">우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 소식</dt>
                        <dd class="gnb-start-desc">빠르게 만나는<br>프랭크 <span>최신 소식</span></dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">뉴스</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">새소식</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=event">이벤트</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube">홍보광고</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=instagram">SNS</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube2">성공스토리</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 회사</dt>
                        <dd class="gnb-start-desc">명품 브랜드<br>프랭크 <span>F&B</span></dd>
                    </dl>
                    <a href="/sub/sub5-1.php">회사소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub5-1.php">프랭크 F&B</a></li>
                        <li><a href="/sub/sub5-2.php">본사 시스템</a></li>
                        <li><a href="/sub/sub5-3.php">연혁</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 창업</dt>
                        <dd class="gnb-start-desc">체계적인 프랜차이즈<br>프랭크버거 <span>창업하기</span></dd>
                    </dl>
                    <a href="/sub/sub6-1.php">창업안내</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub6-1.php">창업 성공전략</a></li>
                        <li><a href="/sub/sub6-2.php">창업 아카데미</a></li>
                        <li><a href="/sub/sub6-3.php">창업조건 및 비용</a></li>
                        <li><a href="/sub/sub6-4.php">창업자금 지원</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=qa">가맹FAQ</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/qawrite.php">가맹상담</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <p class="gnb-bg"></p>
        <nav class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://khy2.dothome.co.kr/bbs/register.php">회원가입</a></li>
                <li>
                    <a href="http://khy2.dothome.co.kr/bbs/login.php">로그인<figure><img src="/img/tnb-icon.png" alt=""></figure></a></li>
                            </ul>
        </nav>
    </div>
</header>

<main id="foundation">
    <h2 class="hidden">창업안내</h2>
    <section class="visual">
        <div class="inner">
            <strong>창업안내</strong>
            <em>체계적인 선진 프랜차이즈 시스템.</em>
        </div>
    </section>
    <nav class="lnb">
        <div class="inner">
            <ul class="lnb-list">
                <li class="on"><a href="/sub/sub6-1.php">창업 성공전략</a></li>
                <li><a href="/sub/sub6-2.php">창업 아카데미</a></li>
                <li><a href="/sub/sub6-3.php">창업조건 및 비용</a></li>
                <li><a href="/sub/sub6-4.php">창업자금 지원</a></li>
                <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=qa">가맹FAQ</a></li>
                <li><a href="http://khy2.dothome.co.kr/bbs/qawrite.php">가맹상담</a></li>
            </ul>
        </div>
    </nav>
    <section class="sec inner">
<script>
    $(function(){
        $('.lnb-list li').removeClass('on')
        $('.lnb-list li').eq(2).addClass('on')
    })
</script>

<header class="sub-header">
    <h3 class="sub-tit"><span>창업조건</span> 및 비용</h3>
    <p class="sub-desc">체계적인 선진 프랜차이즈 시스템을 갖춘 프랭크버거와 함께하려면?</p>
</header>
<article class="foundation-process">
    <header class="sub-article-tit"><h4>개설절차</h4></header>
    <ul class="foundation-process-wrap clearfix">
        <li class="foundation-process-list">
            <em>01</em>
            <strong><span>가맹점 문의 및 상담</span>전화, 온라인 상담, 본사방문</strong>
        </li>
        <li class="foundation-process-list">
            <em>02</em>
            <strong><span>상권분석</span>현장방문, 입지 및 상권조사</strong>
        </li>
        <li class="foundation-process-list">
            <em>03</em>
            <strong><span>가맹계약</span>가맹점과 본사 계약체결</strong>
        </li>
        <li class="foundation-process-list">
            <em>04</em>
            <strong><span>매장설계</span>점포 실측 및 도면확정</strong>
        </li>
        <li class="foundation-process-list">
            <em>05</em>
            <strong><span>인테리어 시공</span>간판, 가구, 주방설비</strong>
        </li>
        <li class="foundation-process-list">
            <em>06</em>
            <strong><span>개점준비</span>Grand Open을 위한 준비</strong>
        </li>
        <li class="foundation-process-list">
            <em>07</em>
            <strong><span>직원 교육진행</span>메뉴얼 실습, 기기조작법,<br>서비스 교육</strong>
        </li>
        <li class="foundation-process-list">
            <em>08</em>
            <strong><span>GRAND OPEN</span>영업 개시,<br>본사 슈퍼바이저 지원</strong>
        </li>
    </ul>
</article>
<article class="foundation-condition clearfix">
    <header class="sub-article-tit"><h4>가맹점 개설 조건</h4></header>
    <ul class="foundation-condition-wrap">
        <li class="foundation-condition-list">
            <span>01</span>전국 주요 상권에 15평 이상 점포 소유 및 임차 가능한 분
        </li>
        <li class="foundation-condition-list">
            <span>02</span>프랭크버거 적합상권에 시설 및 투자 가능한 분
        </li>
        <li class="foundation-condition-list">
            <span>03</span> 프랭크버거 가맹 본사의 가맹점 운영 메뉴얼을 준수하여 운영하실 분
        </li>
        <li class="foundation-condition-list">
            <span>04</span>소비자 만족을 위해 최선을 다해 노력하실 분
        </li>
    </ul>
    <figure class="foundation-condition-img"><img src="/img/sub/foundation-condition.jpg" alt="FRANK BURGER 제조 유통 마케팅 신메뉴 개발 사후관리"></figure>
</article>
<article class="foundation-cost">
    <header class="sub-article-tit"><h4>창업비용</h4></header>
    <div class="foundation-cost-low">
        <strong><span>기본비용 1,800만원 </span>( 49.6㎡/15평 기준 )<em>( 단위 : 만원, VAT 별도 )</em></strong>
        <table class="foundation-cost-box">
            <caption class="hidden">창업비용 목록</caption>
            <thead>
                <tr class="cost-box-tit">
                    <th>구분</th>
                    <th>세부내용</th>
                    <th>금액</th>
                    <th>비고</th>
                </tr>
            </thead>
            <tbody>
                <tr class="cost-box-content">
                    <td>가맹비</td>
                    <td>브랜드 사용, 메뉴얼 사용, 사후 관리 등</td>
                    <td>1,000</td>
                    <td>소멸성</td>
                </tr>
                <tr class="cost-box-content">
                    <td>교육비</td>
                    <td>개점 교육, 서비스 교육, 조리 교육 등</td>
                    <td>400</td>
                    <td>5일간 교육 및 개점지원 등</td>
                </tr>
                <tr class="cost-box-content">
                    <td>홍보비</td>
                    <td>오픈 홍보물, 유니폼, 전단지 POP 등</td>
                    <td>400</td>
                    <td>-</td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="foundation-cost-high">
        <strong><span>기본비용 5,580만원 </span>( 49.6㎡/15평 기준 )<em>( 단위 : 만원, VAT 별도 )</em></strong>
        <table class="foundation-cost-box">
            <caption class="hidden">창업비용 목록</caption>
            <thead>
                <tr class="cost-box-tit">
                    <th>구분</th>
                    <th>세부내용</th>
                    <th>금액</th>
                    <th>비고</th>
                </tr>
            </thead>
            <tbody>
                <tr class="cost-box-content">
                    <td>인테리어</td>
                    <td>목공, 전기, 도장, 조명, 타일, 미장, 설계 및 감리</td>
                    <td>2,850</td>
                    <td>평당 ( 3.3㎡ ) 190만원</td>
                </tr>
                <tr class="cost-box-content">
                    <td>주방</td>
                    <td>싱크대, 디스펜서, 제빙기, 서랍식 냉장고, 테이블냉장고, 자동그리들(옵션)</td>
                    <td>2,200</td>
                    <td>기본 품목 외 별도</td>
                </tr>
                <tr class="cost-box-content">
                    <td>간판</td>
                    <td>전면 돌출 실사 등</td>
                    <td>-</td>
                    <td>현장 상황에 따라 상이함</td>
                </tr>
                <tr class="cost-box-content">
                    <td>키오스크</td>
                    <td>무인주문기</td>
                    <td>330</td>
                    <td>-</td>
                </tr>
                <tr class="cost-box-content">
                    <td>DID</td>
                    <td>메뉴,동영상 홍보용용 2조</td>
                    <td>200</td>
                    <td>-</td>
                </tr>
            </tbody>
        </table>
        <div class="cost-box-notice">
            <p>* 점포 투자 비용은 규모와 특성에 따라 달라질 수 있으며 부가세는 별도입니다.</p>
            <p>* 의탁자, 메뉴보드는 옵션입니다.</p>
            <p>* 간판 및 모든 조명은 효율성이 높은 LED 전구를 기본으로 채택·사용합니다.</p>
            <p>* 철거, 전기 증설, 지방 경비 외 계약서에 명시된 별도 공사 내역, 간판, 가구, 아웃테리어는 현장 견적으로 별도입니다.</p>
        </div>
    </div>
</article>

</section>
</main>

<footer id="footer">
    <button type="button" id="top_btn">
        <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
    </button>
    <div class="inner">
        <h2 class="f-logo">(주)프랭크 에프앤비</h2>
        <ul class="f-menu">
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=provision">이용약관</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=email">이메일무단수집거부</a></li>
        </ul>
        <div class="f-center">
            <em>고객지원 및 상담센터</em>
            <strong>1544 - 7733</strong>
            <p>평일 09:00 ~ 18:00 / 점심 12:00 ~ 13:00<br>(토요일 / 일요일 / 공휴일 휴무)</p>
        </div>
        <div class="f-link">
            <div class="f-link-sns">
                <a href="https://www.instagram.com/frankburger_official_/">인스타그램</a>
                <a href="https://www.youtube.com/channel/UCo3DjdEjQrr8uD_-YUt8mnA">유튜브</a>
                <a href="https://blog.naver.com/bpr2012">네이버 블로그</a>
            </div>
            <div class="f-link-family">
                <a href="http://co-tabe.co.kr/">코앤타베</a>
                <a href="http://bapuri.co.kr/new2/">밥푸리</a>
            </div>
        </div>
        <ul class="f-info">
            <li class="f-info-addr"><address>(주)프랭크 에프앤비 사업자번호 : 130-86-76090 경기도 부천시 옥산로 181</address></li>
            <li class="f-info-copy">COPYRIGHT ⓒ 2019 FRANK F&B. All Rights Reserved.</li>
        </ul>
    </div>
</footer>

    <script>
        $(function() {
            $("#top_btn").on("click", function() {
                $("html, body").animate({scrollTop:0}, '500');
                return false;
            });
        });
    </script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        });
    </script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
