<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>프랭크버거</title>
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/css/default.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://khy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://khy2.dothome.co.kr";
var g5_bbs_url   = "http://khy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<script src="http://khy2.dothome.co.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/common.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/wrest.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>
<meta name="keywords" content="수제버거, 수제버거창업, 프랭크버거, 햄버거, 햄버거창업, 버거창업, 수제햄버거, 버거">
<meta name="description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:title" content="대한민국 수제버거 No.1 프랭크 버거">
<meta property="og:type" content="website">
<meta property="og:description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:image" content="/img/bi.jpg">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="/css/font.css">
<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub5.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/js/jquery.vide.js"></script>
<script src="https://kit.fontawesome.com/50dc02b2ac.js" crossorigin="anonymous"></script>

<div class="skip-nav">
    <a href="#main">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/">프랭크버거</a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인메뉴</h2>
            <ul>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거</dt>
                        <dd class="gnb-start-desc">정통 미국식<br><span>프랭크</span> 치즈버거</dd>
                    </dl>
                    <a href="/sub/sub1-1.php">브랜드소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php">프랭크 버거</a></li>
                        <li><a href="/sub/sub1-2.php">특별함의 이유</a></li>
                        <li><a href="/sub/sub1-3.php">경영철학</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 메뉴</dt>
                        <dd class="gnb-start-desc">프랭크버거 만의<br><span>특화</span>된 메뉴</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">메뉴소개</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">Single</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery2">Side</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery3">Set</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 매장</dt>
                        <dd class="gnb-start-desc"><span>가까운</span> 매장을<br>찾아보세요</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">매장찾기</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">가까운 매장찾기</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=newstore">신규매장</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=partner">오픈예정</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=excellent">우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 소식</dt>
                        <dd class="gnb-start-desc">빠르게 만나는<br>프랭크 <span>최신 소식</span></dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">뉴스</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">새소식</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=event">이벤트</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube">홍보광고</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=instagram">SNS</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube2">성공스토리</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 회사</dt>
                        <dd class="gnb-start-desc">명품 브랜드<br>프랭크 <span>F&B</span></dd>
                    </dl>
                    <a href="/sub/sub5-1.php">회사소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub5-1.php">프랭크 F&B</a></li>
                        <li><a href="/sub/sub5-2.php">본사 시스템</a></li>
                        <li><a href="/sub/sub5-3.php">연혁</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 창업</dt>
                        <dd class="gnb-start-desc">체계적인 프랜차이즈<br>프랭크버거 <span>창업하기</span></dd>
                    </dl>
                    <a href="/sub/sub6-1.php">창업안내</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub6-1.php">창업 성공전략</a></li>
                        <li><a href="/sub/sub6-2.php">창업 아카데미</a></li>
                        <li><a href="/sub/sub6-3.php">창업조건 및 비용</a></li>
                        <li><a href="/sub/sub6-4.php">창업자금 지원</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=qa">가맹FAQ</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/qawrite.php">가맹상담</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <p class="gnb-bg"></p>
        <nav class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://khy2.dothome.co.kr/bbs/register.php">회원가입</a></li>
                <li>
                    <a href="http://khy2.dothome.co.kr/bbs/login.php">로그인<figure><img src="/img/tnb-icon.png" alt=""></figure></a></li>
                            </ul>
        </nav>
    </div>
</header>

<main id="company">
    <h2 class="hidden">회사소개</h2>
    <section class="visual">
        <div class="inner">
            <strong>회사소개</strong>
            <em>명품 브랜드 완성을 위해 노력하는 F&B</em>
        </div>
    </section>
    <nav class="lnb">
        <div class="inner">
            <ul class="lnb-list">
                <li class="on"><a href="/sub/sub5-1.php">프랭크 F&B</a></li>
                <li><a href="/sub/sub5-2.php">본사 시스템</a></li>
                <li><a href="/sub/sub5-3.php">연혁</a></li>
            </ul>
        </div>
    </nav>
    <section class="sec inner">
<script>
    $(function(){
        $('.lnb-list li').removeClass('on')
        $('.lnb-list li').eq(0).addClass('on')
    })
</script>

<header class="sub-header">
    <h3 class="sub-tit">프랭크 <span>F&B</span></h3>
    <p class="sub-desc">브랜드 보호 및 가맹점 관리를 우선으로 하는 프랜차이즈 가맹본사입니다.</p>
</header>
<article class="company-intro clearfix">
    <header class="sub-article-tit"><h4>내 가족이 먹지 못하는 음식은 팔지 않겠습니다.</h4></header>
    <div class="company-intro-txt">
        <p>㈜FRANK F&B는 우리의 입맛에 맞는 100% 순소고기 패티를 자체 생산 제조하여 가맹점에<br>공급하는 선진 프랜차이즈 시스템이 완비된 기업으로 대한민국 프랜차이즈 업체를 이끌고 있는<br>선두주자로 그 역할을 다 하고 있습니다.</p>
        <p>소비자와의 약속을 위해 철저한 위생관리 및 계절별 신선한 재료만을 엄선하여<br>가맹본사에서 자체생산 및 유통을 원칙으로 브랜드 보호 및 가맹점 관리를 우선으로 하는<br>프랜차이즈 가맹본사입니다.</p>
        <p>포장보다는 가맹점과 가맹본사의 내실을 튼튼히하여 명품 브랜드 완성을 위해 노력하는<br>프랜차이즈 가맹 본사의 역할과 책임을 다하겠습니다.</p>
    </div>
    <figure class="company-intro-img"><img src="/img/sub/company-intro.jpg" alt="Frank F&B Corp."></figure>
</article>
<article class="company-vision">
    <header class="sub-article-tit hidden"><h4>프랭크 F&B 비전</h4></header>
    <ul class="company-vision-wrap">
        <li class="company-vision-list clearfix">
            <strong class="company-vision-tit">Advancement<span>함께하는 도약</span></strong>
            <div class="company-vision-desc">
                <p>프랭크에프앤비는 젊습니다.</p>
                <p>프랭크에프앤비는 젊습니다. 자유로운 문화를 추구하고 경쟁보단 협력을 우선 가치로 여깁니다.</p>
                <p>그렇기 때문에 평가와 경쟁을 통한 승진이 아니라 자율과 협력을 위한 자동승진제도를 운영합니다.</p>
                <p>특별히 협력 업무를 위한 TF구성이 활발하게 이루어지도록 지원합니다.</p>
                <p>또한 회사가 성장한 수준에 따른 보상(연봉,인센티브,복리후생)을 함께 공유합니다.</p>
            </div>
        </li>
        <li class="company-vision-list clearfix">
            <strong class="company-vision-tit">Leadership<span>속도보단 방향의 리더십</span></strong>
            <div class="company-vision-desc">
                <p>100년 가는 회사를 만들기 위해, 우리는 속도보다 방향을 중요하게 생각합니다.</p>
                <p>함께 가야 오래 갈수 있고, 함께여서 이룰 수 있는 것이 많다는 것을 알고 있기에 속도를 내는 것보다<br>천천히 가도 제대로 가는 사람, 인내하며 가는 사람을 좋아합니다.</p>
            </div>
        </li>
        <li class="company-vision-list clearfix">
            <strong class="company-vision-tit">Value<span>우리의 가치</span></strong>
            <div class="company-vision-desc">
                <p>프랭크에프앤비는 사람을 소중히 하고 행복한 문화를 만들기 위해 노력합니다.</p>
                <p>우리는 행복한 사람이 행복한 버거를 만든다고 믿고 있습니다.</p>
                <p>맛있는버거를 만들기 위해, 먼저 사람을 소중히 하고 행복한 문화를 만듭니다.</p>
                <p>그렇게 할 때 그 사람들의 손에서 맛있고 행복한 버거가 탄생합니다.</p>
            </div>
        </li>
        <li class="company-vision-list clearfix">
            <strong class="company-vision-tit">Opportunity<span>무한한 기회</span></strong>
            <div class="company-vision-desc">
                <p>우리의 비전은 세상에서 제일 큰 햄버거 회사, 100년 가는 장인 기업이 되는 것입니다.</p>
                <p>본사 직원들에게는 자기개발과 동기부여를 위한 지원을 통해 직무전문가로의 성장할 가능성을 주고,<br>직영 직원들에게는 본사 슈퍼바이저로 성장하거나 피자알볼로, 프랭크버거 매장을 직업 운영할 수 있는 기회를 제공합니다.</p>
                <p>무한한 성장가능성을 가진 회사이기에, 모든 직원에게도 다양한 기회가 열려 있습니다.</p>
            </div>
        </li>
        <li class="company-vision-list clearfix">
            <strong class="company-vision-tit">Leverage<span>선한 영향력</span></strong>
            <div class="company-vision-desc">
                <p>프랭크에프앤비는 외식프랜차이즈 업계의 구글(GOOGLE)이 되길 희망합니다.</p>
                <p>큰 회사보다 내실 있는 회사, 시끄러운 회사보다 조용한 회사로 성장하길 바라며 눈 앞의 이윤보다는<br>모든 이해관계자에게 이익을 줄수 있는 기업을 만들기 원합니다.</p>
                <p>지금까지의 프랜차이즈 시스템이 아닌, 사람이 본질이 되고 문화가 경쟁력이 되는 그런 긍정적인 영향력을 가진 기업이 되고자 합니다.</p>
            </div>
        </li>
    </ul>
</article>
<article class="company-road">
    <header class="sub-article-tit"><h4>오시는 길</h4></header>
    <figure class="company-road-map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3164.9212878833778!2d126.77715767644486!3d37.50977457205333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x357b7d528e845b87%3A0x68628e0eb27d4ea1!2z6rK96riw64-EIOu2gOyynOyLnCDsm5Drr7jqtawg7Jil7IKw66GcIDE4MQ!5e0!3m2!1sko!2skr!4v1672113142791!5m2!1sko!2skr" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </figure>
    <ul class="company-road-notice clearfix">
        <li><strong><span>Address</span>경기도 부천시 옥산로 181</strong></li>
        <li><strong><span>Tel</span>1544-7733</strong></li>
        <li><strong><span>Fax</span>032-678-1661</strong></li>
    </ul>
</article>

</section>
</main>

<footer id="footer">
    <button type="button" id="top_btn">
        <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
    </button>
    <div class="inner">
        <h2 class="f-logo">(주)프랭크 에프앤비</h2>
        <ul class="f-menu">
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=provision">이용약관</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=email">이메일무단수집거부</a></li>
        </ul>
        <div class="f-center">
            <em>고객지원 및 상담센터</em>
            <strong>1544 - 7733</strong>
            <p>평일 09:00 ~ 18:00 / 점심 12:00 ~ 13:00<br>(토요일 / 일요일 / 공휴일 휴무)</p>
        </div>
        <div class="f-link">
            <div class="f-link-sns">
                <a href="https://www.instagram.com/frankburger_official_/">인스타그램</a>
                <a href="https://www.youtube.com/channel/UCo3DjdEjQrr8uD_-YUt8mnA">유튜브</a>
                <a href="https://blog.naver.com/bpr2012">네이버 블로그</a>
            </div>
            <div class="f-link-family">
                <a href="http://co-tabe.co.kr/">코앤타베</a>
                <a href="http://bapuri.co.kr/new2/">밥푸리</a>
            </div>
        </div>
        <ul class="f-info">
            <li class="f-info-addr"><address>(주)프랭크 에프앤비 사업자번호 : 130-86-76090 경기도 부천시 옥산로 181</address></li>
            <li class="f-info-copy">COPYRIGHT ⓒ 2019 FRANK F&B. All Rights Reserved.</li>
        </ul>
    </div>
</footer>

    <script>
        $(function() {
            $("#top_btn").on("click", function() {
                $("html, body").animate({scrollTop:0}, '500');
                return false;
            });
        });
    </script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        });
    </script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
