<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>프랭크버거</title>
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/css/default.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://khy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://khy2.dothome.co.kr";
var g5_bbs_url   = "http://khy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<script src="http://khy2.dothome.co.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/common.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/wrest.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>
<meta name="keywords" content="수제버거, 수제버거창업, 프랭크버거, 햄버거, 햄버거창업, 버거창업, 수제햄버거, 버거">
<meta name="description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:title" content="대한민국 수제버거 No.1 프랭크 버거">
<meta property="og:type" content="website">
<meta property="og:description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:image" content="/img/bi.jpg">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="/css/font.css">
<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub6.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/js/jquery.vide.js"></script>
<script src="https://kit.fontawesome.com/50dc02b2ac.js" crossorigin="anonymous"></script>

<div class="skip-nav">
    <a href="#main">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/">프랭크버거</a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인메뉴</h2>
            <ul>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거</dt>
                        <dd class="gnb-start-desc">정통 미국식<br><span>프랭크</span> 치즈버거</dd>
                    </dl>
                    <a href="/sub/sub1-1.php">브랜드소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php">프랭크 버거</a></li>
                        <li><a href="/sub/sub1-2.php">특별함의 이유</a></li>
                        <li><a href="/sub/sub1-3.php">경영철학</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 메뉴</dt>
                        <dd class="gnb-start-desc">프랭크버거 만의<br><span>특화</span>된 메뉴</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">메뉴소개</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">Single</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery2">Side</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery3">Set</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 매장</dt>
                        <dd class="gnb-start-desc"><span>가까운</span> 매장을<br>찾아보세요</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">매장찾기</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">가까운 매장찾기</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=newstore">신규매장</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=partner">오픈예정</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=excellent">우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 소식</dt>
                        <dd class="gnb-start-desc">빠르게 만나는<br>프랭크 <span>최신 소식</span></dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">뉴스</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">새소식</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=event">이벤트</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube">홍보광고</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=instagram">SNS</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube2">성공스토리</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 회사</dt>
                        <dd class="gnb-start-desc">명품 브랜드<br>프랭크 <span>F&B</span></dd>
                    </dl>
                    <a href="/sub/sub5-1.php">회사소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub5-1.php">프랭크 F&B</a></li>
                        <li><a href="/sub/sub5-2.php">본사 시스템</a></li>
                        <li><a href="/sub/sub5-3.php">연혁</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 창업</dt>
                        <dd class="gnb-start-desc">체계적인 프랜차이즈<br>프랭크버거 <span>창업하기</span></dd>
                    </dl>
                    <a href="/sub/sub6-1.php">창업안내</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub6-1.php">창업 성공전략</a></li>
                        <li><a href="/sub/sub6-2.php">창업 아카데미</a></li>
                        <li><a href="/sub/sub6-3.php">창업조건 및 비용</a></li>
                        <li><a href="/sub/sub6-4.php">창업자금 지원</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=qa">가맹FAQ</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/qawrite.php">가맹상담</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <p class="gnb-bg"></p>
        <nav class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://khy2.dothome.co.kr/bbs/register.php">회원가입</a></li>
                <li>
                    <a href="http://khy2.dothome.co.kr/bbs/login.php">로그인<figure><img src="/img/tnb-icon.png" alt=""></figure></a></li>
                            </ul>
        </nav>
    </div>
</header>

<main id="foundation">
    <h2 class="hidden">창업안내</h2>
    <section class="visual">
        <div class="inner">
            <strong>창업안내</strong>
            <em>체계적인 선진 프랜차이즈 시스템.</em>
        </div>
    </section>
    <nav class="lnb">
        <div class="inner">
            <ul class="lnb-list">
                <li class="on"><a href="/sub/sub6-1.php">창업 성공전략</a></li>
                <li><a href="/sub/sub6-2.php">창업 아카데미</a></li>
                <li><a href="/sub/sub6-3.php">창업조건 및 비용</a></li>
                <li><a href="/sub/sub6-4.php">창업자금 지원</a></li>
                <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=qa">가맹FAQ</a></li>
                <li><a href="http://khy2.dothome.co.kr/bbs/qawrite.php">가맹상담</a></li>
            </ul>
        </div>
    </nav>
    <section class="sec inner">
<script>
    $(function(){
        $('.lnb-list li').removeClass('on')
        $('.lnb-list li').eq(1).addClass('on')
    })
</script>

<header class="sub-header">
    <h3 class="sub-tit">창업 <span>아카데미</span></h3>
    <p class="sub-desc">프랭크 F&B 가맹본사의 초보를 장인으로 키우는 교육시스템</p>
</header>
<div class="sub-sec-desc">
    <p>프랭크 가맹본사는 창업자의 성공창업을 위해 조리교육, 이론교육, 대고객 서비스교육, 매장 및 직영점 실무교육 등으로 프랭크버거 창업을 지원합니다.</p>
    <p>본사 직영 식품제조, 가공공장 운영에 의한 완·반제품 및 소포장 위주로 제품을 공급하므로 경험이 없는 초보창업자도 손쉽게 조리가 가능합니다.</p>
</div>
<ul class="academy-process clearfix">
    <li><span>01</span>오리엔테이션</li>
    <li><span>02</span>제품 기초교육</li>
    <li><span>03</span>직영점 실습</li>
    <li><span>04</span>이론 교육</li>
    <li><span>05</span>협력사 견학</li>
    <li><span>06</span>테스트 및 수료</li>
    <li><span>07</span>오픈</li>
    <li><span>08</span>사후 방문 교육</li>
</ul>
<article class="academy-intro">
    <div class="academy-intro-text">
        <h4 class="academy-sec-tit"><span>장인을 키우는</span>기초 교육 프로그램</h4>
        <strong><span>대상</span>가맹점주 1인</strong>
        <strong><span>기간</span>2주</strong>
        <strong><span>장소</span>프랭크 F&C 아카데미 및 직영점</strong>
    </div>
    <figure class="academy-intro-img"><img src="/img/sub/academy-intro.jpg" alt=""></figure>
</article>
<article class="academy-week clearfix">
    <h4 class="academy-week-tit"><span>1주차</span>FIRST WEEK</h4>
    <p class="academy-week-desc">프랭크버거에 대한 이해와 기초 제조 교육 및 직영점 현장 실습</p>
    <div class="academy-week-box">
        <strong>프 로<br>그 램</strong>
        <ul class="academy-week-txt">
            <li>프랭크버거 브랜드의 이해</li>
            <li>자재 관리 및 준비 방법</li>
            <li>버거업계의 현황과 전망</li>
            <li>주방 관리 방법</li>
            <li>버거 제조 방법과 관리</li>
            <li>버거 및 사이드 만들기</li>
        </ul>
        <figure class="academy-week-img"><img src="/img/sub/academy-first1.jpg"></figure>
    </div>
    <div class="academy-week-box">
        <strong>프 로<br>그 램</strong>
        <ul class="academy-week-txt">
            <li>매장 오픈 / 마감 교육</li>
            <li>인사 / 노무 교육</li>
            <li>기초 교육 내용 실습</li>
            <li>프랭크버거 정책 교육</li>
            <li>회계 관리</li>
        </ul>
        <figure class="academy-week-img"><img src="/img/sub/academy-first2.jpg"></figure>
    </div>
</article>
<article class="academy-week clearfix">
    <h4 class="academy-week-tit"><span>2주차</span>SECOND WEEK</h4>
    <p class="academy-week-desc">직영점 현장 실습 및 이론 교육 & 테스트</p>
    <div class="academy-week-box">
        <strong>프 로<br>그 램</strong>
        <ul class="academy-week-txt">
            <li>직영점 실습</li>
            <li>포스 교육 및 실습</li>
            <li>안전교육</li>
            <li>실제 고객 응대 교육</li>
        </ul>
        <figure class="academy-week-img"><img src="/img/sub/academy-second1.jpg"></figure>
    </div>
    <div class="academy-week-box">
        <strong>프 로<br>그 램</strong>
        <ul class="academy-week-txt">
            <li>LSM 교육</li>
            <li>고객 관리 교육</li>
            <li>인원 관리 및 상권 분석 교육</li>
            <li>테스트 진행</li>
            <li>위생 관리 교육</li>
        </ul>
        <figure class="academy-week-img"><img src="/img/sub/academy-second2.jpg"></figure>
    </div>
</article>

</section>
</main>

<footer id="footer">
    <button type="button" id="top_btn">
        <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
    </button>
    <div class="inner">
        <h2 class="f-logo">(주)프랭크 에프앤비</h2>
        <ul class="f-menu">
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=provision">이용약관</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=email">이메일무단수집거부</a></li>
        </ul>
        <div class="f-center">
            <em>고객지원 및 상담센터</em>
            <strong>1544 - 7733</strong>
            <p>평일 09:00 ~ 18:00 / 점심 12:00 ~ 13:00<br>(토요일 / 일요일 / 공휴일 휴무)</p>
        </div>
        <div class="f-link">
            <div class="f-link-sns">
                <a href="https://www.instagram.com/frankburger_official_/">인스타그램</a>
                <a href="https://www.youtube.com/channel/UCo3DjdEjQrr8uD_-YUt8mnA">유튜브</a>
                <a href="https://blog.naver.com/bpr2012">네이버 블로그</a>
            </div>
            <div class="f-link-family">
                <a href="http://co-tabe.co.kr/">코앤타베</a>
                <a href="http://bapuri.co.kr/new2/">밥푸리</a>
            </div>
        </div>
        <ul class="f-info">
            <li class="f-info-addr"><address>(주)프랭크 에프앤비 사업자번호 : 130-86-76090 경기도 부천시 옥산로 181</address></li>
            <li class="f-info-copy">COPYRIGHT ⓒ 2019 FRANK F&B. All Rights Reserved.</li>
        </ul>
    </div>
</footer>

    <script>
        $(function() {
            $("#top_btn").on("click", function() {
                $("html, body").animate({scrollTop:0}, '500');
                return false;
            });
        });
    </script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        });
    </script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
