<script>
    $(function(){
        $('.lnb-list li').removeClass('on')
        $('.lnb-list li').eq(5).addClass('on')
    })
</script>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>프랭크버거</title>
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/css/default.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://khy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://khy2.dothome.co.kr";
var g5_bbs_url   = "http://khy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<script src="http://khy2.dothome.co.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/common.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/wrest.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

<script>
alert("회원이시라면 로그인 후 이용해 보십시오.");
document.location.replace("./login.php?url=http%3A%2F%2Fkhy2.dothome.co.kr%2Fbbs%2Fqalist.php");
</script>

<noscript>
<div id="validation_check">
    <h1>다음 항목에 오류가 있습니다.</h1>
    <p class="cbg">
        회원이시라면 로그인 후 이용해 보십시오.    </p>
        <div class="btn_confirm">
        <a href="./login.php?url=http%3A%2F%2Fkhy2.dothome.co.kr%2Fbbs%2Fqalist.php">돌아가기</a>
    </div>
    
</div>
</noscript>





</body>
</html>
