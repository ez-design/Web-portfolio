<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="keywords" content="던킨, 도넛, 도너츠, 커피, DUNKIN' DONUTS, dunkindonuts, 던킨도너츠" /> 
<meta name="description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!" />

<meta name="robots" content="index">
<meta property="og:title" content="[Sweet Break, DUNKIN’ DONUTS]" />
<meta property="og:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">
<meta property="og:type" content="website" />
<meta property="og:image" content="/img/og-img.jpg" />
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="[Sweet Break, DUNKIN’ DONUTS]">
<meta name="twitter:url" content="https://www.dunkindonuts.co.kr/"/>
<meta name="twitter:image" content="/img/og-img.jpg">
<meta name="twitter:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">

<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>로그인 | 던킨</title>
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/css/default.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/skin/member/basic/style.css?ver=191110">
<!--[if lte IE 8]>
<script src="http://ringpuppy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://ringpuppy2.dothome.co.kr";
var g5_bbs_url   = "http://ringpuppy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />


<link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/img/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script src="http://ringpuppy2.dothome.co.kr/js/jquery-1.12.4.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery.menu.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/common.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/wrest.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/placeholders.min.js"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub-menu.css">
<script src="/js/sub.js"></script>

<!-- 상단 시작 { -->
<div class="skip-nav">
    <a href="#container">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner"><!-- 1280 가운데정렬 -->
        <h1 class="logo"><a href="/">던킨</a></h1>
        <h2 class="hidden">메인메뉴</h2>
        <nav class="gnb">
            <ul class="gnb-wrap">
                <li class="depth1">
                    <a href="/sub/sub-brand.php">BRAND</a>
                    <dl class="gnb-s">
                        <dt>BRAND</dt>
                        <dd>던킨이야기</dd>
                        <dd><span>던킨도너츠</span>에<br>대해서 알아보세요.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-brand.php">브랜드 소개</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=brand">브랜드 소식</a></li>
                        <li><a href="/sub/sub-brand03.php">CF</a></li>
                        <li><a href="/sub/sub-brand04.php">왜 던킨인가?</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">STORE</a>
                    <dl class="gnb-s">
                        <dt>STORE</dt>
                        <dd>매장찾기</dd>
                        <dd>나와 가장 가까운<br><span>매장</span>을 찾아보세요.</dd>
                        <dd><img src="/img/gnb-img02.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">매장찾기</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=partner">신규매장</a></li>
                        <li><a href="/sub/sub-store03.php">품질우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">MENU</a>
                    <dl class="gnb-s">
                        <dt>MENU</dt>
                        <dd>이달의 도넛</dd>
                        <dd>매번 새로운<br>던킨의 다양한<br><span>도넛</span>을 만나보세요.</dd>
                        <dd><img src="/img/gnb-img03.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">DONUT</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu02">SANDWICHES</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu03">COFFEE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_baverage">BEVERAGE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_others">OTHERS</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-guide.php">창업안내</a>
                    <dl class="gnb-s">
                        <dt>START</dt>
                        <dd>창업안내</dd>
                        <dd>여러분의<br><span>새로운 출발,</span>던킨이<br>도와드리겠습니다.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-guide.php">대한민국 가맹시장</a></li>
                        <li><a href="/sub/sub-guide02.php">SPC와 함께하는</a></li>
                        <li><a href="/sub/sub-guide03.php">가맹점 개설절차</a></li>
                        <li><a href="/sub/sub-guide04.php">사업설명회</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa">FAQ</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-center.php">고객센터</a>
                    <dl class="gnb-s">
                        <dt>CENTER</dt>
                        <dd>고객센터</dd>
                        <dd>던킨의 <span>고개센터를</span><br>통해 궁금증을 해결하세요.</dd>
                        <dd><img src="/img/gnb-img05.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-center.php">접수 및 처리 절차</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa05">자주하는 질문</a></li>
                        <li><a href="#">보도자료</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=gallery">이벤트</a></li>
                    </ul>
                </li>
            </ul>
            <div class="gnb-bg"></div>
        </nav>
        <div class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/register.php">JOIN</a></li>
                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/login.php">LOGIN</a></li>
                            </ul>
        </div>
    </div>
</header>
<!-- } 상단 끝 -->


<!-- 콘텐츠 시작 { -->
<main id="container">
    <section class="sub06">
        <div class="inner">

<!-- 로그인 시작 { -->
<div id="mb_login" class="mbskin">
    <div class="mbskin_box">
        <h1>로그인</h1>
        <div class="mb_log_cate">
            <h2><span class="sound_only">회원</span>로그인</h2>
            <a href="http://ringpuppy2.dothome.co.kr/bbs/register.php" class="join">회원가입</a>
        </div>
        <form name="flogin" action="http://ringpuppy2.dothome.co.kr/bbs/login_check.php" onsubmit="return flogin_submit(this);" method="post">
        <input type="hidden" name="url" value="http%3A%2F%2Fringpuppy2.dothome.co.kr">
        
        <fieldset id="login_fs">
            <legend class="hidden">회원로그인</legend>
            <label for="login_id" class="sound_only">회원아이디<strong class="sound_only"> 필수</strong></label>
            <input type="text" name="mb_id" id="login_id" required class="frm_input required" size="20" maxLength="20" placeholder="아이디">
            <label for="login_pw" class="sound_only">비밀번호<strong class="sound_only"> 필수</strong></label>
            <input type="password" name="mb_password" id="login_pw" required class="frm_input required" size="20" maxLength="20" placeholder="비밀번호">
            <button type="submit" class="btn_submit">로그인</button>
            
            <div id="login_info">
                <div class="login_if_auto chk_box">
                    <input type="checkbox" name="auto_login" id="login_auto_login" class="selec_chk">
                    <label for="login_auto_login"><span></span> 자동로그인</label>  
                </div>
                <div class="login_if_lpl">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/password_lost.php" target="_blank" id="login_password_lost">정보찾기</a>  
                </div>
            </div>
        </fieldset> 
        </form>
            </div>
</div>

<script>
jQuery(function($){
    $("#login_auto_login").click(function(){
        if (this.checked) {
            this.checked = confirm("자동로그인을 사용하시면 다음부터 회원아이디와 비밀번호를 입력하실 필요가 없습니다.\n\n공공장소에서는 개인정보가 유출될 수 있으니 사용을 자제하여 주십시오.\n\n자동로그인을 사용하시겠습니까?");
        }
    });
});

function flogin_submit(f)
{
    if( $( document.body ).triggerHandler( 'login_sumit', [f, 'flogin'] ) !== false ){
        return true;
    }
    return false;
}
</script>
<!-- } 로그인 끝 -->
</div>
</section>

</main>
<!-- } 메인콘텐츠 끝 -->


<!-- 하단 시작 { -->
<footer id="footer">
    <div class="inner">
        <h2 class="f-logo">던킨</h2>
        <ul class="f-menu clearfix">
            <li><a href="/sub/sub-f-use.php">이용약관</a></li>
            <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
            <li><a href="/sub/sub-f-privacy.php">영상정보처리기기운영방침</a></li>
            <li><a href="/sub/sub-f-safety.php">안전보건경영방침</a></li>
        </ul>
        <div class="f-banner">
            <div class="f-site">
                <p class="f-site-tit">Family site<span class="material-symbols-outlined">expand_less</span></p>
                <ul class="f-site-box">
                    <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
                    <li><a href="http://www.brkorea.co.kr/">비알코리아</a></li>
                    <li><a href="http://www.baskinrobbins.co.kr/">배스킨라빈스</a></li>
                    <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
                    <li><a href="https://shany.co.kr/">샤니</a></li>
                    <li><a href="https://www.caffe-pascucci.co.kr/index.asp">파스쿠찌</a></li>
                    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=044D0806A9BA8A6F21BEDA177BB8A053">해피포인트카드</a></li>
                    <li><a href="https://dunkinschool.hunet.co.kr/Login/LoginGate">던킨 온라인 스쿨</a></li>
                    <li><a href="https://dunkin.alba.co.kr/job/brand/main.asp">던킨 아르바이트</a></li>
                </ul>
            </div>
            <ul class="f-sns">
                <li><a href="https://www.facebook.com/DunkinKorea" target="_blank">페이스북</a></li>
                <li><a href="https://www.instagram.com/dunkin_kr/" target="_blank">인스타그램</a></li>
                <li><a href="https://blog.naver.com/dunkin_kr" target="_blank">블로그</a></li>
                <li><a href="https://www.youtube.com/user/dunkindonutskorea" target="_blank">유튜브</a></li>
                <li><a href="https://twitter.com/dunkin_kr" target="_blank">트위터</a></li>
            </ul>
            <ul class="f-mark">
                <li><a href="http://www.spc.co.kr/contributionAll"  target="_blank">SPC행복한 이야기</a></li>
                <li><a href="https://www.kca.go.kr/ccm/" target="_blank">소비자중심경영</a></li>
                <li><a href="https://knqa.ksa.or.kr/knqa/2276/subview.do" target="_blank">국가품질상</a></li>
            </ul>
        </div>
        <div class="f-copy">
            <ul class="f-add clearfix">
                <li><address>서울특별시 서초구 남부순환로 2620(양재동 11-149번지)</address></li>
                <li>TEL : 080-555-3131</li>
                <li>VOC상담: 080-555-3131</li>
                <li>개인정보관리책임자 : 김경우</li>
                <li>사업자 등록번호 : 303-81-09535</li>
                <li>비알코리아(주) 대표이사 도세호</li>
            </ul>
            <p>COPYRIGHT Ⓒ 2016 BRKOREA COMPANY. ALL RIGHTS RESERVED.</p>
        </div>
    </div>
</footer>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    });
</script>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->


</body>
</html>
