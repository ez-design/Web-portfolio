<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="keywords" content="던킨, 도넛, 도너츠, 커피, DUNKIN' DONUTS, dunkindonuts, 던킨도너츠" /> 
<meta name="description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!" />

<meta name="robots" content="index">
<meta property="og:title" content="[Sweet Break, DUNKIN’ DONUTS]" />
<meta property="og:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">
<meta property="og:type" content="website" />
<meta property="og:image" content="/img/og-img.jpg" />
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="[Sweet Break, DUNKIN’ DONUTS]">
<meta name="twitter:url" content="https://www.dunkindonuts.co.kr/"/>
<meta name="twitter:image" content="/img/og-img.jpg">
<meta name="twitter:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">

<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>오류안내 페이지 | 던킨</title>
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/css/default.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=191110">
<!--[if lte IE 8]>
<script src="http://ringpuppy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://ringpuppy2.dothome.co.kr";
var g5_bbs_url   = "http://ringpuppy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />


<link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/img/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script src="http://ringpuppy2.dothome.co.kr/js/jquery-1.12.4.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery.menu.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/common.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/wrest.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/placeholders.min.js"></script>
</head>
<body>

<script>
alert("sw 값이 제대로 넘어오지 않았습니다.");
document.location.replace("http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find");
</script>

<noscript>
<div id="validation_check">
    <h1>다음 항목에 오류가 있습니다.</h1>
    <p class="cbg">
        sw 값이 제대로 넘어오지 않았습니다.    </p>
        <div class="btn_confirm">
        <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">돌아가기</a>
    </div>
    
</div>
</noscript>



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->


</body>
</html>
