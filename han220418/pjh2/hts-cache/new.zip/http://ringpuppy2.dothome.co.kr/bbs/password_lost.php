<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="keywords" content="던킨, 도넛, 도너츠, 커피, DUNKIN' DONUTS, dunkindonuts, 던킨도너츠" /> 
<meta name="description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!" />

<meta name="robots" content="index">
<meta property="og:title" content="[Sweet Break, DUNKIN’ DONUTS]" />
<meta property="og:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">
<meta property="og:type" content="website" />
<meta property="og:image" content="/img/og-img.jpg" />
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="[Sweet Break, DUNKIN’ DONUTS]">
<meta name="twitter:url" content="https://www.dunkindonuts.co.kr/"/>
<meta name="twitter:image" content="/img/og-img.jpg">
<meta name="twitter:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">

<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>회원정보 찾기 | 던킨</title>
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/css/default.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/skin/member/basic/style.css?ver=191110">
<!--[if lte IE 8]>
<script src="http://ringpuppy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://ringpuppy2.dothome.co.kr";
var g5_bbs_url   = "http://ringpuppy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />


<link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/img/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script src="http://ringpuppy2.dothome.co.kr/js/jquery-1.12.4.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery.menu.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/common.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/wrest.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/placeholders.min.js"></script>
</head>
<body>

<!-- 회원정보 찾기 시작 { -->
<div id="find_info" class="new_win">
    <h1 id="win_title">회원정보 찾기</h1>
    <div class="new_win_con">
        <form name="fpasswordlost" action="http://ringpuppy2.dothome.co.kr/bbs/password_lost2.php" onsubmit="return fpasswordlost_submit(this);" method="post" autocomplete="off">
        <fieldset id="info_fs">
            <p>
                회원가입 시 등록하신 이메일 주소를 입력해 주세요.<br>
                해당 이메일로 아이디와 비밀번호 정보를 보내드립니다.
            </p>
            <label for="mb_email" class="sound_only">E-mail 주소<strong class="sound_only">필수</strong></label>
            <input type="text" name="mb_email" id="mb_email" required class="required frm_input full_input email" size="30" placeholder="E-mail 주소">
        </fieldset>
        
<script>var g5_captcha_url  = "http://ringpuppy2.dothome.co.kr/plugin/kcaptcha";</script>
<script src="http://ringpuppy2.dothome.co.kr/plugin/kcaptcha/kcaptcha.js"></script>
<fieldset id="captcha" class="captcha">
<legend><label for="captcha_key">자동등록방지</label></legend>
<img src="http://ringpuppy2.dothome.co.kr/plugin/kcaptcha/img/dot.gif" alt="" id="captcha_img"><input type="text" name="captcha_key" id="captcha_key" required class="captcha_box required" size="6" maxlength="6">
<button type="button" id="captcha_mp3"><span></span>숫자음성듣기</button>
<button type="button" id="captcha_reload"><span></span>새로고침</button>
<span id="captcha_info">자동등록방지 숫자를 순서대로 입력하세요.</span>
</fieldset>
        <div class="win_btn">
            <button type="submit" class="btn_submit">확인</button>
            <button type="button" onclick="window.close();" class="btn_close">창닫기</button>  
        </div>
        </form>
    </div>
</div>

<script>
function fpasswordlost_submit(f)
{
    if (!chk_captcha()) return false;

    return true;
}

$(function() {
    var sw = screen.width;
    var sh = screen.height;
    var cw = document.body.clientWidth;
    var ch = document.body.clientHeight;
    var top  = sh / 2 - ch / 2 - 100;
    var left = sw / 2 - cw / 2;
    moveTo(left, top);
});
</script>
<!-- } 회원정보 찾기 끝 -->

<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->


</body>
</html>
