<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="keywords" content="던킨, 도넛, 도너츠, 커피, DUNKIN' DONUTS, dunkindonuts, 던킨도너츠" /> 
<meta name="description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!" />

<meta name="robots" content="index">
<meta property="og:title" content="[Sweet Break, DUNKIN’ DONUTS]" />
<meta property="og:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">
<meta property="og:type" content="website" />
<meta property="og:image" content="/img/og-img.jpg" />
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="[Sweet Break, DUNKIN’ DONUTS]">
<meta name="twitter:url" content="https://www.dunkindonuts.co.kr/"/>
<meta name="twitter:image" content="/img/og-img.jpg">
<meta name="twitter:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">

<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>던킨</title>
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/css/default.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=191110">
<!--[if lte IE 8]>
<script src="http://ringpuppy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://ringpuppy2.dothome.co.kr";
var g5_bbs_url   = "http://ringpuppy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />


<link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/img/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script src="http://ringpuppy2.dothome.co.kr/js/jquery-1.12.4.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery.menu.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/common.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/wrest.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/placeholders.min.js"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub-guide.css">
<script src="/js/sub.js"></script>

<!-- 상단 시작 { -->
<div class="skip-nav">
    <a href="#container">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner"><!-- 1280 가운데정렬 -->
        <h1 class="logo"><a href="/">던킨</a></h1>
        <h2 class="hidden">메인메뉴</h2>
        <nav class="gnb">
            <ul class="gnb-wrap">
                <li class="depth1">
                    <a href="/sub/sub-brand.php">BRAND</a>
                    <dl class="gnb-s">
                        <dt>BRAND</dt>
                        <dd>던킨이야기</dd>
                        <dd><span>던킨도너츠</span>에<br>대해서 알아보세요.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-brand.php">브랜드 소개</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=brand">브랜드 소식</a></li>
                        <li><a href="/sub/sub-brand03.php">CF</a></li>
                        <li><a href="/sub/sub-brand04.php">왜 던킨인가?</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">STORE</a>
                    <dl class="gnb-s">
                        <dt>STORE</dt>
                        <dd>매장찾기</dd>
                        <dd>나와 가장 가까운<br><span>매장</span>을 찾아보세요.</dd>
                        <dd><img src="/img/gnb-img02.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">매장찾기</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=partner">신규매장</a></li>
                        <li><a href="/sub/sub-store03.php">품질우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">MENU</a>
                    <dl class="gnb-s">
                        <dt>MENU</dt>
                        <dd>이달의 도넛</dd>
                        <dd>매번 새로운<br>던킨의 다양한<br><span>도넛</span>을 만나보세요.</dd>
                        <dd><img src="/img/gnb-img03.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">DONUT</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu02">SANDWICHES</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu03">COFFEE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_baverage">BEVERAGE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_others">OTHERS</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-guide.php">창업안내</a>
                    <dl class="gnb-s">
                        <dt>START</dt>
                        <dd>창업안내</dd>
                        <dd>여러분의<br><span>새로운 출발,</span>던킨이<br>도와드리겠습니다.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-guide.php">대한민국 가맹시장</a></li>
                        <li><a href="/sub/sub-guide02.php">SPC와 함께하는</a></li>
                        <li><a href="/sub/sub-guide03.php">가맹점 개설절차</a></li>
                        <li><a href="/sub/sub-guide04.php">사업설명회</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa">FAQ</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-center.php">고객센터</a>
                    <dl class="gnb-s">
                        <dt>CENTER</dt>
                        <dd>고객센터</dd>
                        <dd>던킨의 <span>고개센터를</span><br>통해 궁금증을 해결하세요.</dd>
                        <dd><img src="/img/gnb-img05.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-center.php">접수 및 처리 절차</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa05">자주하는 질문</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=press&page=1">보도자료</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=gallery">이벤트</a></li>
                    </ul>
                </li>
            </ul>
            <div class="gnb-bg"></div>
        </nav>
        <div class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/register.php">JOIN</a></li>
                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/login.php">LOGIN</a></li>
                            </ul>
        </div>
    </div>
</header>
<!-- } 상단 끝 -->


<!-- 콘텐츠 시작 { -->
<main id="container">
    <div class="visual">
        <div class="inner">창업안내</div>
    </div>
    <div class="lnb inner">
        <ul class="lnb-wrap">
            <li><a href="/sub/sub-guide.php">대한민국 가맹시장</a></li>
            <li><a href="/sub/sub-guide02.php">SPC와 함께하는</a></li>
            <li><a href="/sub/sub-guide03.php">가맹점 개설절차</a></li>
            <li><a href="/sub/sub-guide04.php">사업설명회</a></li>
            <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa">FAQ</a></li>
        </ul>
    </div>
    <section class="sub04">
        <div class="inner">
<script>
    $(function(){
        $(".lnb li").removeClass();
        $(".lnb li").eq(3).addClass('on')
    })
</script>
<h2 class="tit">사업설명회</h2>
<article class="business">
    <div class="article-header">
        <h3 class="article-header-tit">DUNKIN사업설명회</h3>
        <p class="article-header-desc txt"><span>매주 3주차 목요일</span> 7개 도시를 돌아가며 가맹시장 안내 및<br>창업의 도움을 드리고, 던킨을 소개하는 자리를 가지고 있습니다.</p>
        <a href="http://survey.happypointcard.co.kr/survey/view/index/1046" target="_blank" class="article-header-link">사업설명회 사전예약 신청 바로가기<span class="material-symbols-outlined">arrow_forward_ios</span></a>
    </div>
    <div class="business-calendar">
        <h4 class="calender-tit">사업설명회 일정</h4>
        <ul class="calender-wrap clearfix">
            <li>
                <div class="calender-wrap-tit">
                    <em>08</em>
                    <strong>Aug</strong>
                    <p>신대방, 대전, 대구</p>
                </div>
                <table class="calender-wrap-box">
                    <thead>
                        <tr>
                            <th class="sun">Sun</th>
                            <th>Mon</th>
                            <th>Tue</th>
                            <th>Wed</th>
                            <th>Thu</th>
                            <th>Fri</th>
                            <th>Sat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td>1</td>
                            <td>2</td>
                            <td>3</td>
                            <td>4</td>
                            <td>5</td>
                            <td>6</td>
                        </tr>
                        <tr>
                            <td class="sun">7</td>
                            <td>8</td>
                            <td>9</td>
                            <td>10</td>
                            <td>11</td>
                            <td>12</td>
                            <td>13</td>
                        </tr>
                        <tr>
                            <td class="sun">14</td>
                            <td>15</td>
                            <td>16</td>
                            <td>17</td>
                            <td class="check">18<span>신대방<br>대전<br>대구</span></td>
                            <td>19</td>
                            <td>20</td>
                        </tr>
                        <tr>
                            <td class="sun">21</td>
                            <td>22</td>
                            <td>23</td>
                            <td>24</td>
                            <td>25</td>
                            <td>26</td>
                            <td>27</td>
                        </tr>
                        <tr>
                            <td class="sun">28</td>
                            <td>29</td>
                            <td>30</td>
                            <td>31</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </li>
            <li>
                <div class="calender-wrap-tit">
                    <em>09</em>
                    <strong>Sept</strong>
                    <p>신대방, 광주, 부산 / <span>강원</span></p>
                </div>
                <table class="calender-wrap-box">
                    <thead>
                        <tr>
                            <th class="sun">Sun</th>
                            <th>Mon</th>
                            <th>Tue</th>
                            <th>Wed</th>
                            <th>Thu</th>
                            <th>Fri</th>
                            <th>Sat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>1</td>
                            <td>2</td>
                            <td>3</td>
                        </tr>
                        <tr>
                            <td class="sun">4</td>
                            <td>5</td>
                            <td>6</td>
                            <td>7</td>
                            <td>8</td>
                            <td>9</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td class="sun">11</td>
                            <td>12</td>
                            <td>13</td>
                            <td>14</td>
                            <td class="check">15<span>신대방<br>광주<br>부산</span></td>
                            <td>16</td>
                            <td>17</td>
                        </tr>
                        <tr>
                            <td class="sun">18</td>
                            <td>19</td>
                            <td>20</td>
                            <td>21</td>
                            <td class="check2">22<span>강원</span></td>
                            <td>23</td>
                            <td>24</td>
                        </tr>
                        <tr>
                            <td class="sun">25</td>
                            <td>26</td>
                            <td>27</td>
                            <td>28</td>
                            <td>29</td>
                            <td>30</td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </li>
            <li>
                <div class="calender-wrap-tit">
                    <em>10</em>
                    <strong>Oct</strong>
                    <p>신대방, 대전, 대구</p>
                </div>
                <table class="calender-wrap-box">
                    <thead>
                        <tr>
                            <th class="sun">Sun</th>
                            <th>Mon</th>
                            <th>Tue</th>
                            <th>Wed</th>
                            <th>Thu</th>
                            <th>Fri</th>
                            <th>Sat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>1</td>
                        </tr>
                        <tr>
                            <td class="sun">2</td>
                            <td>3</td>
                            <td>4</td>
                            <td>5</td>
                            <td>6</td>
                            <td>7</td>
                            <td>8</td>
                        </tr>
                        <tr>
                            <td class="sun">9</td>
                            <td>10</td>
                            <td>11</td>
                            <td>12</td>
                            <td>13</td>
                            <td>14</td>
                            <td>15</td>
                        </tr>
                        <tr>
                            <td class="sun">16</td>
                            <td>17</td>
                            <td>18</td>
                            <td>19</td>
                            <td class="check">20<span>신대방<br>대전<br>대구</span></td>
                            <td>21</td>
                            <td>22</td>
                        </tr>
                        <tr>
                            <td class="sun">23</td>
                            <td>24</td>
                            <td>25</td>
                            <td>26</td>
                            <td>27</td>
                            <td>28</td>
                            <td>29</td>
                        </tr>
                        <tr>
                            <td class="sun">30</td>
                            <td>31</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </li>
        </ul>
        <p class="calender-more">상세 일정은 매월 초 홈페이지를 통해 공지 예정입니다.</p>
        <p class="calender-more">사전예약하는 분들에게 소정의 사은품을 드립니다.<span>(예약문의 02-2276-4791)</span></p>
    </div>
    <div class="business-place">
        <h4 class="place-tit">사업설명회 장소</h4>
        <div>
            <table class="place-box">
                <colgroup>
                    <col class="col1">
                    <col class="col2">
                    <col class="col3">
                </colgroup>
                <thead>
                    <tr>
                        <th>지역</th>
                        <th>상세주소</th>
                        <th>약도</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>수도권(신대방)</td>
                        <td>서울시 동작구 신대발16다길 BRK아카데미</td>
                        <td><a href="https://map.naver.com/v5/entry/place/19754294?placePath=%2Fhome&c=14127038.8630185,4507791.2629758,15,0,0,0,dh" target="_blank">약도<span class="material-symbols-outlined">location_on</span></a></td>
                    </tr>
                    <tr>
                        <td>대전</td>
                        <td>대전시 서구 한밭대로 755 삼성생명빌딩 16층 비알코리아 대전사무실</td>
                        <td><a href="https://map.naver.com/v5/search/%EB%8C%80%EC%A0%84%EC%8B%9C%20%EC%84%9C%EA%B5%AC%20%ED%95%9C%EB%B0%AD%EB%8C%80%EB%A1%9C%20755%20%EC%82%BC%EC%84%B1%EC%83%9D%EB%AA%85%EB%B9%8C%EB%94%A9/address/14180156.950669382,4350021.725703666,%EB%8C%80%EC%A0%84%EA%B4%91%EC%97%AD%EC%8B%9C%20%EC%84%9C%EA%B5%AC%20%ED%95%9C%EB%B0%AD%EB%8C%80%EB%A1%9C%20755,new?c=14180120.2597652,4350037.7879273,19,0,0,0,dh&isCorrectAnswer=true" target="_blank">약도<span class="material-symbols-outlined">location_on</span></a></td>
                    </tr>
                    <tr>
                        <td>대구</td>
                        <td>대구 수성구 동대구로 334 교직원 공제회관 12층 비알코리아 대구사무실</td>
                        <td><a href="https://map.naver.com/v5/entry/place/1961581337?c=14318247.7214633,4281371.8183852,15,0,0,0,dh" target="_blank">약도<span class="material-symbols-outlined">location_on</span></a></td>
                    </tr>
                    <tr>
                        <td>부산</td>
                        <td>부산시 동구 중앙대로 216 교원빌딩 4층 비알코리아 부산사무실</td>
                        <td><a href="https://map.naver.com/v5/search/%EB%B6%80%EC%82%B0%EC%8B%9C%20%EB%8F%99%EA%B5%AC%20%EC%A4%91%EC%95%99%EB%8C%80%EB%A1%9C%20216%20%EA%B5%90%EC%9B%90%EB%B9%8C%EB%94%A9/address/14364757.550182212,4179700.4776311126,%EB%B6%80%EC%82%B0%EA%B4%91%EC%97%AD%EC%8B%9C%20%EB%8F%99%EA%B5%AC%20%EC%A4%91%EC%95%99%EB%8C%80%EB%A1%9C%20216,new?c=14364695.4450383,4179701.3894325,19,0,0,0,dh&isCorrectAnswer=true" target="_blank">약도<span class="material-symbols-outlined">location_on</span></a></td>
                    </tr>
                    <tr>
                        <td>광주</td>
                        <td>광주시 광산구 장신로 85 수영빌딩 6층 비알코리아 광주사무실</td>
                        <td><a href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EC%8B%9C%20%EA%B4%91%EC%82%B0%EA%B5%AC%20%EC%9E%A5%EC%8B%A0%EB%A1%9C%2085%20%EC%88%98%EC%98%81%EB%B9%8C%EB%94%A9/address/14117475.873106297,4189894.2863271516,%EA%B4%91%EC%A3%BC%EA%B4%91%EC%97%AD%EC%8B%9C%20%EA%B4%91%EC%82%B0%EA%B5%AC%20%EC%9E%A5%EC%8B%A0%EB%A1%9C%2085,new?c=14117449.6796301,4189903.9712208,19,0,0,0,dh&isCorrectAnswer=true" target="_blank">약도<span class="material-symbols-outlined">location_on</span></a></td>
                    </tr>
                    <tr>
                        <td>원주</td>
                        <td>강원도 원주시 호저로 47 강원도경제진흥원</td>
                        <td><a href="https://map.naver.com/v5/entry/place/11877427?placePath=%2Fhome&c=14241783.3651128,4492298.0956219,15,0,0,0,dh" target="_blank">약도<span class="material-symbols-outlined">location_on</span></a></td>
                    </tr>
                    <tr>
                        <td>제주</td>
                        <td>제주특별자치도 제주시 중앙로 216 던킨 제주시청점 2층</td>
                        <td><a href="https://map.naver.com/v5/search/%EC%A0%9C%EC%A3%BC%ED%8A%B9%EB%B3%84%EC%9E%90%EC%B9%98%EB%8F%84%20%EC%A0%9C%EC%A3%BC%EC%8B%9C%20%EC%A4%91%EC%95%99%EB%A1%9C%20216/address/14085168.997655053,3961869.014761919,%EC%A0%9C%EC%A3%BC%ED%8A%B9%EB%B3%84%EC%9E%90%EC%B9%98%EB%8F%84%20%EC%A0%9C%EC%A3%BC%EC%8B%9C%20%EC%A4%91%EC%95%99%EB%A1%9C%20216,new?c=14085138.8078091,3961869.5887904,19,0,0,0,dh&isCorrectAnswer=true" target="_blank">약도<span class="material-symbols-outlined">location_on</span></a></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <ul class="place-wrap clearfix">
            <li>
                <table class="place-wrap-box">
                    <colgroup>
                        <col class="col4">
                        <col class="col5">
                        <col class="col6">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>담당자</th>
                            <th>연락처</th>
                            <th>담당 지역</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>이윤석 차장</td>
                            <td>010-3200-7658</td>
                            <td rowspan="4" class="place">수도권</td>
                        </tr>
                        <tr>
                            <td>이선부 차장</td>
                            <td>010-4849-7751</td>
                        </tr>
                        <tr>
                            <td>김경완 차장</td>
                            <td>010-9534-0026</td>
                        </tr>
                        <tr>
                            <td>정광수 과장</td>
                            <td>010-3584-2109</td>
                        </tr>
                    </tbody>
                </table>
            </li>
            <li>
                <table class="place-wrap-box">
                    <colgroup>
                        <col class="col4">
                        <col class="col5">
                        <col class="col6">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>담당자</th>
                            <th>연락처</th>
                            <th>담당 지역</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>김상근 차장</td>
                            <td>010-7616-2361</td>
                            <td>전남, 전북, 제주</td>
                        </tr>
                        <tr>
                            <td>곽영민 차장</td>
                            <td>010-2890-7728</td>
                            <td>대구, 경북</td>
                        </tr>
                        <tr>
                            <td>장지웅 차장</td>
                            <td>010-2821-0745</td>
                            <td>부산, 울산, 경남</td>
                        </tr>
                        <tr>
                            <td>박동희 과장</td>
                            <td>010-6634-2302</td>
                            <td>충청</td>
                        </tr>
                    </tbody>
                </table>
            </li>
        </ul>
    </div>
    <div class="business-contents">
        <h4 class="contents-tit">사업설명회 내용</h4>
        <div>
            <table class="contents-box">
                <colgroup>
                    <col class="col7">
                    <col class="col8">
                    <col class="col9">
                </colgroup>
                <tr>
                    <td>1. 사전 안내</td>
                    <td class="contents-txt">가맹상담신청서 작성 및 안내</td>
                    <td>5분</td>
                </tr>
                <tr>
                    <td>2. 동영상 자료 시청</td>
                    <td class="contents-txt">SPC 및 던킨 브랜드 소개 영상</td>
                    <td>5분</td>
                </tr>
                <tr>
                    <td rowspan="3">3. 여러분의 출발 던킨이 도와 드리겠습니다.</td>
                    <td class="contents-txt">가맹시장의 현황</td>
                    <td rowspan="3">40분</td>
                </tr>
                <tr>
                    <td class="contents-txt">던킨 사업의 A TO Z</td>
                </tr>
                <tr>
                    <td class="contents-txt">개설 안내 및 Q&A</td>
                </tr>
                <tr>
                    <td>4. 개별상담</td>
                    <td class="contents-txt">희망지역 담당자의 개별 미팅</td>
                    <td>30분</td>
                </tr>
            </table>
        </div>
    </div>
</article>

</div>
</section>

</main>
<!-- } 메인콘텐츠 끝 -->


<!-- 하단 시작 { -->
<footer id="footer">
    <div class="inner">
        <h2 class="f-logo">던킨</h2>
        <ul class="f-menu clearfix">
            <li><a href="/sub/sub-f-use.php">이용약관</a></li>
            <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
            <li><a href="/sub/sub-f-privacy.php">영상정보처리기기운영방침</a></li>
            <li><a href="/sub/sub-f-safety.php">안전보건경영방침</a></li>
        </ul>
        <div class="f-banner">
            <div class="f-site">
                <p class="f-site-tit">Family site<span class="material-symbols-outlined">expand_less</span></p>
                <ul class="f-site-box">
                    <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
                    <li><a href="http://www.brkorea.co.kr/">비알코리아</a></li>
                    <li><a href="http://www.baskinrobbins.co.kr/">배스킨라빈스</a></li>
                    <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
                    <li><a href="https://shany.co.kr/">샤니</a></li>
                    <li><a href="https://www.caffe-pascucci.co.kr/index.asp">파스쿠찌</a></li>
                    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=044D0806A9BA8A6F21BEDA177BB8A053">해피포인트카드</a></li>
                    <li><a href="https://dunkinschool.hunet.co.kr/Login/LoginGate">던킨 온라인 스쿨</a></li>
                    <li><a href="https://dunkin.alba.co.kr/job/brand/main.asp">던킨 아르바이트</a></li>
                </ul>
            </div>
            <ul class="f-sns">
                <li><a href="https://www.facebook.com/DunkinKorea" target="_blank">페이스북</a></li>
                <li><a href="https://www.instagram.com/dunkin_kr/" target="_blank">인스타그램</a></li>
                <li><a href="https://blog.naver.com/dunkin_kr" target="_blank">블로그</a></li>
                <li><a href="https://www.youtube.com/user/dunkindonutskorea" target="_blank">유튜브</a></li>
                <li><a href="https://twitter.com/dunkin_kr" target="_blank">트위터</a></li>
            </ul>
            <ul class="f-mark">
                <li><a href="http://www.spc.co.kr/contributionAll"  target="_blank">SPC행복한 이야기</a></li>
                <li><a href="https://www.kca.go.kr/ccm/" target="_blank">소비자중심경영</a></li>
                <li><a href="https://knqa.ksa.or.kr/knqa/2276/subview.do" target="_blank">국가품질상</a></li>
            </ul>
        </div>
        <div class="f-copy">
            <ul class="f-add clearfix">
                <li><address>서울특별시 서초구 남부순환로 2620(양재동 11-149번지)</address></li>
                <li>TEL : 080-555-3131</li>
                <li>VOC상담: 080-555-3131</li>
                <li>개인정보관리책임자 : 김경우</li>
                <li>사업자 등록번호 : 303-81-09535</li>
                <li>비알코리아(주) 대표이사 도세호</li>
            </ul>
            <p>COPYRIGHT Ⓒ 2016 BRKOREA COMPANY. ALL RIGHTS RESERVED.</p>
        </div>
    </div>
</footer>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    });
</script>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->


</body>
</html>
