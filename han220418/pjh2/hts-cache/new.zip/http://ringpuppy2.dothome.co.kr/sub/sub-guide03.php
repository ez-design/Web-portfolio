<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="keywords" content="던킨, 도넛, 도너츠, 커피, DUNKIN' DONUTS, dunkindonuts, 던킨도너츠" /> 
<meta name="description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!" />

<meta name="robots" content="index">
<meta property="og:title" content="[Sweet Break, DUNKIN’ DONUTS]" />
<meta property="og:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">
<meta property="og:type" content="website" />
<meta property="og:image" content="/img/og-img.jpg" />
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="[Sweet Break, DUNKIN’ DONUTS]">
<meta name="twitter:url" content="https://www.dunkindonuts.co.kr/"/>
<meta name="twitter:image" content="/img/og-img.jpg">
<meta name="twitter:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">

<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>던킨</title>
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/css/default.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=191110">
<!--[if lte IE 8]>
<script src="http://ringpuppy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://ringpuppy2.dothome.co.kr";
var g5_bbs_url   = "http://ringpuppy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />


<link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/img/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script src="http://ringpuppy2.dothome.co.kr/js/jquery-1.12.4.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery.menu.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/common.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/wrest.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/placeholders.min.js"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub-guide.css">
<script src="/js/sub.js"></script>

<!-- 상단 시작 { -->
<div class="skip-nav">
    <a href="#container">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner"><!-- 1280 가운데정렬 -->
        <h1 class="logo"><a href="/">던킨</a></h1>
        <h2 class="hidden">메인메뉴</h2>
        <nav class="gnb">
            <ul class="gnb-wrap">
                <li class="depth1">
                    <a href="/sub/sub-brand.php">BRAND</a>
                    <dl class="gnb-s">
                        <dt>BRAND</dt>
                        <dd>던킨이야기</dd>
                        <dd><span>던킨도너츠</span>에<br>대해서 알아보세요.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-brand.php">브랜드 소개</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=brand">브랜드 소식</a></li>
                        <li><a href="/sub/sub-brand03.php">CF</a></li>
                        <li><a href="/sub/sub-brand04.php">왜 던킨인가?</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">STORE</a>
                    <dl class="gnb-s">
                        <dt>STORE</dt>
                        <dd>매장찾기</dd>
                        <dd>나와 가장 가까운<br><span>매장</span>을 찾아보세요.</dd>
                        <dd><img src="/img/gnb-img02.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">매장찾기</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=partner">신규매장</a></li>
                        <li><a href="/sub/sub-store03.php">품질우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">MENU</a>
                    <dl class="gnb-s">
                        <dt>MENU</dt>
                        <dd>이달의 도넛</dd>
                        <dd>매번 새로운<br>던킨의 다양한<br><span>도넛</span>을 만나보세요.</dd>
                        <dd><img src="/img/gnb-img03.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">DONUT</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu02">SANDWICHES</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu03">COFFEE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_baverage">BEVERAGE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_others">OTHERS</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-guide.php">창업안내</a>
                    <dl class="gnb-s">
                        <dt>START</dt>
                        <dd>창업안내</dd>
                        <dd>여러분의<br><span>새로운 출발,</span>던킨이<br>도와드리겠습니다.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-guide.php">대한민국 가맹시장</a></li>
                        <li><a href="/sub/sub-guide02.php">SPC와 함께하는</a></li>
                        <li><a href="/sub/sub-guide03.php">가맹점 개설절차</a></li>
                        <li><a href="/sub/sub-guide04.php">사업설명회</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa">FAQ</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-center.php">고객센터</a>
                    <dl class="gnb-s">
                        <dt>CENTER</dt>
                        <dd>고객센터</dd>
                        <dd>던킨의 <span>고개센터를</span><br>통해 궁금증을 해결하세요.</dd>
                        <dd><img src="/img/gnb-img05.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-center.php">접수 및 처리 절차</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa05">자주하는 질문</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=press&page=1">보도자료</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=gallery">이벤트</a></li>
                    </ul>
                </li>
            </ul>
            <div class="gnb-bg"></div>
        </nav>
        <div class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/register.php">JOIN</a></li>
                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/login.php">LOGIN</a></li>
                            </ul>
        </div>
    </div>
</header>
<!-- } 상단 끝 -->


<!-- 콘텐츠 시작 { -->
<main id="container">
    <div class="visual">
        <div class="inner">창업안내</div>
    </div>
    <div class="lnb inner">
        <ul class="lnb-wrap">
            <li><a href="/sub/sub-guide.php">대한민국 가맹시장</a></li>
            <li><a href="/sub/sub-guide02.php">SPC와 함께하는</a></li>
            <li><a href="/sub/sub-guide03.php">가맹점 개설절차</a></li>
            <li><a href="/sub/sub-guide04.php">사업설명회</a></li>
            <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa">FAQ</a></li>
        </ul>
    </div>
    <section class="sub04">
        <div class="inner">
<script>
    $(function(){
        $(".lnb li").removeClass();
        $(".lnb li").eq(2).addClass('on')
    })
</script>
<h2 class="tit">가맹점 개설절차</h2>
<article class="open">
    <div class="article-header">
        <h3 class="article-header-tit">OPEN PROCESS</h3>
        <p class="article-header-desc">여러분의 최적의 던킨을 제공하기 위해 아래와 같은 <span>절차</span>를 진행합니다.<br>입지에 맞는 <span>최적의 던킨</span>을 제공하기 위해 45~60일간<br><span>6단계의 절차</span>를 거쳐 던킨 점포가 탄생하게 됩니다.</p>
    </div>
    <ul class="open-wrap clearfix">
        <li>
            <div class="open-icon"></div>
            <em class="open-num">STEP 01</em>
            <strong class="open-tit">창업의뢰</strong>
            <p class="open-txt">예비창업자로부터<br>개설희망 접수</p>
        </li>
        <li>
            <div class="open-icon"></div>
            <em class="open-num">STEP 02</em>
            <strong class="open-tit">시장조사</strong>
            <p class="open-txt">입지분석 및 선정 등<br>대략 7일의 기간이<br>소요됩니다.</p>
        </li>
        <li>
            <div class="open-icon"></div>
            <em class="open-num">STEP 03</em>
            <strong class="open-tit">창업승인  / 점포계약</strong>
            <p class="open-txt">창업승인 후 매장을 운영하실<br>점포를 계약합니다.</p>
        </li>
        <li>
            <div class="open-icon"></div>
            <em class="open-num">STEP 04</em>
            <strong class="open-tit">가맹계약  / 인테리어 계약</strong>
            <p class="open-txt">본사와 프랜차이즈 가맹계약 체결과 동시에<br>매장의 인테리어 입찰 및 계약이 진행됩니다.</p>
        </li>
        <li>
            <div class="open-icon"></div>
            <em class="open-num">STEP 05</em>
            <strong class="open-tit">가맹점주 교육  /<br>인테리어 시공</strong>
            <p class="open-txt">가맹점주님의 이론교육 및 현장교육이 진행되며<br>동시에 매장의 인테리어 시공을 진행합니다.<br>[교육 2인 이수, 16일간 / 공사기간 약 15~20일 소요]</p>
        </li>
        <li>
            <div class="open-icon"></div>
            <em class="open-num">STEP 06</em>
            <strong class="open-tit">개점준비 및 교육 /<br>영업신고 및 사업자 등록</strong>
            <p class="open-txt">전체적인 개점 준비와 점주님의<br>개점 교육이 진행됩니다. 또한, 오픈일 기준 최소<br>10일전 영업신고 및 사업자 등록을 완료합니다.</p>
        </li>
        <li>
            <div class="open-icon"></div>
            <em class="open-num">STEP 07</em>
            <strong class="open-tit">OPEN</strong>
            <p class="open-txt">짝짝짝!<br>던킨 오픈을<br>축하드립니다.</p>
        </li>
    </ul>
</article>
<article class="condition">
    <div class="article-header">
        <h3 class="article-header-tit">CONDITION</h3>
        <p class="article-header-desc">던킨 가맹점 <span>개설조건</span>을 확인해보세요.</p>
    </div>
    <p class="condition-txt">(단위 : 천원, 부가세포함)</p>
    <div class="list">
        <table class="list-wrap">
            <caption class="hidden">개설조건 설명</caption>
            <colgroup>
                <col class="col1">
                <col class="col2">
                <col class="col3">
                <col class="col4">
            </colgroup>
            <thead class="list-tit">
                <tr>
                    <th colspan="2" class="list-cate">구분</th>
                    <th scope="col" class="list-sum">금액</th>
                    <th scope="col" class="list-note">비고</th>
                </tr>
            </thead>
            <tbody class="list-box">
                <tr>
                    <td rowspan="5" class="list-box-tit">본사납입금</td>
                    <td>가맹비</td>
                    <td>5,500</td>
                    <td>소멸성 비용</td>
                </tr>
                <tr>
                    <td>계약이행보증금</td>
                    <td>10,000</td>
                    <td>계약종료 시 반환<span>*휴게소 등 월단위 결제점포의 경우 40,000천원 적용</span></td>
                </tr>
                <tr>
                    <td>기획관리비</td>
                    <td>3,300</td>
                    <td>인테리어 공사진행 관리, 감독</td>
                </tr>
                <tr>
                    <td>교육비</td>
                    <td>1,650</td>
                    <td>이론, 실습교육 (최대 15일)</td>
                </tr>
                <tr class="list-box-total">
                    <td>소계</td>
                    <td>20,450</td>
                    <td></td>
                </tr>
                <tr>
                    <td rowspan="7" class="list-box-tit">투자비</td>
                    <td>판매장비</td>
                    <td>54,900 ~ 60,300</td>
                    <td>점포 특성에 따라 변동</td>
                </tr>
                <tr>
                    <td>간판 (내외부Sign)</td>
                    <td>9,000 ~ 13,000</td>
                    <td>점포 특성에 따라 변동</td>
                </tr>
                <tr>
                    <td>의탁자</td>
                    <td>6,000 ~ 8,000</td>
                    <td>점포 특성에 따라 변동</td>
                </tr>
                <tr>
                    <td>인테리어</td>
                    <td>36,000 ~ 46,000</td>
                    <td>점포 특성에 따라 변동</td>
                </tr>
                <tr>
                    <td>초도 제품, 상품</td>
                    <td>11,000 ~ 16,500</td>
                    <td>제품, 상품</td>
                </tr>
                <tr>
                    <td>기타</td>
                    <td>8,800 ~ 10,000</td>
                    <td>에어컨, CCTV, 보안 外</td>
                </tr>
                <tr class="list-box-total">
                    <td>소계</td>
                    <td>125,700 ~ 153,800</td>
                    <td></td>
                </tr>
            </tbody>
            <tfoot class="list-total">
                <tr>
                    <td colspan="2">합계 (본사납입금 + 투자비)</td>
                    <td>146,150 ~ 174,250</td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="info">
        <p>상기 금액은 당사의 가맹점 운영 경험을 토대로 추정한 것으로 실제 지불금액과는 다를 수 있음</p>
        <p>전기증설(최소25KW) 비용, 정화조 증설비용 등 점포 여건에 따라 추가 비용이 발생할 수 있음</p>
        <p>임대차 비용 별도</p>
    </div>
</article>
<article class="consult">
    <div class="article-header"><h3 class="article-header-tit">CONSULT</h3></div>
    <div class="consult-info">
        <p>가맹점 문의/점포개설에 대한 상담은 전화 및 팩스, 이메일 모두 가능합니다.</p>
        <p>홈페이지상에서는 관련 내용만 안내하오니 점포개설에 대한 구체적인 상담은 지역별 담당자와 유선상담을 부탁 드립니다.</p>
        <p>구체적인 의뢰 점포가 있을시는 E-mail로 점포주소, 위치도, 임차조건, 평수를 보내주시면 상담이 더욱 용이합니다.</p>
    </div>
    <div class="list">
        <table class="list-wrap">
            <caption class="hidden">가맹점 문의/점포개설에 대한 상담</caption>
            <colgroup>
                <col class="col1">
                <col class="col2">
                <col class="col3">
                <col class="col4">
            </colgroup>
            <thead class="list-tit">
                <tr>
                    <th scope="col" class="list-name">담당자</th>
                    <th scope="col" class="list-mail">이메일</th>
                    <th scope="col" class="list-tel">연락처</th>
                    <th scope="col" class="list-area">지역</th>
                </tr>
            </thead>
            <tbody class="list-box">
                <tr>
                    <td>이선부 차장</td>
                    <td>artlover77@spc.co.kr</td>
                    <td>Tel : 010-4849-7751</td>
                    <td>
                        <span>*가맹담당*</span>
                        <p><span>서울</span>동작구, 관악구, 서초구, 강남구, 송파구, 광진구, 강동구</p>
                        <p><span>경기</span>김포시, 파주시, 고양시, 수원시, 오산시, 화성시, 용인시, 하남시</p>
                    </td>
                </tr>
                <tr>
                    <td>이윤석 차장</td>
                    <td>aceys@spc.co.kr</td>
                    <td>Tel : 010-3200-7658</td>
                    <td>
                        <span>*직영담당*</span>
                        <p>서울, 수도권 직영점</p>
                    </td>
                </tr>
                <tr>
                    <td>김경완 차장</td>
                    <td>mlb2583@spc.co.kr</td>
                    <td>Tel : 010-9534-0026</td>
                    <td>
                        <span>*가맹담당*</span>
                        <p><span>서울</span>강서구, 양천구, 마포구, 영등포구, 구로구, 금천구, 은평구,<br>서대문구, 종로구, 중구, 용산구, 성동구</p>
                        <p><span>경기</span>인천시, 부천시, 광명시, 시흥시, 안산시, 안양시, 의왕시, 군포시,<br>과천시</p>
                    </td>
                </tr>
                <tr>
                    <td>정광수 과장</td>
                    <td>ks.jung@spc.co.kr</td>
                    <td>Tel : 010-3584-2109</td>
                    <td>
                        <span>*가맹담당*</span>
                        <p><span>서울</span>도봉구, 강북구, 노원구, 성북구, 동대문구, 중랑구</p>
                        <p><span>경기</span>양주시, 의정부시, 가평군, 남양주시, 구리시, 양평군, 광주시,<br>성남시, 이천시, 여주시, 연천군, 포천시, 동두천시, 평택시, 안성시</p>
                        <p><span>강원</span></p>
                    </td>
                </tr>
                <tr>
                    <td>박동희 과장</td>
                    <td>aura3679@spc.co.kr</td>
                    <td>Tel : 010-6634-2302</td>
                    <td><span>충남</span> (대전/세종), <span>충북</span></td>
                </tr>
                <tr>
                    <td>김상근 차장</td>
                    <td>2272361@spc.co.kr</td>
                    <td>Tel : 010-7616-2361</td>
                    <td><span>전남</span> (광주), <span>전북, 제주</span></td>
                </tr>
                <tr>
                    <td>곽영민 차장</td>
                    <td>graywolf23@spc.co.kr</td>
                    <td>Tel : 010-2890-7728</td>
                    <td><span>경북, 대구</span></td>
                </tr>
                <tr>
                    <td>장지웅 차장</td>
                    <td>jiung95@spc.co.kr</td>
                    <td>Tel : 010-2821-0745</td>
                    <td><span>부산, 울산, 경남</span></td>
                </tr>
            </tbody>
        </table>
    </div>
</article>


</div>
</section>

</main>
<!-- } 메인콘텐츠 끝 -->


<!-- 하단 시작 { -->
<footer id="footer">
    <div class="inner">
        <h2 class="f-logo">던킨</h2>
        <ul class="f-menu clearfix">
            <li><a href="/sub/sub-f-use.php">이용약관</a></li>
            <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
            <li><a href="/sub/sub-f-privacy.php">영상정보처리기기운영방침</a></li>
            <li><a href="/sub/sub-f-safety.php">안전보건경영방침</a></li>
        </ul>
        <div class="f-banner">
            <div class="f-site">
                <p class="f-site-tit">Family site<span class="material-symbols-outlined">expand_less</span></p>
                <ul class="f-site-box">
                    <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
                    <li><a href="http://www.brkorea.co.kr/">비알코리아</a></li>
                    <li><a href="http://www.baskinrobbins.co.kr/">배스킨라빈스</a></li>
                    <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
                    <li><a href="https://shany.co.kr/">샤니</a></li>
                    <li><a href="https://www.caffe-pascucci.co.kr/index.asp">파스쿠찌</a></li>
                    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=044D0806A9BA8A6F21BEDA177BB8A053">해피포인트카드</a></li>
                    <li><a href="https://dunkinschool.hunet.co.kr/Login/LoginGate">던킨 온라인 스쿨</a></li>
                    <li><a href="https://dunkin.alba.co.kr/job/brand/main.asp">던킨 아르바이트</a></li>
                </ul>
            </div>
            <ul class="f-sns">
                <li><a href="https://www.facebook.com/DunkinKorea" target="_blank">페이스북</a></li>
                <li><a href="https://www.instagram.com/dunkin_kr/" target="_blank">인스타그램</a></li>
                <li><a href="https://blog.naver.com/dunkin_kr" target="_blank">블로그</a></li>
                <li><a href="https://www.youtube.com/user/dunkindonutskorea" target="_blank">유튜브</a></li>
                <li><a href="https://twitter.com/dunkin_kr" target="_blank">트위터</a></li>
            </ul>
            <ul class="f-mark">
                <li><a href="http://www.spc.co.kr/contributionAll"  target="_blank">SPC행복한 이야기</a></li>
                <li><a href="https://www.kca.go.kr/ccm/" target="_blank">소비자중심경영</a></li>
                <li><a href="https://knqa.ksa.or.kr/knqa/2276/subview.do" target="_blank">국가품질상</a></li>
            </ul>
        </div>
        <div class="f-copy">
            <ul class="f-add clearfix">
                <li><address>서울특별시 서초구 남부순환로 2620(양재동 11-149번지)</address></li>
                <li>TEL : 080-555-3131</li>
                <li>VOC상담: 080-555-3131</li>
                <li>개인정보관리책임자 : 김경우</li>
                <li>사업자 등록번호 : 303-81-09535</li>
                <li>비알코리아(주) 대표이사 도세호</li>
            </ul>
            <p>COPYRIGHT Ⓒ 2016 BRKOREA COMPANY. ALL RIGHTS RESERVED.</p>
        </div>
    </div>
</footer>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    });
</script>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->


</body>
</html>
