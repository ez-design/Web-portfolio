<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="keywords" content="던킨, 도넛, 도너츠, 커피, DUNKIN' DONUTS, dunkindonuts, 던킨도너츠" /> 
<meta name="description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!" />

<meta name="robots" content="index">
<meta property="og:title" content="[Sweet Break, DUNKIN’ DONUTS]" />
<meta property="og:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">
<meta property="og:type" content="website" />
<meta property="og:image" content="/img/og-img.jpg" />
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="[Sweet Break, DUNKIN’ DONUTS]">
<meta name="twitter:url" content="https://www.dunkindonuts.co.kr/"/>
<meta name="twitter:image" content="/img/og-img.jpg">
<meta name="twitter:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">

<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>던킨</title>
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/css/default.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=191110">
<!--[if lte IE 8]>
<script src="http://ringpuppy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://ringpuppy2.dothome.co.kr";
var g5_bbs_url   = "http://ringpuppy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />


<link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/img/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script src="http://ringpuppy2.dothome.co.kr/js/jquery-1.12.4.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery.menu.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/common.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/wrest.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/placeholders.min.js"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub-menu.css">
<script src="/js/sub.js"></script>

<!-- 상단 시작 { -->
<div class="skip-nav">
    <a href="#container">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner"><!-- 1280 가운데정렬 -->
        <h1 class="logo"><a href="/">던킨</a></h1>
        <h2 class="hidden">메인메뉴</h2>
        <nav class="gnb">
            <ul class="gnb-wrap">
                <li class="depth1">
                    <a href="/sub/sub-brand.php">BRAND</a>
                    <dl class="gnb-s">
                        <dt>BRAND</dt>
                        <dd>던킨이야기</dd>
                        <dd><span>던킨도너츠</span>에<br>대해서 알아보세요.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-brand.php">브랜드 소개</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=brand">브랜드 소식</a></li>
                        <li><a href="/sub/sub-brand03.php">CF</a></li>
                        <li><a href="/sub/sub-brand04.php">왜 던킨인가?</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">STORE</a>
                    <dl class="gnb-s">
                        <dt>STORE</dt>
                        <dd>매장찾기</dd>
                        <dd>나와 가장 가까운<br><span>매장</span>을 찾아보세요.</dd>
                        <dd><img src="/img/gnb-img02.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">매장찾기</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=partner">신규매장</a></li>
                        <li><a href="/sub/sub-store03.php">품질우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">MENU</a>
                    <dl class="gnb-s">
                        <dt>MENU</dt>
                        <dd>이달의 도넛</dd>
                        <dd>매번 새로운<br>던킨의 다양한<br><span>도넛</span>을 만나보세요.</dd>
                        <dd><img src="/img/gnb-img03.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">DONUT</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu02">SANDWICHES</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu03">COFFEE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_baverage">BEVERAGE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_others">OTHERS</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-guide.php">창업안내</a>
                    <dl class="gnb-s">
                        <dt>START</dt>
                        <dd>창업안내</dd>
                        <dd>여러분의<br><span>새로운 출발,</span>던킨이<br>도와드리겠습니다.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-guide.php">대한민국 가맹시장</a></li>
                        <li><a href="/sub/sub-guide02.php">SPC와 함께하는</a></li>
                        <li><a href="/sub/sub-guide03.php">가맹점 개설절차</a></li>
                        <li><a href="/sub/sub-guide04.php">사업설명회</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa">FAQ</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-center.php">고객센터</a>
                    <dl class="gnb-s">
                        <dt>CENTER</dt>
                        <dd>고객센터</dd>
                        <dd>던킨의 <span>고개센터를</span><br>통해 궁금증을 해결하세요.</dd>
                        <dd><img src="/img/gnb-img05.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-center.php">접수 및 처리 절차</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa05">자주하는 질문</a></li>
                        <li><a href="#">보도자료</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=gallery">이벤트</a></li>
                    </ul>
                </li>
            </ul>
            <div class="gnb-bg"></div>
        </nav>
        <div class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/register.php">JOIN</a></li>
                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/login.php">LOGIN</a></li>
                            </ul>
        </div>
    </div>
</header>
<!-- } 상단 끝 -->


<!-- 콘텐츠 시작 { -->
<main id="container">
    <section class="sub06">
        <div class="inner">

<h2 class="tit">이용약관</h2>
<ul class="use">
    <li class="use-box">
        <h3 class="use-box-tit">제 1조(목적)</h3>
        <p class="use-box-desc">본 약관은 해피포인트카드 회원이 주식회사 섹타나인(이하 "당사")에서 제공하는 해피포인트카드 서비스를 이용함에 있어 해피포인트카드 회원과 당사의 제반 권리의무 및 관련 절차 등을 규정하는 데 그 목적이 있습니다.</p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 2조 (운영)</h3>
        <p class="use-box-desc">해피포인트 카드는 당사에서 운영하며, 해피포인트 카드 서비스는 본 약관에 동의하고 당사의 승인을 얻은 회원, 제휴가맹점에 적용됩니다.</p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 3조 (용어의 정의)</h3>
        <p class="use-box-desc">① "해피포인트카드 회원"(이하 "회원")이라 함은 당사의 약관을 승인하고 정해진 가입 절차를 통하여 가입하여 당사로부터 회원 자격을 부여 받아 정상적으로 해피포인트카드 서비스를 이용할 수 있는 고객을 말합니다.<br>② "해피포인트카드 서비스"라 함은 회원을 위해 당사가 제공하는 서비스로 해피포인트 적립 및 사용 서비스를 말합니다.<br>③ "해피포인트카드"(이하 "카드")라 함은 회원이 해피포인트카드 서비스를 정상적으로 이용할 수 있도록 당사 또는 당사와 제휴 계약을 체결한 업체가 발급한 카드로 종류는 다음과 같습니다.
            <span class="use-box-des-more">
                1. 일반 마일리지 카드 : 단순한 포인트 적립 및 사용만 가능한 기본 카드를 의미함.<br>2. 해피포인트 모바일 카드(이하 "모바일 카드") : 당사 또는 당사와 서비스 계약을 체결한 제휴가맹점에서 제공하는 스마트폰 어플리케이션을 통하여 발급받거나 등록한 카드로, 기본카드의 기능을 포함함<br>3. 해피포인트 제휴카드(이하 "제휴카드") : 해피포인트카드의 기본적인 마일리지 서비스와 신용카드 또는 체크카드, 선불카드 등의 기능이 결합된 제휴 업체 발급 카드를 의미함.
            </span>
        ④ "해피포인트"(이하 “포인트”)라 함은 당사의 브랜드, 제휴가맹점에서 제품 및 서비스를 구입할 경우 당사 및 제휴가맹점이 고지한 적립률에 따라 부여되는 포인트를 의미합니다.<br>⑤ "가용 포인트", "잔여 포인트"라 함은 회원이 적법하게 부여 받은 해피포인트 중 이미 사용한 포인트를 제외한 나머지 해피포인트의 합계를 의미합니다.<br>⑥ "제휴가맹점"은 온/오프라인 상의 당사 또는 SPC그룹 계열사 브랜드의 직영점 또는 가맹점 및 당사와 제휴 계약을 체결하고 해피포인트를 공동으로 운영하거나 회원 대상의 서비스를 제공하기로 합의한 업체 또는 점포 전체를 의미합니다. 단, 당사 또는 SPC그룹 계열사 브랜드의 직영점 또는 가맹점 중 휴게소, 지하철 역사, 기타 사업장에 입점한 형태의 일부 업체 또는 점포의 경우, 제휴가맹점에서 제외되어 해피포인트 적립 또는 사용이 불가능할 수 있습니다. 제휴가맹점의 추가, 변경 시 당사는 제4조에 따른 방법에 따라 사전에 고지합니다.<br>⑦ 당사와 회원 사이에 개별적으로 합의한 사항이 본 약관에 정한 사항과 다를 때에는 그 합의사항을 본 약관에 우선하여 적용하며, 전자금융거래에 관하여 본 약관에 정하지 않은 사항은 개별약관이 정하는 바에 따릅니다. 당사는 본 약관과 전자금융거래에 관한 개별약관에 정하지 않은 사항(용어의 정의 포함)에 대하여는 다른 합의사항이 없으면 전자금융거래법, 전자상거래 등에서의 소비자 보호에 관한 법률 등 관계 법령에서 정한 바에 따릅니다.
        </p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 4조 (약관개정)</h3>
        <p class="use-box-desc">① 본 약관은 수시로 개정될 수 있으며 약관을 개정하고자 할 경우 당사는 개정된 약관을 적용하고자 하는 날(이하 "효력 발생일"이라고 합니다)로부터 1개월 전에 약관이 개정된다는 사실과 개정된 내용 등을 회원에게 고지하여 드립니다. 단, 법령의 개정으로 인하여 긴급하게 약관을 변경하는 때에는 해피포인트 홈페이지(www.happypointcard.com)(이하 "홈페이지")또는 해피포인트 모바일 어플리케이션(이하 "해피앱")에 이를 즉시 게시하고 회원에게 고지합니다.<br>② 당사가 e-mail통보 또는 서면통보의 방법으로 본 약관이 개정된 사실 및 개정된 내용을 회원에게 고지하는 경우에는 회원이 당사에 기제공한 e-mail 주소나 주소지 중 가장 최근에 제공된 e-mail이나 주소지로 통보합니다.<br>③ 본 조의 규정에 의하여 개정된 약관(이하 "개정약관")은 원칙적으로 그 효력 발생일로부터 장래를 향하여 유효합니다.<br>④ 당사가 제1항에 따라 게시하거나 고지를 하는 경우에는 “회원이 변경에 동의하지 아니한 경우 고지를 받은 날로부터 30일 이내에 계약을 해지할 수 있으며, 계약해지의 의사표시를 하지 아니한 경우에는 변경에 동의한 것으로 본다”라는 취지의 내용을 통지하여야 합니다.<br>⑤ 회원은 약관의 변경내용이 게시되거나 통지된 후부터 변경되는 약관의 시행일 전의 영업일까지 당사와 서비스 이용계약을 해지할 수 있습니다. 이 기간 안에 회원이 약관의 변경내용에 대하여 이의를 제기하지 아니하는 경우에는 약관의 변경을 승인한 것으로 봅니다.<br>⑥ 본 조의 통지방법 및 통지의 효력은 본 약관의 각 조항에서 규정하는 개별적인 또는 전체적인 통지의 경우에 이를 준용합니다.<br>⑦ 당사가 회원에 고지하는 방법은 다음 각 호에 따릅니다.
            <span class="use-box-des-more">
                1. e-mail 통보<br>2. 휴대 전화 메시지(SMS, LMS 등) 발송<br>3. 서면통보<br>4. 해피포인트 홈페이지(www.happypointcard.com)(이하 "홈페이지")또는 해피포인트 모바일 어플리케이션(이하 "해피앱") 내 게시<br>5. 제휴가맹점 내 게시
            </span>
        </p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 5조 (회원가입 및 해피포인트카드 발급)</h3>
        <p class="use-box-desc">① 회원으로 가입하고자 하는 고객은 당사에서 정한 홈페이지 및 모바일(당사 또는 당사의 제휴가맹점에서 운영하는 홈페이지 및 모바일)이나 일부 제휴가맹점의 지점에서 회원 가입 신청서(서면 또는 온라인, 모바일 포함)에 정해진 사항을 기입한 후, 본 약관 및 개인정보 수집 동의서, 개인정보 제 3자 제공 동의서, 위치기반 서비스 이용약관에 동의함으로써 회원가입을 신청합니다. 단, 제휴가맹점을 통하여 가입하는 경우, 제휴가맹점에 따라 별도의 ‘개인정보의 수집, 제공 및 활용에 대한 동의서’를 요청할 수 있습니다.<br>② 14세 미만의 경우, 법정대리인의 동의를 받아 본 약관에 동의하고 가입 신청을 합니다. 단, 이 경우 법률에 의거 또는 제휴가맹점의 정책에 따라 법정대리인의 동의 여부와 관계없이 가입을 제한하거나 일부 서비스 제공이 불가능 할 수 있습니다.<br>③ 회원은 회원자격을 타인에게 양도하거나 대여 또는 담보의 목적으로 이용할 수 없습니다.<br>④ 본 조 제1항 및 제2항에 따라 가입된 회원 중 개인정보를 잘못 기입했거나 개인식별정보, 이름 등이 법적 절차에 의해 변경되었을 경우 증빙자료 제출/심사 후 카드의 명의를 변경할 수 있습니다.<br>⑤ 카드의 분실/파손/사용정지 등의 상태 변경은 회원 자격에 영향을 미치지 않습니다. </p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 5조 (회원가입 및 해피포인트카드 발급)</h3>
        <p class="use-box-desc">① 회원으로 가입하고자 하는 고객은 당사에서 정한 홈페이지 및 모바일(당사 또는 당사의 제휴가맹점에서 운영하는 홈페이지 및 모바일)이나 일부 제휴가맹점의 지점에서 회원 가입 신청서(서면 또는 온라인, 모바일 포함)에 정해진 사항을 기입한 후, 본 약관 및 개인정보 수집 동의서, 개인정보 제 3자 제공 동의서, 위치기반 서비스 이용약관에 동의함으로써 회원가입을 신청합니다. 단, 제휴가맹점을 통하여 가입하는 경우, 제휴가맹점에 따라 별도의 ‘개인정보의 수집, 제공 및 활용에 대한 동의서’를 요청할 수 있습니다.<br>② 14세 미만의 경우, 법정대리인의 동의를 받아 본 약관에 동의하고 가입 신청을 합니다. 단, 이 경우 법률에 의거 또는 제휴가맹점의 정책에 따라 법정대리인의 동의 여부와 관계없이 가입을 제한하거나 일부 서비스 제공이 불가능 할 수 있습니다.<br>③ 회원은 회원자격을 타인에게 양도하거나 대여 또는 담보의 목적으로 이용할 수 없습니다.<br>④ 본 조 제1항 및 제2항에 따라 가입된 회원 중 개인정보를 잘못 기입했거나 개인식별정보, 이름 등이 법적 절차에 의해 변경되었을 경우 증빙자료 제출/심사 후 카드의 명의를 변경할 수 있습니다.<br>⑤ 카드의 분실/파손/사용정지 등의 상태 변경은 회원 자격에 영향을 미치지 않습니다. </p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 6조 (해피포인트카드 서비스 개요)</h3>
        <p class="use-box-desc">① 당사가 본 약관에 정해진 바에 따라 회원에게 제공하는 해피포인트카드 서비스는 다음 각 호와 같으며 해피포인트카드 서비스를 이용하고자 하는 고객은 본 약관에 정해진 제반 절차를 거쳐 회원으로 가입하여야 합니다. 단, 개별 서비스의 특성 또는 해피포인트카드의 성격에 따라 일부 서비스의 이용조건, 이용범위 등이 제한되거나 회원에게 일정한 자격요건이 요구될 수 있으며, 이 경우 당사는 그 제한 사항 및 자격요건을 회원에게 고지해 드립니다.
            <span class="use-box-des-more">
                가. 회원은 회원 본인이 제휴가맹점에서 상품/서비스를 구입하고 제휴가맹점의 포인트 지급 원칙에 따라 현장에서 해피포인트카드를 제시하거나, 온라인에서 카드 등록 또는 인증하면 해피포인트를 적립 받을 수 있으며, 필요에 따라 본인 확인을 위하여 신분증 제시를 요구할 수 있습니다.<br>나. 적립 포인트는 실 결제 금액에 제휴가맹점별 적립률을 적용하여 산정되며, 제휴가맹점 별 적립률은 해피포인트 홈페이지 및 해피앱 혹은 제휴가맹점 홈페이지에서 확인 가능합니다. 단, 당사와 제휴가맹점의 정책에 따라 해피포인트 모바일 카드 발급고객과 해피포인트 모바일 카드 미발급고객의 적립률은 상이하게 적용됩니다.<br>다. 회원이 상품/서비스를 구입 후 해피포인트카드 이외에 타 제휴카드, 타사 멤버십 카드를 제시하거나 이미 할인된 상품/서비스를 구매하는 경우 해피포인트 적립이 불가할 수 있습니다. 단, 당사가 중복 적립 가능하도록 허용한 경우에는 정해진 적립률에 따라 포인트를 적립 받을 수 있습니다.<br>라. 포인트는 제휴 가맹점에서 상품/서비스를 구입한 시점에, 회원 본인의 매출금액에 대한 현장(제휴가맹점)적립을 원칙으로 하나, 카드 미제시 등의 이유로 적립하지 못하였을 때에는 구입한 시점으로부터 24시간 이내일 경우 영수증 바코드를 이용하여 해피앱 등으로 적립할 수 있습니다. 또한 제휴가맹점의 정책에 따라 구입 및 적립 요청 시점 이후 특정 시점에 포인트가 일괄 적립될 수 있습니다. 이때 당사는 당사의 홈페이지나 해피앱 또는 제휴가맹점 홈페이지나 모바일 어플리케이션, 제휴영업점을 통하여 별도 표기 합니다.<br>마. 제휴가맹점의 정책에 따라 일부 제휴가맹점에서는 포인트 적립이 불가할 수도 있으며, 온라인 서비스의 경우 별도의 적립률이 적용될 수 있습니다. 이 경우 당사 홈페이지 및 해피앱 혹은 제휴가맹점 홈페이지 및 제휴가맹점을 통하여 별도 안내합니다.<br>바. 포인트 적립률 및 기준은 당사와 제휴가맹점의 내부 방침에 따라 사전고지 후 변경될 수 있습니다.<br>사. 회원은 상품 구매 외에도 당사 홈페이지나 해피앱, 제휴가맹점 홈페이지나 모바일 어플리케이션, 제휴 영업점에서 한시적으로 또는 상시로 진행하는 이벤트에 참여하는 등의 방법으로 해피포인트를 적립할 수 있습니다.
            </span>
        ② 당사는 해피포인트카드 서비스의 원활한 제공을 위하여 홈페이지를 운영하고 있으며, 회원은 이용자 ID 및 Password 지정 등 당사가 정하는 이용자 등록 절차를 거쳐 홈페이지 및 해피앱 내 각종 서비스를 이용할 수 있습니다.<br>③ 해피포인트는 금전으로 교환 또는 환불이 불가하며, 다른 회원이 보유한 포인트와 합산하거나 제3자에 대한 양도, 별도의 충전이 불가합니다.
        </p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 7조 (해피포인트카드의 이용 및 운용)</h3>
        <p class="use-box-desc">① 회원은 "제휴가맹점"에서 1,000원 이상의 상품 및 서비스를 구매하는 경우, 해피포인트카드, 해피포인트 제휴카드 또는 해피포인트 모바일 카드를 제시하고 제휴가맹점의 기준에 따라 실 결제금액의 특정 비율만큼 포인트를 적립 받을 수 있습니다. 회원은 휴대전화번호 등 회원의 개인정보로 회원임을 인증하는 경우, 해피포인트카드, 해피포인트 제휴카드 또는 해피포인트 모바일 카드를 제시하지 아니하더라도 해피포인트를 적립할 수 있습니다.<br>② 포인트가 일정 포인트 이상[현행 일백포인트 이상이며, 행사 또는 제휴가맹점의 별도 기준에 따를 수 있음] 적립된 경우, 회원은 당사의 가맹점에서 제품 구매 시 10포인트 단위로 현금 대신 활용하실 수 있습니다. 단, 포인트로 제품을 구매하는 경우, 포인트 사용 금액 상당에 대하여는 포인트의 추가 적립이 불가합니다.<br>③ 해피포인트 적립 및 사용은 해피포인트카드 운영정책에 따라 해피포인트카드에 등록된 회원 정보와 회원이 제시한 정보가 일치할 경우에 한하여 가능합니다.<br>④ 1회 이상 해피포인트를 적립 또는 사용한 회원은 본 약관의 모든 사항에 동의한 것으로 간주합니다.<br>⑤ 회원은 이 카드 및 회원에게 적립된 포인트를 타인에게 양도 또는 담보의 목적으로 이용할 수 없으며 선량한 관리자로서의 주의를 다하여 카드 및 적립 포인트를 이용, 관리하여야 합니다.<br>⑥ 회원은 카드를 분실하였을 경우 즉시 당사에 알려, 카드 정지 및 재발급 요청을 할 수 있으며, 당사는 요청을 받은 때부터 제3자가 해당 카드를 사용함으로 인하여 회원에게 발생한 손해를 배상할 책임을 부담합니다. 다만, 카드 정지 및 재발급 요청이 있기 전에 적립된 포인트에 대한 손해에 대해서는 그 책임을 회원의 부담으로 할 수 있습니다.<br>⑦ 회원은 당사가 정한 회원의 필수정보(이름, 주민등록번호 7자리(생년월일, 성별), CI값 등 본인식별번호, 휴대폰 번호, 주소, e-mail)가 누락되어 있을 경우 적립된 포인트의 사용이 제한 될 수 있습니다.<br>⑧ 회원의 구매로 적립된 포인트의 유효기간은 적립일로부터 36개월이며 적립일로부터 36개월 이후 적립 포인트는 실효되어 자동 소멸됩니다. 유효기간은 연장이 불가능하며, 당사는 유효기간이 도래하기 1개월 전 회원이 당사에 제출한 전화번호를 통한 메시지(SMS/LMS/MMS/PUSH)나 전자우편 주소로 유효기간의 도래, 연장이 불가능하다는 점에 대해 1회 이상 통지합니다.<br>⑨ 당사 또는 제휴가맹점은 이벤트 성으로 한시적 유효기간을 갖는 포인트를 지급할 수 있으며, 이 경우 별도 유효기간이 적용될 수 있습니다.<br>⑩ 포인트의 실효는 회원 자격에 영향을 미치지 아니합니다.<br>⑪ 당사는 사회공익활동 참가희망 회원에 한하여 회원의 적립포인트 중 10%를 활용하여 사회활동에 참여 할 수 있으며, 참여 의사는 홈페이지 및 해피포인트카드 고객센터를 통하여 언제라도 변경할 수 있습니다. 당사는 해당 기부금액의 사용 시 그 내역을 당사의 홈페이지를 통해 공고하여야 합니다.<br>⑫ 당사는 할인카드, 쿠폰, 기타 프로모션에 따른 할인 혜택 및 증정품(판촉물, 제품)제공 행사 참여 혜택과 포인트 적립/사용 서비스를 중복 제공하지 아니할 수 있습니다. 단, 당사가 중복 적립 가능하도록 허용한 경우에는 정해진 적립률에 따라 포인트를 적립 받을 수 있습니다.</p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 8조 (적립포인트의 관리 및 권리)</h3>
        <p class="use-box-desc">① 포인트는 카드발급 후 최초 적립하는 시점부터 누적 적립됩니다.<br>② 포인트는 회원에게 귀속된 금전적 권리이므로 당사는 이를 제3자에게 담보로 제공하거나 채무에 대한 변제로 충당할 수 없습니다.<br>③ 포인트 적립에 오류가 있을 경우 회원은 오류 발생 시점부터 30일 이내에 "당사"에 정정신청을 하여야 하며 "당사"는 회원의 정정요청일로부터 30일 이내에 조정을 할 수 있습니다. 단, 회원은 이를 증명할 수 있는 구매 영수증이나 기타 자료를 제시하거나 제휴가맹점으로부터 명시적인 확인을 받아야 합니다.<br>④ 적립 포인트는 당사의 홈페이지 또는 해피앱, 각 가맹점에 설치된 POS 및 결제 영수증, 해피포인트카드 고객센터에서 조회 가능합니다.</p>
    </li>
    <li class="use-box">
        <h3 class="use-box-tit">제 9조 (카드의 분실 및 재발급)</h3>
        <p class="use-box-desc">① 회원이 카드를 분실, 파·훼손하였을 경우 당사 해피포인트카드 고객센터(080-320-1234)를 통해 재발급 신청을 하거나, 홈페이지에서 당사가 정하는 신청절차를 거친 후 재발급을 신청할 수 있습니다. 이때, 기존 카드는 정지되며, 기존 적립포인트는 재발급 시 신규카드로 이관됩니다.<br>② 이관 완료된 카드는 회원이 등록한 주소지로 발송됩니다. 회원은 카드의 정확한 배송을 위해 재발급 신청 시 정확한 주소를 등록해야 하며, 재발급 신청 시 정보 미변경으로 인한 손실에 대해서는 회원이 모든 책임을 집니다. 단, 해피포인트 제휴카드의 포인트 이관은 별도의 정책에 따를 수 있으며, 이러한 경우, 회원에게 별도로 고지해야 합니다.</p>
    </li>
</ul>

</div>
</section>

</main>
<!-- } 메인콘텐츠 끝 -->


<!-- 하단 시작 { -->
<footer id="footer">
    <div class="inner">
        <h2 class="f-logo">던킨</h2>
        <ul class="f-menu clearfix">
            <li><a href="/sub/sub-f-use.php">이용약관</a></li>
            <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
            <li><a href="/sub/sub-f-privacy.php">영상정보처리기기운영방침</a></li>
            <li><a href="/sub/sub-f-safety.php">안전보건경영방침</a></li>
        </ul>
        <div class="f-banner">
            <div class="f-site">
                <p class="f-site-tit">Family site<span class="material-symbols-outlined">expand_less</span></p>
                <ul class="f-site-box">
                    <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
                    <li><a href="http://www.brkorea.co.kr/">비알코리아</a></li>
                    <li><a href="http://www.baskinrobbins.co.kr/">배스킨라빈스</a></li>
                    <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
                    <li><a href="https://shany.co.kr/">샤니</a></li>
                    <li><a href="https://www.caffe-pascucci.co.kr/index.asp">파스쿠찌</a></li>
                    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=044D0806A9BA8A6F21BEDA177BB8A053">해피포인트카드</a></li>
                    <li><a href="https://dunkinschool.hunet.co.kr/Login/LoginGate">던킨 온라인 스쿨</a></li>
                    <li><a href="https://dunkin.alba.co.kr/job/brand/main.asp">던킨 아르바이트</a></li>
                </ul>
            </div>
            <ul class="f-sns">
                <li><a href="https://www.facebook.com/DunkinKorea" target="_blank">페이스북</a></li>
                <li><a href="https://www.instagram.com/dunkin_kr/" target="_blank">인스타그램</a></li>
                <li><a href="https://blog.naver.com/dunkin_kr" target="_blank">블로그</a></li>
                <li><a href="https://www.youtube.com/user/dunkindonutskorea" target="_blank">유튜브</a></li>
                <li><a href="https://twitter.com/dunkin_kr" target="_blank">트위터</a></li>
            </ul>
            <ul class="f-mark">
                <li><a href="http://www.spc.co.kr/contributionAll"  target="_blank">SPC행복한 이야기</a></li>
                <li><a href="https://www.kca.go.kr/ccm/" target="_blank">소비자중심경영</a></li>
                <li><a href="https://knqa.ksa.or.kr/knqa/2276/subview.do" target="_blank">국가품질상</a></li>
            </ul>
        </div>
        <div class="f-copy">
            <ul class="f-add clearfix">
                <li><address>서울특별시 서초구 남부순환로 2620(양재동 11-149번지)</address></li>
                <li>TEL : 080-555-3131</li>
                <li>VOC상담: 080-555-3131</li>
                <li>개인정보관리책임자 : 김경우</li>
                <li>사업자 등록번호 : 303-81-09535</li>
                <li>비알코리아(주) 대표이사 도세호</li>
            </ul>
            <p>COPYRIGHT Ⓒ 2016 BRKOREA COMPANY. ALL RIGHTS RESERVED.</p>
        </div>
    </div>
</footer>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    });
</script>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->


</body>
</html>
